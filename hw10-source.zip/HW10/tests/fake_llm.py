"""測試用假 LLM：重播 runs/v2 的輸出，用來驗證 v3 graph 的路由與迴圈（不是正式執行結果）。"""
import json, re
from pathlib import Path
ROOT = Path(__file__).resolve().parent.parent


class FakeLLM:
    models = {"writer": "fake-writer", "reviewer": "fake-reviewer"}

    def __init__(self, run_dir):
        self.dir = run_dir / "llm"; self.dir.mkdir(parents=True, exist_ok=True)
        self.outline = json.load(open(ROOT / "runs/v2/llm/outline_1.response.json"))["slides"]
        self.slides = {s["id"]: s for s in json.load(open(ROOT / "runs/v2/llm/draft_1.response.json"))["slides"]}
        self.reviewed = set()

    def __call__(self, key, prompt, role="writer"):
        (self.dir / f"{key}.prompt.md").write_text(prompt, encoding="utf-8")
        ids = set(re.findall(r"\[([a-z0-9\-]+#\d+)\]", prompt))
        if key.startswith("outline"):
            out = [dict(s, claims=[c for c in s["claims"] if c in ids]) for s in self.outline]
            res = {"slides": out}
        elif key.startswith("draft"):
            sid = key.split("_")[1]
            s = json.loads(json.dumps(self.slides[sid]))
            if "overflow" in prompt and s.get("bullets"):
                s["bullets"] = s["bullets"][:3]
            res = s
        else:
            sid = key.split("_")[1]
            if sid == "s06" and sid not in self.reviewed:
                self.reviewed.add(sid)
                res = {"verdict": "fail", "issues": [{"where": "bullet 3", "type": "misleading", "problem": "測試用", "fix": "測試用"}]}
            else:
                res = {"verdict": "pass", "issues": []}
        (self.dir / f"{key}.response.json").write_text(json.dumps(res, ensure_ascii=False), encoding="utf-8")
        return res
