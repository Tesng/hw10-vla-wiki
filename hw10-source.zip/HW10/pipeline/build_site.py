"""產生 GitHub Pages 用的 site/：首頁（繳交內容 1–6）、Wiki 瀏覽頁、簡報、執行紀錄。
用法：python3 pipeline/build_site.py   → 把 site/ 裡面的檔案拖進 GitHub repo 即可（index.html 在最外層）。
"""
from __future__ import annotations
import html, json, re, shutil, sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from wiki import load_wiki, load_raw, ROOT

SITE = ROOT / "site"
E = html.escape

CSS = """
*{box-sizing:border-box}body{margin:0;font-family:-apple-system,"PingFang TC","Noto Sans TC","Microsoft JhengHei",sans-serif;
color:#1f2933;background:#f7f8fa;line-height:1.7}
a{color:#2a7f74}header{background:#0f1419;color:#e8edf2;padding:28px 6vw}header h1{margin:0;font-size:28px}
header p{margin:.4em 0 0;color:#93a1b0}nav.top{display:flex;gap:18px;flex-wrap:wrap;margin-top:14px}nav.top a{color:#4fb3a9;text-decoration:none}
main{max-width:1080px;margin:0 auto;padding:28px 6vw 80px}.wrap{display:grid;grid-template-columns:230px 1fr;gap:32px;max-width:1200px;margin:0 auto;padding:28px 4vw}
aside.side{position:sticky;top:16px;align-self:start;font-size:14px}aside.side h4{margin:1.2em 0 .3em;color:#52606d}aside.side a{display:block;text-decoration:none;padding:2px 0}
aside.side a.on{font-weight:700}h1,h2,h3{line-height:1.3}h2{margin-top:2em;border-bottom:2px solid #e4e7eb;padding-bottom:.3em}
table{border-collapse:collapse;width:100%;font-size:14px;margin:1em 0;background:#fff}th,td{border:1px solid #e4e7eb;padding:6px 10px;text-align:left;vertical-align:top}
th{background:#f0f4f8}code{background:#eef1f4;padding:1px 5px;border-radius:4px;font-size:.92em}pre{background:#0f1419;color:#e8edf2;padding:14px;border-radius:8px;overflow:auto}
pre code{background:none;color:inherit}.cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin:18px 0}
.card{background:#fff;border:1px solid #e4e7eb;border-radius:12px;padding:16px;text-decoration:none;color:inherit}.card b{display:block;font-size:17px;color:#2a7f74}
.card span{font-size:14px;color:#52606d}.chip{font-size:11px;border:1px solid #cbd2d9;border-radius:5px;padding:0 5px;margin-left:3px;text-decoration:none;color:#52606d;white-space:nowrap}
.inf{font-size:11px;color:#c56a15;border:1px solid #e0893a;border-radius:5px;padding:0 5px}.warn{background:#fff7e6;border-left:3px solid #e0893a;padding:2px 8px}
.meta{color:#52606d;font-size:14px}figure{margin:1em 0;background:#fff;border:1px solid #e4e7eb;border-radius:12px;padding:10px}figure svg{width:100%;height:auto}
blockquote{border-left:3px solid #cbd2d9;margin:1em 0;padding:.2em 1em;color:#52606d}
"""


def page(title, body, nav_prefix=""):
    return (f'<!DOCTYPE html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>{E(title)}</title><style>{CSS}</style></head><body><header><h1>{E(title)}</h1>'
            f'<p>HW10｜用 LLM Wiki 做教學 HTML 簡報 — VLA 模型入門</p><nav class="top">'
            f'<a href="{nav_prefix}index.html">首頁（繳交內容）</a><a href="{nav_prefix}wiki/index.html">LLM Wiki</a>'
            f'<a href="{nav_prefix}slides.html">教學簡報</a><a href="{nav_prefix}runs.html">執行與檢查紀錄</a></nav></header>{body}</body></html>')


def inline(t, link=lambda n: f"{n}.html", raw=None):
    raw = raw or {}
    t = E(t)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<b>\1</b>", t)
    t = re.sub(r"\[([^\]]+)\]\(([^)]+)\)", r'<a href="\2">\1</a>', t)
    t = re.sub(r"\[\[src:([a-z0-9\-]+)\]\]", lambda m: f'<a class="chip" href="{E(raw[m.group(1)]["meta"]["url"])}" '
               f'title="{E(raw[m.group(1)]["meta"]["title"])}" target="_blank">{m.group(1)}</a>' if m.group(1) in raw else m.group(0), t)
    t = re.sub(r"\[\[([a-z0-9\-]+)\]\]", lambda m: f'<a href="{link(m.group(1))}">{m.group(1)}</a>', t)
    t = t.replace("(推論)", '<span class="inf">推論</span>')
    return t


def md(text, **kw):
    out, lines, i = [], text.splitlines(), 0
    while i < len(lines):
        l = lines[i]
        if l.startswith("```"):
            j = i + 1
            while j < len(lines) and not lines[j].startswith("```"):
                j += 1
            lang = l[3:].strip()
            code = "\n".join(lines[i + 1:j])
            out.append(f'<pre><code class="{lang}">{E(code)}</code></pre>')
            i = j + 1
            continue
        if l.strip() == "<!-- GRAPH_SVG -->":
            out.append(f"<figure>{(ROOT / 'docs' / 'graph.svg').read_text(encoding='utf-8')}</figure>")
        elif l.strip().startswith("<!--") and l.strip().endswith("-->"):
            out.append(l.strip())
        elif re.match(r"^#{1,4} ", l):
            n = len(l.split(" ")[0])
            m = re.match(r"(\d+)\.", l[n+1:])
            hid = f' id="sec{m.group(1)}"' if m else ""
            out.append(f"<h{n}{hid}>{inline(l[n+1:], **kw)}</h{n}>")
        elif l.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                if not re.match(r"^\|[\s\-:|]+\|$", lines[i]):
                    rows.append([c.strip() for c in lines[i].strip().strip("|").split("|")])
                i += 1
            out.append("<table>" + "".join("<tr>" + "".join(f"<{'th' if k == 0 else 'td'}>{inline(c, **kw)}</{'th' if k == 0 else 'td'}>"
                                                             for c in r) + "</tr>" for k, r in enumerate(rows)) + "</table>")
            continue
        elif re.match(r"^\s*([-*]|\d+\.) ", l):
            tag = "ol" if re.match(r"^\s*\d+\. ", l) else "ul"
            items = []
            while i < len(lines) and re.match(r"^\s*([-*]|\d+\.) ", lines[i]):
                txt = re.sub(r"^\s*([-*]|\d+\.) ", "", lines[i])
                cls = ' class="warn"' if txt.startswith("⚠") else ""
                items.append(f"<li{cls}>{inline(txt, **kw)}</li>")
                i += 1
            out.append(f"<{tag}>{''.join(items)}</{tag}>")
            continue
        elif l.startswith(">"):
            out.append(f"<blockquote>{inline(l[1:].strip(), **kw)}</blockquote>")
        elif l.strip():
            out.append(f"<p>{inline(l, **kw)}</p>")
        i += 1
    return "\n".join(out)


def build_wiki(raw):
    pages = load_wiki()
    d = SITE / "wiki"
    d.mkdir(parents=True, exist_ok=True)
    groups = {"meta": [], "concept": [], "source": []}
    for n, p in pages.items():
        groups.setdefault(p.meta.get("type", "concept"), []).append(n)

    def side(cur):
        h = ""
        for g, title in (("meta", "導覽"), ("concept", "概念頁"), ("source", "論文摘要頁")):
            h += f"<h4>{title}</h4>" + "".join(f'<a href="{n}.html" class="{"on" if n == cur else ""}">{n}</a>' for n in sorted(groups[g]))
        h += '<h4>原始資料 raw/</h4><a href="raw.html">raw sources（7 篇）</a><a href="schema.html">AGENTS.md（schema）</a>'
        return h

    for n, p in pages.items():
        body = md(p.body, raw=raw)
        srcs = "、".join(f'<a href="{E(raw[r]["meta"]["url"])}" target="_blank">{r}</a>' for r in p.meta.get("sources", []) if r in raw)
        meta = f'<p class="meta">{E(str(p.meta.get("summary", "")))}<br>type: {p.meta.get("type")}｜sources: {srcs or "—"}</p>'
        (d / f"{n}.html").write_text(page(f"Wiki：{n}", f'<div class="wrap"><aside class="side">{side(n)}</aside>'
                                          f'<article>{meta}{body}</article></div>', "../"), encoding="utf-8")
    rows = "".join(f'<h3>{E(r["meta"]["title"].strip(chr(34)))} ({r["meta"]["year"]})</h3><p class="meta">id: <code>{k}</code>｜'
                   f'<a href="{E(r["meta"]["url"])}" target="_blank">{E(r["meta"]["url"])}</a></p>{md(r["text"])}' for k, r in raw.items())
    (d / "raw.html").write_text(page("Wiki：raw sources", f'<div class="wrap"><aside class="side">{side("")}</aside><article>'
                                     f'<p class="meta">raw/ 是不可修改的原始資料層；Wiki 的每個數字都必須在這裡找得到。</p>{rows}</article></div>', "../"),
                                encoding="utf-8")
    (d / "schema.html").write_text(page("Wiki：AGENTS.md", f'<div class="wrap"><aside class="side">{side("")}</aside><article>'
                                        f'{md((ROOT / "AGENTS.md").read_text(encoding="utf-8"))}<h2>需求摘要（先討論）</h2>'
                                        f'{md((ROOT / "docs" / "requirements.md").read_text(encoding="utf-8"))}</article></div>', "../"),
                                   encoding="utf-8")
    return len(pages)


def trace_table(run):
    p = ROOT / "runs" / run / "trace.jsonl"
    if not p.exists():
        return ""
    rows = ["| # | 節點 | → 下一步 | 結果 |", "|---|---|---|---|"]
    for k, l in enumerate(p.read_text().splitlines(), 1):
        t = json.loads(l)
        if t.get("event") == "wait_llm":
            continue
        info = {a: b for a, b in t.items() if a not in ("node", "visit", "ms", "next")}
        rows.append(f"| {k} | {t['node']} | {t.get('next')} | `{json.dumps(info, ensure_ascii=False)[:180]}` |")
    return "\n".join(rows)


def build_runs():
    parts = ["# 執行與檢查紀錄", "",
             "每次執行都保存在 `runs/<id>/`：`trace.jsonl`（每個節點的執行與路由）、`state.json`（checkpoint）、"
             "`llm/`（每次 LLM 呼叫的 prompt 與 response）。v3 另外有 `sources.md`、`cards/`、`outline.md`、`drafts/`、`deck.html`、`report.md`。", ""]
    for run, note in (("v5", "run v5（最終版，Groq）"), ("v4", "run v4（Groq）"), ("v3", "run v3（Groq）"),
                      ("v2", "run v2"), ("v1", "run v1")):
        if not (ROOT / "runs" / run).exists():
            continue
        parts += [f"## {note}", ""]
        rep = ROOT / "runs" / run / "report.md"
        if rep.exists():
            parts += [re.sub(r"^# ", "### ", rep.read_text(encoding="utf-8"), flags=re.M).replace("\n## ", "\n#### "), ""]
        parts += ["### trace（節點執行順序）", "", trace_table(run), ""]
        if run in ("v1", "v2"):
            parts += [f"簡報成品：[slides-{run}.html](slides-{run}.html)", ""]
    for f, title in (("runs/v3/attempt1/README.md", "v3 第 1 次執行：在 draft_pages 當掉"),
                     ("runs/v3_review/recheck_with_v4.txt", "v3 的 49 份稿子用 v4 檢查器重跑"),
                     ("runs/wiki_lint/lint_0_initial.txt", "Wiki 第一次 lint"),
                     ("runs/v1_review/claim_trace.txt", "v1 人工審查：逐句比對"),
                     ("runs/v1_review/replay_v2_checks.txt", "把 v2 檢查回放到 v1 草稿")):
        p = ROOT / f
        if p.exists():
            parts += [f"## {title}", "", "```", p.read_text(encoding="utf-8").strip(), "```", ""]
    (SITE / "runs.html").write_text(page("執行與檢查紀錄", f"<main>{md(chr(10).join(parts), link=lambda n: 'wiki/' + n + '.html')}</main>"),
                                    encoding="utf-8")


def main():
    if SITE.exists():
        shutil.rmtree(SITE)
    SITE.mkdir()
    raw = load_raw()
    n = build_wiki(raw)
    shutil.copy(ROOT / "output" / "slides.html", SITE / "slides.html")
    for r in ("v1", "v2"):
        src = ROOT / "output" / f"slides_{r}.html"
        if src.exists():
            shutil.copy(src, SITE / f"slides-{r}.html")
    build_runs()
    report = (ROOT / "REPORT.md").read_text(encoding="utf-8")
    cards = ('<div class="cards"><a class="card" href="wiki/index.html"><b>📚 LLM Wiki</b><span>15+ 頁概念與論文摘要，每句附出處</span></a>'
             '<a class="card" href="slides.html"><b>🎞 教學 HTML 簡報</b><span>←/→ 換頁、N 看講者備註、quiz 可作答</span></a>'
             '<a class="card" href="runs.html"><b>🧪 執行與檢查紀錄</b><span>v1→v5 的 trace 與檢查報告</span></a>'
             '<a class="card" href="hw10-source.zip"><b>📦 原始碼與紀錄</b><span>graph、Wiki、raw、所有 runs（zip）</span></a></div>')
    body = md(report, link=lambda x: f"wiki/{x}.html", raw=raw)
    body = body.replace("<!-- CARDS -->", cards)
    (SITE / "index.html").write_text(page("VLA 是什麼？— LLM Wiki × 教學簡報", f"<main>{body}</main>"), encoding="utf-8")
    (SITE / ".nojekyll").write_text("")
    # 原始碼與完整執行紀錄（不含 .env 與 git）打包，方便助教查看
    import zipfile
    with zipfile.ZipFile(SITE / "hw10-source.zip", "w", zipfile.ZIP_DEFLATED) as z:
        for p in sorted(ROOT.rglob("*")):
            rel = p.relative_to(ROOT)
            if p.is_dir() or rel.parts[0] in (".git", "site") or p.name.endswith(".env") or p.name == ".env" \
                    or "__pycache__" in rel.parts or p.name == ".DS_Store":
                continue
            z.write(p, f"HW10/{rel}")
    files = sorted(str(p.relative_to(SITE)) for p in SITE.rglob("*") if p.is_file())
    print(f"site/ 已產生：{len(files)} 個檔案（wiki {n} 頁）")


if __name__ == "__main__":
    main()
