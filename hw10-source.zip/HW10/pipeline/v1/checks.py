"""簡報內容的確定性檢查（不靠 LLM）。回傳錯誤清單，每項含 slide id、類型、說明，會原樣回饋給 repair 節點。"""
from __future__ import annotations
import re
import config as C
from wiki import numbers

KINDS = {"title", "content", "flow", "compare", "timeline", "quiz", "summary"}


def slide_text(s: dict) -> str:
    parts = [s.get("title", ""), s.get("subtitle", "")]
    parts += [b.get("text", "") for b in s.get("bullets", [])]
    for st in s.get("flow", []):
        parts += [st.get("label", ""), st.get("text", "")]
    t = s.get("table") or {}
    parts += t.get("columns", []) + [str(c) for r in t.get("rows", []) for c in r]
    parts += [f"{i.get('name','')} {i.get('text','')}" for i in s.get("timeline", [])]
    q = s.get("quiz") or {}
    parts += [q.get("q", "")] + q.get("options", []) + [q.get("explain", "")]
    return "\n".join(parts)


def grounded_units(s: dict):
    """所有需要有出處的單位：(文字, 引用清單, 位置描述)。"""
    for i, b in enumerate(s.get("bullets", [])):
        if b.get("type", "fact") == "fact":
            yield b.get("text", ""), b.get("cite", []), f"bullet {i+1}"
    t = s.get("table")
    if t:
        for r in t.get("rows", []):
            yield " ".join(map(str, r)), t.get("cite", []), "table row"
    for it in s.get("timeline", []):
        yield it.get("text", ""), it.get("cite", []), f"timeline {it.get('name')}"
    q = s.get("quiz")
    if q:
        yield q.get("explain", ""), q.get("cite", []), "quiz explain"


def check_slides(slides: list[dict], pages: dict[str, str], context: set[str]) -> list[dict]:
    errs = []
    E = lambda sid, typ, msg: errs.append({"slide": sid, "type": typ, "msg": msg})
    lo, hi = C.SLIDE_RANGE
    if not lo <= len(slides) <= hi:
        E("-", "slide_count", f"共 {len(slides)} 張，需介於 {lo}–{hi}")
    covered = {s.get("objective") for s in slides}
    for o in C.OBJECTIVES:
        if o not in covered:
            E("-", "objective_uncovered", f"{o} 沒有任何投影片負責")
    if slides and slides[0].get("kind") != "title":
        E(slides[0].get("id"), "structure", "第一張必須是 title")
    if not any(s.get("kind") == "quiz" for s in slides):
        E("-", "structure", "教學簡報至少要有 1 張 quiz（小測驗）")
    if not any(s.get("kind") == "summary" for s in slides):
        E("-", "structure", "缺少 summary 投影片")

    defined: set[str] = set()
    for s in slides:
        sid = s.get("id", "?")
        if s.get("kind") not in KINDS:
            E(sid, "schema", f"kind={s.get('kind')} 不合法")
        bl = s.get("bullets", [])
        if len(bl) > C.MAX_BULLETS:
            E(sid, "too_long", f"{len(bl)} 個 bullet > {C.MAX_BULLETS}")
        for b in bl:
            if len(b.get("text", "")) > C.MAX_BULLET_CHARS:
                E(sid, "too_long", f"bullet 超過 {C.MAX_BULLET_CHARS} 字：{b['text'][:30]}…")
        # 引用與數字
        for text, cites, where in grounded_units(s):
            if not cites:
                E(sid, "uncited", f"{where} 沒有引用 wiki 頁：{text[:40]}")
                continue
            for c in cites:
                if c not in pages:
                    E(sid, "bad_cite", f"{where} 引用不存在的頁 [[{c}]]")
                elif c not in context:
                    E(sid, "cite_outside_context", f"{where} 引用了 query 沒取回的頁 [[{c}]]")
            src = set().union(*(numbers(pages[c]) for c in cites if c in pages)) if cites else set()
            miss = numbers(text) - src
            if miss:
                E(sid, "ungrounded_number", f"{where} 的數字 {sorted(miss)} 在引用頁 {cites} 找不到")
        # 術語：第一次出現必須定義
        text = slide_text(s)
        here = {d.get("term") for d in s.get("defines", [])}
        for term, rx in C.TERMS.items():
            if term in defined:
                continue
            if re.search(rx, text, re.I) or term in here:
                if term in here:
                    defined.add(term)
                else:
                    E(sid, "undefined_term", f"術語「{term}」第一次出現但沒有在 defines 解釋")
                    defined.add(term)  # 只報一次
    return errs

