"""LLM Wiki → 教學 HTML 簡報 的 graph（v1）。

用法：
  python pipeline/graph.py --run v1            # 開始（agent 模式遇到 LLM 節點會暫停）
  python pipeline/graph.py --run v1 --resume   # LLM 回覆寫好後繼續
  ANTHROPIC_API_KEY=... python pipeline/graph.py --run auto --llm anthropic   # 全自動
"""
from __future__ import annotations
import argparse, json, re, sys
from html.parser import HTMLParser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config as C
from engine import Graph, END
from wiki import load_wiki, load_raw, ROOT
from lint import lint
from checks import check_slides
from llm import make_llm
import prompts as P
import render as R

g = Graph()
LLM = None


def pages_text():
    return {n: p.body for n, p in load_wiki().items()}


# ── 1. 取得資料 ───────────────────────────────────────────────
@g.node("load_wiki")
def load_wiki_node(st):
    pages = load_wiki()
    st["wiki_meta"] = {n: p.meta.get("sources", []) for n, p in pages.items()}
    return {"pages": len(pages), "raw_sources": len(load_raw())}


@g.node("lint_wiki")
def lint_wiki_node(st):
    st["lint_errors"] = lint()
    return {"lint_errors": len(st["lint_errors"])}


g.edge("load_wiki", "lint_wiki")
g.edge("lint_wiki", lambda st: "query_wiki" if not st["lint_errors"] else "stop_fix_wiki")


@g.node("stop_fix_wiki")
def stop_fix_wiki(st):
    st["status_final"] = "failed: wiki lint 未通過，請先 ingest/修 wiki（python pipeline/lint.py）"
    return {"errors": st["lint_errors"][:5]}


g.edge("stop_fix_wiki", END)


# ── 2. 查詢 Wiki（index 優先 + 關鍵字打分，每個目標取 top-k）─────────
@g.node("query_wiki")
def query_wiki(st):
    pages = load_wiki()
    retrieval, ctx = {}, set()
    for oid, (_, kws) in C.OBJECTIVES.items():
        scored = []
        for n, p in pages.items():
            if p.meta.get("type") == "meta":
                continue
            hay = (n + " " + str(p.meta.get("summary", "")) + " " + p.body).lower()
            sc = sum(hay.count(k.lower()) for k in kws) + (3 if n in [k.lower() for k in kws] else 0)
            if p.meta.get("type") == "concept":
                sc *= 1.5  # 教學優先用概念頁
            scored.append((round(sc, 1), n))
        top = [n for sc, n in sorted(scored, reverse=True)[:C.TOP_K_PER_OBJECTIVE] if sc > 0]
        retrieval[oid] = top
        ctx |= set(top)
    st["retrieval"] = retrieval
    st["context"] = sorted(ctx)
    return {"context_pages": st["context"]}


g.edge("query_wiki", "outline")


# ── 3. 整理重點（LLM）────────────────────────────────────────
@g.node("outline")
def outline(st):
    pt = pages_text()
    key = f"outline_{st.get('visits', {}).get('outline', 0) + 1}"
    st["outline"] = LLM(key, P.outline_prompt(pt, st["context"], pt["index"]))["slides"]
    return {"outline_slides": len(st["outline"])}


g.edge("outline", "draft_slides")


@g.node("draft_slides")
def draft_slides(st):
    pt = pages_text()
    key = f"draft_{st.get('visits', {}).get('draft_slides', 0) + 1}"
    st["slides"] = LLM(key, P.draft_prompt(pt, st["context"], st["outline"]))["slides"]
    return {"slides": len(st["slides"])}


g.edge("draft_slides", "check_slides")


# ── 4. 檢查內容（確定性）+ 修正迴圈 ─────────────────────────────
@g.node("check_slides")
def check_slides_node(st):
    errs = check_slides(st["slides"], pages_text(), set(st["context"]))
    st["slide_errors"] = errs
    hist = st.setdefault("error_history", [])
    hist.append({"round": len(hist), "n": len(errs), "by_type": _count(errs)})
    return {"errors": len(errs), "by_type": _count(errs)}


def _count(errs):
    out = {}
    for e in errs:
        out[e["type"]] = out.get(e["type"], 0) + 1
    return out


def route_after_check(st):
    if not st["slide_errors"]:
        return "render_html"
    if st.get("visits", {}).get("repair", 0) < C.MAX_REPAIR:
        return "repair"
    return "stop_failed"


g.edge("check_slides", route_after_check)


@g.node("repair")
def repair(st):
    pt = pages_text()
    key = f"repair_{st.get('visits', {}).get('repair', 0) + 1}"
    st["slides"] = LLM(key, P.repair_prompt(pt, st["context"], st["slides"], st["slide_errors"]))["slides"]
    return {"slides": len(st["slides"])}


g.edge("repair", "check_slides")


@g.node("stop_failed")
def stop_failed(st):
    st["status_final"] = f"failed: 修正 {C.MAX_REPAIR} 次仍有 {len(st['slide_errors'])} 個錯誤"
    return {}


g.edge("stop_failed", END)


# ── 5. 產生簡報 + 檢查 HTML ───────────────────────────────────
@g.node("render_html")
def render_html(st):
    out = ROOT / "output" / f"slides_{st['run']}.html"
    out.parent.mkdir(exist_ok=True)
    out.write_text(R.render(st["slides"], C.OBJECTIVES, C.TOPIC, st["wiki_meta"], load_raw()), encoding="utf-8")
    st["output"] = str(out.relative_to(ROOT))
    return {"output": st["output"]}


g.edge("render_html", "check_html")


class _Counter(HTMLParser):
    def __init__(self):
        super().__init__()
        self.sections, self.ext, self.quiz = 0, [], 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "section":
            self.sections += 1
        if tag in ("script", "link", "img") and re.match(r"https?://", a.get("src") or a.get("href") or ""):
            self.ext.append(tag)
        if "quiz" in (a.get("class") or ""):
            self.quiz += 1


@g.node("check_html")
def check_html(st):
    c = _Counter()
    c.feed((ROOT / st["output"]).read_text(encoding="utf-8"))
    errs = []
    if c.sections != len(st["slides"]) + 1:
        errs.append(f"section 數 {c.sections} ≠ 投影片 {len(st['slides'])}+1")
    if c.ext:
        errs.append(f"有外部資源 {c.ext}")
    st["html_errors"] = errs
    st["status_final"] = "done" if not errs else f"failed: {errs}"
    return {"html_errors": errs, "sections": c.sections}


g.edge("check_html", END)


def main():
    global LLM
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="v1")
    ap.add_argument("--llm", default="agent", choices=["agent", "anthropic"])
    ap.add_argument("--resume", action="store_true")
    a = ap.parse_args()
    run_dir = ROOT / "runs" / a.run
    run_dir.mkdir(parents=True, exist_ok=True)
    LLM = make_llm(a.llm, run_dir)
    sp = run_dir / "state.json"
    st = json.loads(sp.read_text()) if a.resume and sp.exists() else {"run": a.run}
    print(f"[graph] run={a.run} start={st.get('_next', 'load_wiki')}")
    st = g.run(st, "load_wiki", run_dir)
    print(f"[graph] status = {st['status']}")


if __name__ == "__main__":
    main()
