"""LLM Wiki → 教學 HTML 簡報 的 graph（v2）。

v1 → v2 變更（見 REPORT.md）：
  * query_wiki 產生 claim 層級的 evidence pack，並檢查每個學習目標至少有 2 個 fact claim（不足就擴大檢索重查）
  * 新增 check_outline（+ repair_outline 迴圈）：在寫內容前就擋下術語順序、目標覆蓋、claim 不存在
  * check_slides 改成 claim 層級：數字必須在「所引 claim」內、(推論) claim 不可被寫成 fact

用法：
  python pipeline/graph.py --run v1            # 開始（agent 模式遇到 LLM 節點會暫停）
  python pipeline/graph.py --run v1 --resume   # LLM 回覆寫好後繼續
  ANTHROPIC_API_KEY=... python pipeline/graph.py --run auto --llm anthropic   # 全自動
"""
from __future__ import annotations
import argparse, json, re, sys
from html.parser import HTMLParser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config as C
from engine import Graph, END
from wiki import load_wiki, load_raw, claims, ROOT
from lint import lint
from checks import check_slides, check_outline
from llm import make_llm
import prompts as P
import render as R

g = Graph()
LLM = None


def pages_text():
    return {n: p.body for n, p in load_wiki().items()}


# ── 1. 取得資料 ───────────────────────────────────────────────
@g.node("load_wiki")
def load_wiki_node(st):
    pages = load_wiki()
    st["wiki_meta"] = {n: p.meta.get("sources", []) for n, p in pages.items()}
    return {"pages": len(pages), "raw_sources": len(load_raw())}


@g.node("lint_wiki")
def lint_wiki_node(st):
    st["lint_errors"] = lint()
    return {"lint_errors": len(st["lint_errors"])}


g.edge("load_wiki", "lint_wiki")
g.edge("lint_wiki", lambda st: "query_wiki" if not st["lint_errors"] else "stop_fix_wiki")


@g.node("stop_fix_wiki")
def stop_fix_wiki(st):
    st["status_final"] = "failed: wiki lint 未通過，請先 ingest/修 wiki（python pipeline/lint.py）"
    return {"errors": st["lint_errors"][:5]}


g.edge("stop_fix_wiki", END)


# ── 2. 查詢 Wiki（index 優先 + 關鍵字打分）→ claim 層級 evidence pack ─────
MIN_FACTS = 2


@g.node("query_wiki")
def query_wiki(st):
    pages = load_wiki()
    k = C.TOP_K_PER_OBJECTIVE + st.get("visits", {}).get("query_wiki", 0)  # 重查時擴大 k
    retrieval, ctx = {}, set()
    for oid, (_, kws) in C.OBJECTIVES.items():
        scored = []
        for n, p in pages.items():
            if p.meta.get("type") == "meta":
                continue
            hay = (n + " " + str(p.meta.get("summary", "")) + " " + p.body).lower()
            sc = sum(hay.count(kw.lower()) for kw in kws) + (3 if n in [kw.lower() for kw in kws] else 0)
            if p.meta.get("type") == "concept":
                sc *= 1.5
            scored.append((round(sc, 1), n))
        retrieval[oid] = [n for sc, n in sorted(scored, reverse=True)[:k] if sc > 0]
        ctx |= set(retrieval[oid])
    ev = claims(pages, sorted(ctx))
    # 檢查：每個目標的頁面至少有 MIN_FACTS 個 fact claim
    thin = [o for o, ns in retrieval.items() if sum(1 for c in ev.values() if c["page"] in ns and c["kind"] == "fact") < MIN_FACTS]
    st.update(retrieval=retrieval, context=sorted(ctx), evidence=ev, thin_objectives=thin)
    return {"k": k, "context_pages": len(ctx), "claims": len(ev),
            "inference_claims": sum(c["kind"] == "inference" for c in ev.values()), "thin": thin}


g.edge("query_wiki", lambda st: "query_wiki" if st["thin_objectives"] and st["visits"]["query_wiki"] < 3 else "outline")


# ── 3. 整理重點（LLM）────────────────────────────────────────
@g.node("outline")
def outline(st):
    pt = pages_text()
    key = f"outline_{st.get('visits', {}).get('outline', 0) + 1}"
    st["outline"] = LLM(key, P.outline_prompt(st["evidence"], pt["index"]))["slides"]
    return {"outline_slides": len(st["outline"])}


g.edge("outline", "check_outline")


@g.node("check_outline")
def check_outline_node(st):
    errs = check_outline(st["outline"], st["evidence"])
    st["outline_errors"] = errs
    st.setdefault("error_history", []).append({"stage": "outline", "n": len(errs), "by_type": _count(errs)})
    return {"errors": len(errs), "by_type": _count(errs)}


g.edge("check_outline", lambda st: "draft_slides" if not st["outline_errors"]
       else ("repair_outline" if st.get("visits", {}).get("repair_outline", 0) < C.MAX_REPAIR else "stop_failed"))


@g.node("repair_outline")
def repair_outline(st):
    pt = pages_text()
    key = f"repair_outline_{st.get('visits', {}).get('repair_outline', 0) + 1}"
    st["outline"] = LLM(key, P.outline_repair_prompt(st["evidence"], pt["index"], st["outline"], st["outline_errors"]))["slides"]
    return {"outline_slides": len(st["outline"])}


g.edge("repair_outline", "check_outline")


@g.node("draft_slides")
def draft_slides(st):
    pt = pages_text()
    key = f"draft_{st.get('visits', {}).get('draft_slides', 0) + 1}"
    st["slides"] = LLM(key, P.draft_prompt(st["evidence"], st["outline"]))["slides"]
    return {"slides": len(st["slides"])}


g.edge("draft_slides", "check_slides")


# ── 4. 檢查內容（確定性）+ 修正迴圈 ─────────────────────────────
@g.node("check_slides")
def check_slides_node(st):
    errs = check_slides(st["slides"], st["evidence"])
    st["slide_errors"] = errs
    st.setdefault("error_history", []).append({"stage": "slides", "n": len(errs), "by_type": _count(errs)})
    return {"errors": len(errs), "by_type": _count(errs)}


def _count(errs):
    out = {}
    for e in errs:
        out[e["type"]] = out.get(e["type"], 0) + 1
    return out


def route_after_check(st):
    if not st["slide_errors"]:
        return "render_html"
    if st.get("visits", {}).get("repair", 0) < C.MAX_REPAIR:
        return "repair"
    return "stop_failed"


g.edge("check_slides", route_after_check)


@g.node("repair")
def repair(st):
    pt = pages_text()
    key = f"repair_{st.get('visits', {}).get('repair', 0) + 1}"
    st["slides"] = LLM(key, P.repair_prompt(st["evidence"], st["slides"], st["slide_errors"]))["slides"]
    return {"slides": len(st["slides"])}


g.edge("repair", "check_slides")


@g.node("stop_failed")
def stop_failed(st):
    st["status_final"] = f"failed: 修正 {C.MAX_REPAIR} 次仍未通過檢查"
    return {}


g.edge("stop_failed", END)


# ── 5. 產生簡報 + 檢查 HTML ───────────────────────────────────
@g.node("render_html")
def render_html(st):
    out = ROOT / "output" / f"slides_{st['run']}.html"
    out.parent.mkdir(exist_ok=True)
    out.write_text(R.render(st["slides"], C.OBJECTIVES, C.TOPIC, st["evidence"], load_raw()), encoding="utf-8")
    st["output"] = str(out.relative_to(ROOT))
    return {"output": st["output"]}


g.edge("render_html", "check_html")


class _Counter(HTMLParser):
    def __init__(self):
        super().__init__()
        self.sections, self.ext, self.quiz = 0, [], 0

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if tag == "section":
            self.sections += 1
        if tag in ("script", "link", "img") and re.match(r"https?://", a.get("src") or a.get("href") or ""):
            self.ext.append(tag)
        if "quiz" in (a.get("class") or ""):
            self.quiz += 1


@g.node("check_html")
def check_html(st):
    c = _Counter()
    c.feed((ROOT / st["output"]).read_text(encoding="utf-8"))
    errs = []
    if c.sections != len(st["slides"]) + 1:
        errs.append(f"section 數 {c.sections} ≠ 投影片 {len(st['slides'])}+1")
    if c.ext:
        errs.append(f"有外部資源 {c.ext}")
    st["html_errors"] = errs
    st["status_final"] = "done" if not errs else f"failed: {errs}"
    return {"html_errors": errs, "sections": c.sections}


g.edge("check_html", END)


def main():
    global LLM
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="v2")
    ap.add_argument("--llm", default="agent", choices=["agent", "anthropic"])
    ap.add_argument("--resume", action="store_true")
    a = ap.parse_args()
    run_dir = ROOT / "runs" / a.run
    run_dir.mkdir(parents=True, exist_ok=True)
    LLM = make_llm(a.llm, run_dir)
    sp = run_dir / "state.json"
    st = json.loads(sp.read_text()) if a.resume and sp.exists() else {"run": a.run}
    print(f"[graph] run={a.run} start={st.get('_next', 'load_wiki')}")
    st = g.run(st, "load_wiki", run_dir)
    print(f"[graph] status = {st['status']}")


if __name__ == "__main__":
    main()
