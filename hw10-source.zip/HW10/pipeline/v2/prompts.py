"""LLM 節點的 prompt 模板。"""
import json
import config as C

SCHEMA = """每張投影片 JSON：
{"id":"s01","kind":"title|content|flow|compare|timeline|quiz|summary","objective":"O1..O5 或 null",
 "title":"...","subtitle":"(可選)",
 "bullets":[{"text":"≤60字","cite":["claim id，如 rt2#3"],"type":"fact|inference|analogy"}],
 "defines":[{"term":"術語(須與術語表同名)","def":"一句白話解釋"}],
 "flow":[{"label":"...","text":"..."}],                      (kind=flow)
 "table":{"columns":[...],"rows":[[...]],"cite":[...]},       (kind=compare)
 "timeline":[{"year":"2023","name":"RT-2","text":"...","cite":[...]}], (kind=timeline)
 "quiz":{"q":"...","options":["..."],"answer":0,"explain":"...","cite":[...]}, (kind=quiz)
 "note":"講者備註"}"""

RULES = f"""規則：
1. 只能使用下方 Evidence pack 的 claim；每個 bullet / 表格 / 時間線 / quiz 解說都要 cite claim id（如 rt2#3）。
2. 所有數字必須出現在被 cite 的 claim 中。引用 (inference) claim 的句子必須標 type=inference（畫面上會標「推論」）；
   自己的比喻標 type=analogy（不需 cite，不可含數字）。
3. 觀眾：{C.AUDIENCE}。下列術語第一次出現的那張投影片必須放進 defines：{list(C.TERMS)}。
4. 每張最多 {C.MAX_BULLETS} 個 bullet，每個 ≤{C.MAX_BULLET_CHARS} 字；總張數 {C.SLIDE_RANGE[0]}–{C.SLIDE_RANGE[1]}。
5. 第一張 kind=title，至少 1 張 quiz、1 張 summary；每個學習目標至少 1 張。
6. 繁體中文，術語保留英文。只輸出 JSON。"""


def objectives_text():
    return "\n".join(f"- {k}: {v[0]}" for k, v in C.OBJECTIVES.items())


def context_text(evidence):
    """v2：不再貼整頁，而是貼帶 id 的 claim（fact / inference 分開標示）。"""
    lines, cur = [], None
    for cid, c in evidence.items():
        if c["page"] != cur:
            cur = c["page"]
            lines.append(f"\n=== [[{cur}]] ===")
        lines.append(f"[{cid}] ({c['kind']}) {c['text']}")
    return "\n".join(lines)


def outline_prompt(evidence, index):
    return f"""你是教學簡報設計者。主題：{C.TOPIC}
學習目標：
{objectives_text()}

Wiki index：
{index}

Evidence pack（query 節點取回的 claim）：
{context_text(evidence)}

請先規劃大綱，輸出 JSON：{{"slides":[{{"id":"s01","kind":"...","objective":"O1","title":"...","claims":["rt2#3"],
"introduces":["這張會解釋的術語"],"purpose":"這張要讓觀眾懂什麼"}}]}}
術語表：{list(C.TERMS)}——標題或目的提到某術語時，這張或更早的投影片必須 introduces 它。
{RULES}"""


def draft_prompt(evidence, outline):
    return f"""依照大綱把每張投影片寫成完整內容。主題：{C.TOPIC}
大綱：
{json.dumps(outline, ensure_ascii=False, indent=1)}

Evidence pack：
{context_text(evidence)}

{SCHEMA}
{RULES}
輸出 JSON：{{"slides":[...]}}"""


def repair_prompt(evidence, slides, errors):
    return f"""下列投影片沒有通過自動檢查。請只修正有問題的地方，其餘保持不變，輸出完整的 {{"slides":[...]}}。
檢查錯誤：
{json.dumps(errors, ensure_ascii=False, indent=1)}

目前投影片：
{json.dumps(slides, ensure_ascii=False, indent=1)}

Evidence pack：
{context_text(evidence)}

{SCHEMA}
{RULES}"""


def outline_repair_prompt(evidence, index, outline, errors):
    return f"""大綱沒有通過檢查，請修正後輸出完整 {{"slides":[...]}}（格式同前）。
錯誤：
{json.dumps(errors, ensure_ascii=False, indent=1)}
目前大綱：
{json.dumps(outline, ensure_ascii=False, indent=1)}
""" + outline_prompt(evidence, index)
