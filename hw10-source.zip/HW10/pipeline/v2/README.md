v2 graph 的原始程式（封存，對照用）。現行版本是 pipeline/graph.py（v3）。
v1 封存在 pipeline/v1/。封存檔 import 的是現行的共用模組，不保證可以直接重跑；當時的執行紀錄在 runs/v1、runs/v2。
