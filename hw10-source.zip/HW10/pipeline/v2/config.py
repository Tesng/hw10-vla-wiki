"""簡報任務設定：主題、觀眾、學習目標（含檢索關鍵字）、需定義的術語、檢查門檻。"""
TOPIC = "VLA（Vision-Language-Action）模型是什麼？"
AUDIENCE = "修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學"

OBJECTIVES = {
    "O1": ("說出 VLA 的定義，以及它和 LLM / VLM 的關係", ["vla", "VLM", "定義", "rt2"]),
    "O2": ("理解動作怎麼變成模型輸出：離散 token vs 連續動作", ["動作", "token", "bin", "diffusion", "flow"]),
    "O3": ("知道 VLA 的資料從哪來：跨機體資料與 co-fine-tuning", ["embodiment", "co-fine", "OXE", "資料"]),
    "O4": ("理解為什麼需要 action chunking 才能高頻控制", ["chunk", "Hz", "頻率"]),
    "O5": ("能比較 RT-1 → π0 的演進與代表模型", ["timeline", "時間線", "OpenVLA", "Octo", "π0"]),
}

# 觀眾不熟的術語：第一次出現的那張投影片必須在 defines 中解釋
TERMS = {
    "VLA": r"\bVLA\b",
    "VLM": r"\bVLM\b",
    "policy": r"\bpolicy\b|策略",
    "embodiment": r"embodiment|機體",
    "DoF": r"DoF|自由度",
    "co-fine-tuning": r"co-fine-tun",
    "action chunk": r"chunk",
    "diffusion": r"diffusion|擴散",
    "flow matching": r"flow matching",
    "控制頻率": r"\bHz\b|控制頻率",
    "正遷移": r"positive transfer|正遷移",
}

MAX_BULLETS = 5
MAX_BULLET_CHARS = 60
SLIDE_RANGE = (10, 16)
MAX_REPAIR = 2
TOP_K_PER_OBJECTIVE = 4
