"""v3 的 prompt。每個 LLM 節點只看得到它該看的東西（講義：每一關只能看什麼、改什麼）。"""
import json
import config as C

KIND_SCHEMA = {
    "title": '{"id","kind":"title","title","subtitle","defines":[{"term","def"}],"note"}',
    "content": '{"id","kind":"content","objective","title","bullets":[{"text","cite":["claim id"],"type":"fact|inference|analogy"}],"defines":[{"term","def"}],"note"}',
    "flow": '{"id","kind":"flow","objective","title","flow":[{"label","text"}],"bullets":[...同 content],"defines":[...],"note"}',
    "compare": '{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}',
    "timeline": '{"id","kind":"timeline","objective","title","timeline":[{"year","name","text","cite":["claim id"]}],"bullets":[...],"defines":[...],"note"}',
    "quiz": '{"id","kind":"quiz","objective","title","quiz":{"q","options":["A","B","C","D"],"answer":索引,"explain","cite":["claim id"]},"note"}',
    "summary": '{"id","kind":"summary","title","bullets":[...同 content],"note"}',
}


EXAMPLE = {
    "id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？",
    "bullets": [
        {"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"},
        {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"},
        {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"},
        {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}],
    "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}],
    "note": "先問觀眾：文字是 token，那動作呢？"}


def cards_text(evidence, ids=None):
    lines, cur = [], None
    for cid, c in evidence.items():
        if ids is not None and cid not in ids:
            continue
        if c["page"] != cur:
            cur = c["page"]
            lines.append(f"\n=== [[{cur}]] ===")
        flag = "inference" if c["kind"] == "inference" else ("conflict" if c["text"].startswith("⚠") else "fact")
        lines.append(f"[{cid}] ({flag}) {c['text']}")
    return "\n".join(lines)


def objectives_text():
    return "\n".join(f"- {k}: {v[0]}" for k, v in C.OBJECTIVES.items())


def outline_prompt(evidence, index, feedback=None, prev=None, errors=None):
    extra = ""
    if prev is not None:
        extra = f"""
上一版大綱：
{json.dumps(prev, ensure_ascii=False, indent=1)}
"""
    if errors:
        extra += f"\n程式檢查錯誤（全部都要修好）：\n{json.dumps(errors, ensure_ascii=False, indent=1)}\n"
    if feedback:
        extra += f"\n人工審閱意見（優先處理）：\n{feedback}\n"
    return f"""你是教學簡報設計者。主題：{C.TOPIC}
觀眾：{C.AUDIENCE}
學習目標：
{objectives_text()}

Wiki index：
{index}

證據卡（只能使用這些 claim；每條前面是 claim id）：
{cards_text(evidence)}
{extra}
請規劃 {C.SLIDE_RANGE[0]}–{C.SLIDE_RANGE[1]} 張投影片的大綱，輸出 JSON：
{{"slides":[{{"id":"s01","kind":"title|content|flow|compare|timeline|quiz|summary","objective":"O1..O5 或 null",
"title":"...","claims":["這張會用到的 claim id"],"introduces":["這張要解釋的術語"],"purpose":"這張要讓觀眾懂什麼"}}]}}
規則：
1. 第一張 kind=title；至少 1 張 quiz、1 張 summary；O1–O5 每個至少 1 張；教學順序由淺入深。
2. content/flow/compare/timeline 每張至少 3 條 claim（內容太薄撐不起一頁）；quiz 至少 2 條（正解與解說要有證據）；claim id 必須完全照抄證據卡。
   compare 表格的每一列都要比較「同一類東西」，欄位只放證據裡有的資訊，不要用「—」填空。
3. 術語表：{list(C.TERMS)}。某張的標題或 purpose 用到術語時，該張或更早的投影片必須在 introduces 裡放這個術語。
4. 標成 (conflict) 的 claim 代表論文之間有矛盾，若使用要把兩邊都講清楚。
5. 繁體中文，術語保留英文。"""


def slide_prompt(plan, cards, must_define, already_defined, feedback=None, prev=None):
    fb = ""
    if prev is not None:
        fb = f"\n你上一版的這頁：\n{json.dumps(prev, ensure_ascii=False, indent=1)}\n"
    if feedback:
        fb += f"\n這頁沒有通過檢查，只修正以下問題：\n{json.dumps(feedback, ensure_ascii=False, indent=1)}\n"
    return f"""你在寫教學簡報「{C.TOPIC}」中的其中一頁。觀眾：{C.AUDIENCE}
這頁的大綱：
{json.dumps(plan, ensure_ascii=False, indent=1)}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：
{cards}

這頁必須在 defines 解釋的術語：{sorted(must_define) or "無"}
之前投影片已解釋過、不必再解釋的術語：{sorted(already_defined) or "無"}
{fb}
輸出這一頁的 JSON，欄位：{KIND_SCHEMA.get(plan.get("kind"), KIND_SCHEMA["content"])}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{json.dumps(EXAMPLE, ensure_ascii=False)}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 {C.MAX_BULLETS} 個 bullet，每個 ≤{C.MAX_BULLET_CHARS} 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。"""


def review_prompt(slide_view, cited):
    return f"""你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
{slide_view}

證據（claim id → 原文）：
{cited}

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
- inference（推論）句也要查：推論不能和證據矛盾（例如證據說 A 比較慢，推論卻說 A 提升速度）
真正的比喻不用查證。
若這頁是 quiz：只有 answer 指到的那個選項必須正確且有證據支持；其他選項是「故意設計的錯誤選項」，本來就應該是錯的，
不要要求把它們改成正確。要檢查的是：正解有沒有證據支持、是不是剛好只有一個選項正確（如果有兩個以上都對，type 用 misleading）、
解說有沒有講清楚為什麼其他選項錯。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{{"verdict":"pass|fail","issues":[{{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}}]}}
沒有問題就輸出 {{"verdict":"pass","issues":[]}}。"""
