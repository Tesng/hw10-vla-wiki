"""確定性檢查（不靠 LLM）。每個錯誤都帶 slide id，graph 依此「錯在哪一頁就退回哪一頁」。"""
from __future__ import annotations
import re
import config as C
from wiki import numbers, normalize

TYPO_RE = re.compile(r"(與|的|和|及|是|在|了)\1")
KINDS = {"title", "content", "flow", "compare", "timeline", "quiz", "summary"}
NEEDS_CLAIMS = {"content", "flow", "compare", "timeline"}


def slide_text(s: dict) -> str:
    parts = [s.get("title", ""), s.get("subtitle", "")]
    parts += [b.get("text", "") for b in s.get("bullets", [])]
    for st in s.get("flow", []):
        parts += [st.get("label", ""), st.get("text", "")]
    t = s.get("table") or {}
    parts += [str(c) for c in t.get("columns", [])] + [str(c) for r in t.get("rows", []) for c in r]
    parts += [f"{i.get('name','')} {i.get('text','')}" for i in s.get("timeline", [])]
    q = s.get("quiz") or {}
    parts += [q.get("q", "")] + [str(o) for o in q.get("options", [])] + [q.get("explain", "")]
    return "\n".join(parts)


def grounded_units(s: dict):
    """所有需要出處的單位：(文字, 引用, 位置, 型別)。"""
    for i, b in enumerate(s.get("bullets", [])):
        if b.get("type", "fact") in ("fact", "inference"):
            yield b.get("text", ""), b.get("cite", []), f"bullet {i+1}", b.get("type", "fact")
    t = s.get("table")
    if t:
        for r in t.get("rows", []):
            yield " ".join(map(str, r)), t.get("cite", []), "table row", "fact"
    for it in s.get("timeline", []):
        yield it.get("text", ""), it.get("cite", []), f"timeline {it.get('name')}", "fact"
    q = s.get("quiz")
    if q:
        yield q.get("explain", ""), q.get("cite", []), "quiz explain", "fact"


def terms_in(text: str) -> set[str]:
    text = normalize(text)
    return {t for t, rx in C.TERMS.items() if re.search(rx, text, re.I)}


def check_outline(outline: list[dict], evidence: dict) -> list[dict]:
    errs = []
    E = lambda sid, typ, msg: errs.append({"slide": sid, "type": typ, "msg": msg})
    lo, hi = C.SLIDE_RANGE
    if not lo <= len(outline) <= hi:
        E("-", "slide_count", f"大綱 {len(outline)} 張，需介於 {lo}–{hi}")
    for o in C.OBJECTIVES:
        if o not in {s.get("objective") for s in outline}:
            E("-", "objective_uncovered", f"{o} 沒有投影片")
    if outline and outline[0].get("kind") != "title":
        E(outline[0].get("id"), "structure", "第一張必須是 title")
    kinds = [s.get("kind") for s in outline]
    if "quiz" not in kinds:
        E("-", "structure", "至少要有 1 張 quiz")
    if "summary" not in kinds:
        E("-", "structure", "缺少 summary")
    ids = [s.get("id") for s in outline]
    if len(set(ids)) != len(ids):
        E("-", "schema", "投影片 id 重複")
    introduced = set()
    for s in outline:
        sid = s.get("id")
        if s.get("kind") not in KINDS:
            E(sid, "schema", f"kind={s.get('kind')} 不合法")
        for c in s.get("claims", []):
            if c not in evidence:
                E(sid, "bad_cite", f"大綱引用了證據卡裡沒有的 claim [{c}]")
        if s.get("kind") == "quiz" and len(s.get("claims", [])) < 2:
            E(sid, "thin_slide", "quiz 至少要指定 2 條 claim（正解和解說要有證據；v5 的 quiz 沒有 claim，寫稿模型只好自己編 claim0）")
        if TYPO_RE.search(s.get("title", "")):
            E(sid, "typo", f"標題有重複字：{TYPO_RE.search(s.get('title', '')).group(0)}")
        if s.get("kind") in NEEDS_CLAIMS and len(s.get("claims", [])) < 3:
            E(sid, "thin_slide", f"內容頁只規劃 {len(s.get('claims', []))} 條 claim，至少要 3 條才撐得起一頁教學內容")
        introduced |= set(s.get("introduces", []))
        for t in terms_in(s.get("title", "") + " " + s.get("purpose", "")):
            if t not in introduced:
                E(sid, "term_order", f"標題/目的用到「{t}」，但這張或之前沒有 introduces 它")
                introduced.add(t)
    return errs


def validate_schema(s, plan) -> list[dict]:
    """先檢查 JSON 結構（格式錯就不往下檢查內容，避免程式崩潰）。"""
    sid = plan["id"]
    errs = []
    E = lambda msg: errs.append({"slide": sid, "type": "schema", "msg": msg})
    if not isinstance(s, dict):
        return [{"slide": sid, "type": "schema", "msg": "輸出必須是一個 JSON 物件（這一頁）"}]
    for i, b in enumerate(s.get("bullets", []) or [], 1):
        if not isinstance(b, dict):
            E(f'bullets 第 {i} 項必須是物件 {{"text": "...", "cite": ["claim id"], "type": "fact|inference|analogy"}}，不能是字串')
        elif re.search(r"cite\s*[:：]|\[[a-z0-9\-]+#\d+\]", str(b.get("text", ""))):
            E(f"bullets 第 {i} 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]")
        elif not isinstance(b.get("cite", []), list):
            E(f"bullets 第 {i} 項的 cite 必須是陣列")
        elif b.get("type", "fact") not in ("fact", "inference", "analogy"):
            E(f"bullets 第 {i} 項的 type 是「{b.get('type')}」，只能是 fact、inference 或 analogy（矛盾的內容請用 fact 並把兩邊都寫出來）")
    for i, d in enumerate(s.get("defines", []) or [], 1):
        if not (isinstance(d, dict) and "term" in d and "def" in d):
            E(f'defines 第 {i} 項必須是物件 {{"term": "術語", "def": "白話解釋"}}')
    t = s.get("table")
    if t is not None and not (isinstance(t, dict) and isinstance(t.get("rows"), list) and all(isinstance(r, list) for r in t["rows"])):
        E('table 必須是 {"columns": [...], "rows": [[...], ...], "cite": [...]}')
    for k in ("flow", "timeline"):
        if any(not isinstance(x, dict) for x in s.get(k, []) or []):
            E(f"{k} 的每一項都必須是物件")
    q = s.get("quiz")
    if q is not None and not isinstance(q, dict):
        E("quiz 必須是物件")
    elif isinstance(q, dict) and re.search(r"[a-z][a-z0-9\-]*#\d+", str(q.get("explain", ""))):
        E("quiz.explain 裡寫了 claim id；claim id 只能放在 quiz.cite，解說文字不要出現")
    if plan.get("kind") in ("content", "flow", "summary") and not s.get("bullets"):
        E("這種頁面需要 bullets")
    return errs


def check_slide(s: dict, plan: dict, evidence: dict, defined_before: set[str]) -> list[dict]:
    """單頁檢查（逐頁稿節點裡的小圈）。plan = 大綱中這一頁。先驗格式，再驗內容。"""
    errs = validate_schema(s, plan)
    if errs:
        return errs
    sid = plan["id"]
    E = lambda typ, msg: errs.append({"slide": sid, "type": typ, "msg": msg})
    if s.get("kind") != plan.get("kind"):
        E("schema", f"kind 應為 {plan.get('kind')}，實際為 {s.get('kind')}")
    allowed = set(plan.get("claims", []))
    bl = s.get("bullets", [])
    if len(bl) > C.MAX_BULLETS:
        E("too_long", f"{len(bl)} 個 bullet，上限 {C.MAX_BULLETS}")
    for i, b in enumerate(bl, 1):
        if len(b.get("text", "")) > C.MAX_BULLET_CHARS:
            E("too_long", f"bullet {i} 有 {len(b['text'])} 字，上限 {C.MAX_BULLET_CHARS}：請至少刪掉 {len(b['text']) - C.MAX_BULLET_CHARS + 5} 個字，或拆成兩個 bullet")
        if b.get("type") == "analogy" and numbers(b.get("text", "")):
            E("number_in_analogy", f"bullet {i} 是比喻卻含數字")
        if b.get("type") == "analogy" and not re.search(r"像|如同|好比|想像|彷彿|類似|比喻|就好", b.get("text", "")):
            E("disguised_claim", f"bullet {i} 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉")
    if s.get("kind") == "quiz":
        q = s.get("quiz") or {}
        if not (isinstance(q.get("answer"), int) and 0 <= q["answer"] < len(q.get("options", [])) >= 3):
            E("schema", "quiz 需要 ≥3 個選項與合法的 answer 索引")
    for text, cites, where, typ in grounded_units(s):
        if not cites:
            E("uncited", f"{where} 沒有引用 claim")
            continue
        for c in cites:
            if c not in evidence:
                E("bad_cite", f"{where} 引用了不存在的 claim [{c}]")
            elif allowed and c not in allowed:
                E("cite_outside_cards", f"{where} 引用了這頁證據卡以外的 claim [{c}]")
        good = [evidence[c] for c in cites if c in evidence]
        if good:
            miss = numbers(text) - set().union(*(set(g["nums"]) for g in good))
            if miss:
                E("ungrounded_number", f"{where} 的數字 {sorted(miss)} 不在所引 claim {cites} 中")
            if any(g["kind"] == "inference" for g in good):
                if where == "quiz explain" and "推論" not in text:
                    E("inference_as_fact", "quiz 解說用到 (inference) claim：請在解說文字中寫明「（推論）」，或改引用 fact claim")
                elif where == "table row":
                    E("inference_in_table", f"表格只能引用 fact claim；{[c for c in cites if c in evidence and evidence[c]['kind'] == 'inference']} 是推論，請從 table.cite 拿掉，改寫成 bullets 裡 type=inference 的句子")
                elif typ == "fact" and where != "quiz explain":
                    E("inference_as_fact", f"{where} 引用 (推論) claim 卻標成 fact：請把 type 改成 inference")
    m = TYPO_RE.search(slide_text(s))
    if m:
        E("typo", f"有重複字「{m.group(0)}」")
    here = {d.get("term") for d in s.get("defines", [])}
    must = (terms_in(slide_text(s)) | set(plan.get("introduces", []))) - defined_before
    for t in sorted(must - here):
        E("undefined_term", f"術語「{t}」在這頁第一次出現，必須放進 defines")
    return errs


def check_deck(slides: list[dict]) -> list[dict]:
    """整份檢查：術語實際的第一次出現（用最終稿重算）。"""
    errs, defined = [], set()
    for s in slides:
        here = {d.get("term") for d in s.get("defines", [])}
        for t in sorted(terms_in(slide_text(s)) - defined - here):
            errs.append({"slide": s.get("id"), "type": "undefined_term", "msg": f"術語「{t}」第一次出現但沒有定義"})
        defined |= here | terms_in(slide_text(s))
    return errs


def coverage(slides: list[dict], evidence: dict) -> dict:
    used = {c for s in slides for _, cites, _, _ in grounded_units(s) for c in cites if c in evidence}
    raw_avail = {r for c in evidence.values() for r in c["raw"]}
    raw_used = {r for c in used for r in evidence[c]["raw"]}
    return {"claims_used": len(used), "raw_available": sorted(raw_avail), "raw_used": sorted(raw_used),
            "raw_unused": sorted(raw_avail - raw_used)}
