"""讀取 LLM Wiki：解析 frontmatter、內部連結、引用與 bullet。"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
WIKI = ROOT / "wiki"
RAW = ROOT / "raw"

LINK_RE = re.compile(r"\[\[(?!src:)([a-z0-9\-]+)\]\]")
CITE_RE = re.compile(r"\[\[src:([a-z0-9\-]+)\]\]")
NUM_RE = re.compile(r"\d+(?:[.,]\d+)*")
# 名稱中的數字不算「事實數字」
NAME_PATTERNS = [r"RT-\d(?:-X)?", r"π0", r"\b[Pp]i-?0\b", r"Llama ?2", r"DINOv2", r"Bridge v2", r"t5-base",
                 r"EfficientNet-B\d", r"Prismatic-7B", r"Octo-(?:Small|Base)", r"20[12]\d",
                 r"\bO\d\b", r"PaLI-X", r"PaLM-E", r"\[CLS\]", r"6-DoF", r"\bH=", r"v4-128",
                 r"A100-hours", r"\bA\d{3,4}\b", r"RTX \d{4}", r"[①②③④⑤]"]


NAV_RE = re.compile(r"^-\s*(相關|見|細節見|延伸)[：:]?\s*")


def is_nav(line: str) -> bool:
    """純導覽列，如「- 相關：[[a]]、[[b]]」。"""
    rest = LINK_RE.sub("", NAV_RE.sub("", line))
    return bool(NAV_RE.match(line)) and not re.sub(r"[\s、,，與和]", "", rest)


DASHES = dict.fromkeys(map(ord, "\u2010\u2011\u2012\u2013\u2014\u2212\uFE63\uFF0D"), "-")
CLAIM_ID_RE = re.compile(r"[a-z][a-z0-9\-]*#\d+")


def normalize(text: str) -> str:
    """v4：檢查前先正規化。v3 的 Groq 輸出用了不換行連字號「RT‑1」(U+2011)，造成大量誤報。"""
    import unicodedata
    text = unicodedata.normalize("NFKC", str(text)).translate(DASHES)
    return re.sub(r"[\u00A0\u2000-\u200B\u202F\u205F\u3000]", " ", text)


def strip_names(text: str) -> str:
    text = CLAIM_ID_RE.sub(" ", normalize(text))
    text = LINK_RE.sub(" ", text)
    for p in NAME_PATTERNS:
        text = re.sub(p, " ", text)
    return text


def numbers(text: str) -> set[str]:
    return {n.replace(",", "") for n in NUM_RE.findall(strip_names(text))}


@dataclass
class Page:
    name: str
    path: Path
    meta: dict
    body: str
    links: set[str] = field(default_factory=set)
    cites: set[str] = field(default_factory=set)

    @property
    def bullets(self) -> list[str]:
        """事實句：bullet 與表格資料列（略過表頭、分隔列、純導覽列）。"""
        lines = [l.strip() for l in self.body.splitlines()]
        out = []
        for i, l in enumerate(lines):
            if not l.startswith(("- ", "| ")) or set(l) <= set("|-: "):
                continue
            if l.startswith("| ") and i + 1 < len(lines) and set(lines[i + 1]) <= set("|-: ") and lines[i + 1]:
                continue  # 表頭
            if is_nav(l):
                continue
            out.append(l)
        return out


def parse_frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---"):
        return {}, text
    _, fm, body = text.split("---", 2)
    meta = {}
    for line in fm.strip().splitlines():
        k, _, v = line.partition(":")
        v = v.strip()
        if v.startswith("[") and v.endswith("]"):
            v = [x.strip() for x in v[1:-1].split(",") if x.strip()]
        meta[k.strip()] = v
    return meta, body


def load_wiki() -> dict[str, Page]:
    pages = {}
    for p in sorted(WIKI.rglob("*.md")):
        meta, body = parse_frontmatter(p.read_text(encoding="utf-8"))
        name = meta.get("name", p.stem)
        pages[name] = Page(name, p, meta, body, set(LINK_RE.findall(body)), set(CITE_RE.findall(body)))
    return pages


def load_raw() -> dict[str, dict]:
    raw = {}
    for p in sorted(RAW.glob("*.md")):
        meta, body = parse_frontmatter(p.read_text(encoding="utf-8"))
        raw[meta["id"]] = {"meta": meta, "text": body, "path": p}
    return raw


def claims(pages: dict[str, Page], names=None) -> dict[str, dict]:
    """把 wiki 頁拆成可引用的 claim：id = 頁名#序號，kind = fact / inference。"""
    out = {}
    for n in (names or pages):
        p = pages[n]
        if p.meta.get("type") == "meta":
            continue
        for i, b in enumerate(p.bullets, 1):
            text = CITE_RE.sub("", b).lstrip("-| ").strip()
            out[f"{n}#{i}"] = {"page": n, "text": text,
                               "kind": "inference" if "(推論)" in b else "fact",
                               "raw": CITE_RE.findall(b), "nums": sorted(numbers(text))}
    return out
