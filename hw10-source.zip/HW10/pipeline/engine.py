"""極小的 graph 引擎：節點 = 函式(state)，邊 = 固定或條件路由；每個節點後 checkpoint + trace。"""
from __future__ import annotations
import json, time
from pathlib import Path
from llm import WaitingForLLM

END = "__end__"


class Graph:
    def __init__(self):
        self.nodes, self.edges = {}, {}

    def node(self, name):
        def deco(fn):
            self.nodes[name] = fn
            return fn
        return deco

    def edge(self, src, dst_or_router):
        self.edges[src] = dst_or_router

    def next_of(self, name, state):
        e = self.edges[name]
        return e(state) if callable(e) else e

    def run(self, state: dict, start: str, run_dir: Path) -> dict:
        cur = state.get("_next", start)
        trace = run_dir / "trace.jsonl"
        while cur != END:
            t0 = time.time()
            try:
                out = self.nodes[cur](state) or {}
            except Exception as ex:
                if not isinstance(ex, WaitingForLLM):
                    state["_next"] = cur
                    state["status"] = f"crashed at {cur}: {type(ex).__name__}: {ex}"
                    self.save(state, run_dir)
                    with trace.open("a") as f:
                        f.write(json.dumps({"node": cur, "event": "crash", "error": f"{type(ex).__name__}: {ex}"},
                                           ensure_ascii=False) + "\n")
                    print(f"[graph] 節點 {cur} 當掉，已存 checkpoint，修好後用 --resume 繼續：{ex}")
                    raise
                w = ex
                state["_next"] = cur
                state["status"] = f"waiting:{w}"
                self.save(state, run_dir)
                with trace.open("a") as f:
                    f.write(json.dumps({"node": cur, "event": "wait_llm"}, ensure_ascii=False) + "\n")
                return state
            state.setdefault("visits", {})[cur] = state.get("visits", {}).get(cur, 0) + 1
            nxt = self.next_of(cur, state)
            with trace.open("a") as f:
                f.write(json.dumps({"node": cur, "visit": state["visits"][cur], "ms": int((time.time() - t0) * 1000),
                                    "next": nxt, **out}, ensure_ascii=False) + "\n")
            print(f"  {cur:<14} -> {nxt}   {json.dumps(out, ensure_ascii=False)[:150]}")
            cur = nxt
            state["_next"] = cur
            self.save(state, run_dir)
        state["status"] = state.get("status_final", "done")
        self.save(state, run_dir)
        return state

    @staticmethod
    def save(state, run_dir):
        (run_dir / "state.json").write_text(json.dumps(state, ensure_ascii=False, indent=1), encoding="utf-8")
