"""渲染檢查：投影片在 1280×720 下有沒有溢出。

優先用 Playwright 真的打開 HTML、逐頁量測（講義：產生 HTML → 截圖 → 修版面）；
沒有安裝 Playwright 時，改用字數估算（heuristic），報告中會註明用的是哪一種。
安裝：pip install playwright && python -m playwright install chromium
"""
from __future__ import annotations
import math
from pathlib import Path

W, H = 1280, 720


def measure_playwright(html_path: Path, shots_dir: Path | None = None):
    from playwright.sync_api import sync_playwright
    out = []
    with sync_playwright() as p:
        b = p.chromium.launch()
        pg = b.new_page(viewport={"width": W, "height": H})
        pg.goto(html_path.resolve().as_uri())
        n = pg.evaluate("document.querySelectorAll('section').length")
        for i in range(n):
            pg.evaluate(f"go({i})")
            pg.wait_for_timeout(120)
            r = pg.evaluate("""() => { const s = document.querySelector('section.on');
                const limit = window.innerHeight - 40; let maxB = 0;
                s.querySelectorAll('*').forEach(e => { const b = e.getBoundingClientRect().bottom; if (b > maxB) maxB = b; });
                return {over: Math.max(0, Math.round(maxB - limit)), scroll: s.scrollHeight - s.clientHeight}; }""")
            if shots_dir:
                shots_dir.mkdir(parents=True, exist_ok=True)
                pg.screenshot(path=str(shots_dir / f"slide_{i+1:02d}.png"))
            out.append(max(r["over"], r["scroll"]))
        b.close()
    return out


def estimate(slides: list[dict]):
    """粗估每頁高度（單位：px），超過可用高度就算溢出。"""
    avail = H * 0.85 - 150          # 扣掉標題、上下邊距
    out = []
    for s in slides:
        if s.get("kind") == "title":
            out.append(0)
            continue
        has_aside = bool(s.get("defines"))
        cols = 30 if has_aside else 48
        h = 0
        for b in s.get("bullets", []):
            h += math.ceil(max(1, len(b.get("text", "")) + 4) / cols) * 34 + 14
        h += 120 if s.get("flow") else 0
        t = s.get("table")
        h += (len(t.get("rows", [])) + 1) * 42 + 30 if t else 0
        h += len(s.get("timeline", [])) * 40
        q = s.get("quiz")
        h += 60 + len(q.get("options", [])) * 58 + 60 if q else 0
        if has_aside:  # 右側名詞小卡也要放得下
            h = max(h, len(s["defines"]) * 95)
        out.append(max(0, int(h - avail)))
    return out


def check(html_path: Path, slides: list[dict], shots_dir: Path | None = None):
    """回傳 (method, [每頁溢出 px])；只包含內容頁（不含最後的資料來源頁）。"""
    try:
        res = measure_playwright(html_path, shots_dir)
        return "playwright", res[:len(slides)]
    except Exception as e:  # 沒裝 playwright 或瀏覽器
        return f"heuristic（未使用 Playwright：{type(e).__name__}）", estimate(slides)
