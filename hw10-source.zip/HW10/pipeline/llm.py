"""LLM 後端（只用標準函式庫）。

  groq       讀 HW10/.env 或環境變數的 GROQ_API_KEY；writer 與 reviewer 會選「不同的模型」，
             讓 AI 審查等於開一個新的對話、換一雙眼睛。
  anthropic  讀 ANTHROPIC_API_KEY。
  agent      不呼叫 API：把 prompt 寫成檔案後暫停，由外部 agent 寫 response，再用 --resume 繼續。

每一次呼叫都會把 prompt / response 存在 runs/<id>/llm/，並在 calls.jsonl 記錄模型、token 數與耗時。
"""
from __future__ import annotations
import json, os, re, time, urllib.error, urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent


class WaitingForLLM(Exception):
    pass


class LLMError(Exception):
    pass


def load_dotenv():
    p = ROOT / ".env"
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            k, _, v = line.strip().partition("=")
            if k and v and not k.startswith("#"):
                os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


def extract_json(text: str):
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.S).strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", text, re.S)
    if m:
        text = m.group(1)
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        a, b = text.find("{"), text.rfind("}")
        if a >= 0 and b > a:
            return json.loads(text[a:b + 1])
        raise


class Base:
    def __init__(self, run_dir: Path):
        self.dir = run_dir / "llm"
        self.dir.mkdir(parents=True, exist_ok=True)

    def _paths(self, key):
        return self.dir / f"{key}.prompt.md", self.dir / f"{key}.response.json"

    def _log(self, rec):
        with (self.dir / "calls.jsonl").open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")


class AgentLLM(Base):
    def __call__(self, key, prompt, role="writer"):
        pp, rp = self._paths(key)
        pp.write_text(prompt, encoding="utf-8")
        if not rp.exists():
            raise WaitingForLLM(str(rp))
        return extract_json(rp.read_text(encoding="utf-8"))


class ChatAPI(Base):
    """OpenAI 相容的 chat completions（Groq）。"""
    URL = "https://api.groq.com/openai/v1"
    WRITER_PREF = ["openai/gpt-oss-120b", "llama-3.3-70b-versatile", "moonshotai/kimi-k2-instruct", "qwen/qwen3-32b"]
    # v4：v3 用 gpt-oss-20b 審查，放過了表格欄位錯置與事實錯誤。
    # 改用「不同模型家族、夠大」的 Qwen 當審查者：換一雙眼睛，而且 Groq 的 TPM 額度是按模型分開算的，
    # 寫稿（gpt-oss-120b）和審查各用一份額度，不必互相等。
    REVIEWER_PREF = ["qwen/qwen3.8-27b", "qwen/qwen3-32b", "llama-3.3-70b-versatile", "moonshotai/kimi-k2-instruct",
                     "openai/gpt-oss-120b", "openai/gpt-oss-20b"]

    def __init__(self, run_dir):
        super().__init__(run_dir)
        load_dotenv()
        self.key = os.environ.get("GROQ_API_KEY")
        if not self.key:
            raise LLMError("找不到 GROQ_API_KEY：請在 HW10/.env 寫一行 GROQ_API_KEY=...")
        avail = self.avail = self._models()
        self.models = {
            "writer": os.environ.get("GROQ_WRITER_MODEL") or next((m for m in self.WRITER_PREF if m in avail), None),
        }
        self.models["reviewer"] = os.environ.get("GROQ_REVIEWER_MODEL") or next(
            (m for m in self.REVIEWER_PREF if m in avail), None)
        if not all(self.models.values()):
            raise LLMError(f"Groq 上找不到偏好的模型，可用：{sorted(avail)[:20]}；請用 GROQ_WRITER_MODEL / GROQ_REVIEWER_MODEL 指定")
        self.window = {}   # model -> [(time, tokens)]：沒有 header 時的後備做法
        self.bucket = {}   # model -> (剩餘 tokens, 補滿所需秒數, 記錄時間)：來自 Groq 回應 header
        self.tpm = {}      # model -> 每分鐘 token 上限（從 429 訊息學到；預設 GROQ_TPM 或 8000）
        print(f"[llm] groq writer={self.models['writer']}  reviewer={self.models['reviewer']}")

    def _req(self, path, body=None):
        req = urllib.request.Request(self.URL + path, json.dumps(body).encode() if body else None, {
            "Authorization": f"Bearer {self.key}", "Content-Type": "application/json", "User-Agent": "hw10-graph"})
        return urllib.request.urlopen(req, timeout=180)

    def _fallback(self, role, current):
        pref = self.WRITER_PREF if role == "writer" else self.REVIEWER_PREF
        later = pref[pref.index(current) + 1:] if current in pref else pref
        return next((m for m in later if m in self.avail), None)

    @staticmethod
    def _secs(v):
        """'7.66s' / '1m2.5s' / '450ms' → 秒"""
        if not v:
            return 0.0
        t = 0.0
        for num, unit in re.findall(r"([\d.]+)(ms|m|s|h)", v):
            t += float(num) * {"ms": 0.001, "s": 1, "m": 60, "h": 3600}[unit]
        return t

    def _throttle(self, model, est):
        """v4.1：優先用 Groq 回傳的「剩餘 token / 多久補滿」精準等待（Groq 的額度是連續回補的，
        不需要等滿 60 秒）；沒有 header 時才退回自己算的 60 秒滑動視窗。"""
        b = self.bucket.get(model)
        if b:
            remaining, reset, at = b
            limit = self.tpm.get(model, 8000)
            refill = (time.time() - at) * limit / 60.0          # 經過的時間已經回補的量
            have = min(limit, remaining + refill)
            if have >= est:
                return
            wait = (est - have) * 60.0 / limit + 0.3
            self._log({"event": "throttle", "model": model, "have": int(have), "est": est, "wait": round(wait, 1)})
            print(f"  [llm] 剩 {int(have)} tokens，需要約 {est}，等 {wait:.1f}s")
            time.sleep(wait)
            return
        limit = self.tpm.get(model, int(os.environ.get("GROQ_TPM", 8000))) * 0.85
        while True:
            now = time.time()
            w = self.window.setdefault(model, [])
            w[:] = [(t, n) for t, n in w if now - t < 60]
            used = sum(n for _, n in w)
            if used + est <= limit or not w:
                return
            wait = 60 - (now - w[0][0]) + 0.5
            self._log({"event": "throttle", "model": model, "used": used, "est": est, "wait": round(wait, 1)})
            print(f"  [llm] 本分鐘已用 {used} tokens，先等 {wait:.0f}s 再送（TPM 節流）")
            time.sleep(wait)

    def _models(self):
        return {m["id"] for m in json.load(self._req("/models"))["data"]}

    def __call__(self, key, prompt, role="writer"):
        pp, rp = self._paths(key)
        pp.write_text(prompt, encoding="utf-8")
        model = self.models[role]
        max_tok = 3000 if key.startswith("outline") else (1200 if role == "reviewer" else 2000)
        body = {"model": model, "temperature": 0.3 if role == "writer" else 0.0, "max_tokens": max_tok,
                "messages": [{"role": "system", "content": "你只輸出一個合法的 JSON 物件，不要任何其他文字。"},
                             {"role": "user", "content": prompt}],
                "response_format": {"type": "json_object"}}
        if model.startswith("openai/gpt-oss"):
            body["reasoning_effort"] = "medium" if role == "reviewer" else "low"
        if model.startswith("qwen/"):
            body["reasoning_format"] = "hidden"     # 不要把 <think> 推理過程混進 JSON
        last = None
        for attempt in range(12):
            t0 = time.time()
            est = int(len(prompt) * 0.8) + 900   # 中英混合約 0.8 token/字 + 平均輸出（含推理）
            est = min(est, int(self.tpm.get(body["model"], 8000) * 0.9))   # 估計值不能超過上限，否則永遠等不到
            self._throttle(body["model"], est)
            try:
                resp = self._req("/chat/completions", body)
                h = resp.headers
                if h.get("x-ratelimit-remaining-tokens"):
                    self.tpm[body["model"]] = int(h.get("x-ratelimit-limit-tokens") or self.tpm.get(body["model"], 8000))
                    self.bucket[body["model"]] = (int(h["x-ratelimit-remaining-tokens"]),
                                                  self._secs(h.get("x-ratelimit-reset-tokens")), time.time())
                data = json.load(resp)
                u0 = data.get("usage", {})
                self.window.setdefault(body["model"], []).append((time.time(), u0.get("total_tokens") or est))
                text = data["choices"][0]["message"]["content"] or ""
                rp.write_text(text, encoding="utf-8")
                u = data.get("usage", {})
                self._log({"key": key, "role": role, "model": model, "attempt": attempt + 1,
                           "prompt_tokens": u.get("prompt_tokens"), "completion_tokens": u.get("completion_tokens"),
                           "sec": round(time.time() - t0, 1)})
                try:
                    return extract_json(text)
                except json.JSONDecodeError as e:
                    last = f"JSON 解析失敗：{e}"
                    self._log({"key": key, "event": "bad_json", "attempt": attempt + 1})
                    continue
            except urllib.error.HTTPError as e:
                msg = e.read().decode(errors="ignore")[:300]
                last = f"HTTP {e.code}: {msg}"
                if e.code == 413 or "request too large" in msg.lower() or "reduce your message size" in msg.lower():
                    alt = self._fallback(role, model)
                    self._log({"key": key, "event": "request_too_large", "model": model, "switch_to": alt})
                    if not alt:
                        raise LLMError(last)
                    print(f"  [llm] {model} 單次請求超過 token 上限，改用 {alt}")
                    model = body["model"] = self.models[role] = alt
                    body.pop("reasoning_effort", None)
                    if alt.startswith("openai/gpt-oss"):
                        body["reasoning_effort"] = "low"
                    continue
                if e.code == 429:
                    m = re.search(r"Limit (\d+)", msg)
                    if m and "per minute" in msg:
                        self.tpm[body["model"]] = int(m.group(1))
                    m2 = re.search(r"try again in ([\d.]+)s", msg)
                    wait = max(float(e.headers.get("retry-after") or 0), float(m2.group(1)) if m2 else 0, 5.0) + 2
                    if "per day" in msg.lower() or "(TPD)" in msg or "(RPD)" in msg:
                        raise LLMError("已達 Groq 每日額度上限（TPD/RPD），請明天再 --resume，或換模型：" + msg[:200])
                    self._log({"key": key, "event": "rate_limited", "wait": wait})
                    print(f"  [llm] 429 rate limit，等 {wait:.0f}s")
                    time.sleep(min(wait, 90))
                    continue
                if e.code == 400 and "reasoning" in msg.lower() and ("reasoning_format" in body or "reasoning_effort" in body):
                    body.pop("reasoning_format", None); body.pop("reasoning_effort", None)
                    self._log({"key": key, "event": "reasoning_param_unsupported_retry"})
                    continue
                if e.code == 400 and "json" in msg.lower() and "response_format" in body:
                    body.pop("response_format")
                    self._log({"key": key, "event": "json_mode_unsupported_retry"})
                    continue
                raise LLMError(last)
            except (TimeoutError, OSError) as e:
                # v5：大請求遇到 read timeout 直接當掉 → 網路錯誤改成退避重試
                wait = min(10 * (attempt + 1), 60)
                last = f"{type(e).__name__}: {e}"
                self._log({"key": key, "event": "network_retry", "error": last, "wait": wait})
                print(f"  [llm] 網路逾時／連線錯誤（{last[:60]}），{wait}s 後重試")
                time.sleep(wait)
                continue
        raise LLMError(f"{key} 失敗：{last}")


class AnthropicLLM(Base):
    def __init__(self, run_dir):
        super().__init__(run_dir)
        load_dotenv()
        self.model = os.environ.get("LLM_MODEL", "claude-sonnet-4-5")

    def __call__(self, key, prompt, role="writer"):
        pp, rp = self._paths(key)
        pp.write_text(prompt, encoding="utf-8")
        body = json.dumps({"model": self.model, "max_tokens": 4096,
                           "messages": [{"role": "user", "content": prompt}]}).encode()
        req = urllib.request.Request("https://api.anthropic.com/v1/messages", body, {
            "x-api-key": os.environ["ANTHROPIC_API_KEY"], "anthropic-version": "2023-06-01",
            "content-type": "application/json"})
        text = json.load(urllib.request.urlopen(req))["content"][0]["text"]
        rp.write_text(text, encoding="utf-8")
        return extract_json(text)


def make_llm(kind: str, run_dir: Path):
    if kind == "groq":
        return ChatAPI(run_dir)
    if kind == "anthropic":
        return AnthropicLLM(run_dir)
    if kind == "fake":
        import importlib.util, sys
        spec = importlib.util.spec_from_file_location("fake_llm", ROOT / "tests" / "fake_llm.py")
        mod = importlib.util.module_from_spec(spec); spec.loader.exec_module(mod)
        return mod.FakeLLM(run_dir)
    return AgentLLM(run_dir)


if __name__ == "__main__":
    # python3 pipeline/llm.py           連線測試
    # python3 pipeline/llm.py --models  列出可用的對話模型，以及每個模型每分鐘的 token 額度（TPM）
    import sys, tempfile
    api = ChatAPI(Path(tempfile.mkdtemp()))
    if "--models" in sys.argv:
        skip = ("whisper", "tts", "guard", "playai", "orpheus", "prompt-guard", "distil")
        rows = []
        for m in sorted(api.avail):
            if any(k in m for k in skip):
                continue
            try:
                r = api._req("/chat/completions", {"model": m, "max_tokens": 1,
                                                    "messages": [{"role": "user", "content": "hi"}]})
                rows.append((int(r.headers.get("x-ratelimit-limit-tokens") or 0), m,
                             r.headers.get("x-ratelimit-limit-requests")))
            except (TimeoutError, OSError) as e:
                if isinstance(e, urllib.error.HTTPError):
                    raise
                # v5：大請求遇到 read timeout 直接當掉 → 網路錯誤改成退避重試
                wait = min(10 * (attempt + 1), 60)
                last = f"{type(e).__name__}: {e}"
                self._log({"key": key, "event": "network_retry", "error": last, "wait": wait})
                print(f"  [llm] 網路逾時／連線錯誤（{last[:60]}），{wait}s 後重試")
                time.sleep(wait)
                continue
            except urllib.error.HTTPError as e:
                rows.append((0, m, f"HTTP {e.code}"))
        print(f"{'TPM':>8}  {'RPD':>6}  model")
        for tpm, m, rpd in sorted(rows, reverse=True):
            print(f"{tpm:>8}  {str(rpd):>6}  {m}")
    else:
        print("可用模型數：", len(api.avail))
        print("測試回覆：", api("ping", '請輸出 {"ok": true, "msg": "哈囉"}', role="reviewer"))
