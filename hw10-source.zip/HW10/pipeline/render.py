"""把 slides JSON 渲染成單一 HTML 簡報（無外部依賴，←/→ 換頁，N 顯示講者備註）。"""
from __future__ import annotations
import html, json

def E(x):
    """render 不改內容，但 LLM 可能把 year 輸出成數字（v4 實跑：2022 是 int）→ 一律轉成字串再跳脫。"""
    return html.escape("" if x is None else str(x))

CSS = r"""
*{box-sizing:border-box;margin:0;padding:0}
:root{--bg:#0f1419;--panel:#161d26;--ink:#e8edf2;--mut:#93a1b0;--acc:#4fb3a9;--acc2:#e0a458;--line:#2a3542}
html,body{height:100%;background:var(--bg);color:var(--ink);font-family:-apple-system,"PingFang TC","Noto Sans TC","Microsoft JhengHei",sans-serif}
.deck{position:relative;height:100vh;overflow:hidden}
section{position:absolute;inset:0;padding:6vh 7vw 9vh;display:none;flex-direction:column;gap:2.4vh}
section.on{display:flex;animation:in .35s ease}
@keyframes in{from{opacity:0;transform:translateY(8px)}to{opacity:1;transform:none}}
.obj{font-size:13px;letter-spacing:.08em;color:var(--acc)}
h1{font-size:clamp(34px,5.2vw,64px);line-height:1.15}
h2{font-size:clamp(26px,3.4vw,42px);line-height:1.2}
.sub{font-size:clamp(16px,1.8vw,22px);color:var(--mut)}
.body{display:grid;grid-template-columns:1fr minmax(240px,32%);gap:3vw;flex:1;min-height:0}
.body.full{grid-template-columns:1fr}
ul.b{list-style:none;display:flex;flex-direction:column;gap:1.6vh;font-size:clamp(17px,1.75vw,24px);line-height:1.5}
ul.b li{padding-left:1.1em;position:relative}
ul.b li:before{content:"";position:absolute;left:0;top:.62em;width:.42em;height:.42em;border-radius:50%;background:var(--acc)}
ul.b li.analogy:before{background:var(--acc2)}
ul.b li.analogy{color:#f3d7b0}
.cite{font-size:.62em;vertical-align:super;margin-left:.3em}
.cite a{color:var(--mut);text-decoration:none;border:1px solid var(--line);border-radius:6px;padding:0 .35em;margin-right:.2em}
.cite a:hover{color:var(--acc);border-color:var(--acc)}
aside.defs{display:flex;flex-direction:column;gap:1.2vh;align-self:start}
.def{background:var(--panel);border:1px solid var(--line);border-left:3px solid var(--acc2);border-radius:10px;padding:1.2vh 1vw}
.def b{color:var(--acc2);display:block;font-size:15px;margin-bottom:.3em}
.def span{font-size:15px;color:var(--ink);line-height:1.5}
.defs .h{font-size:12px;color:var(--mut);letter-spacing:.1em}
.flow{display:flex;align-items:stretch;gap:0;flex-wrap:wrap}
.step{flex:1;min-width:150px;background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:2vh 1.2vw;position:relative;margin-right:2.2vw}
.step:not(:last-child):after{content:"→";position:absolute;right:-2vw;top:50%;transform:translateY(-50%);color:var(--acc);font-size:24px}
.step b{display:block;color:var(--acc);margin-bottom:.4em;font-size:clamp(16px,1.5vw,20px)}
.step span{font-size:clamp(14px,1.25vw,17px);color:var(--mut);line-height:1.5}
table{border-collapse:collapse;width:100%;font-size:clamp(14px,1.35vw,18px)}
th,td{border-bottom:1px solid var(--line);padding:1.1vh .8vw;text-align:left}
th{color:var(--acc);font-weight:600}
td:first-child{font-weight:600}
.tl{display:flex;flex-direction:column;gap:1.4vh;border-left:2px solid var(--line);padding-left:1.6vw}
.tli{position:relative}
.tli:before{content:"";position:absolute;left:calc(-1.6vw - 7px);top:.45em;width:12px;height:12px;border-radius:50%;background:var(--acc)}
.tli .y{color:var(--acc2);font-size:14px;margin-right:.6em}
.tli b{font-size:clamp(16px,1.5vw,20px)}
.tli span{color:var(--mut);font-size:clamp(14px,1.3vw,18px);margin-left:.6em}
.quiz .q{font-size:clamp(19px,2vw,27px);margin-bottom:2vh}
.opt{display:block;width:100%;text-align:left;background:var(--panel);color:var(--ink);border:1px solid var(--line);border-radius:10px;padding:1.4vh 1.2vw;margin-bottom:1.2vh;font-size:clamp(15px,1.5vw,20px);cursor:pointer;font-family:inherit}
.opt:hover{border-color:var(--acc)}
.opt.right{border-color:#5cc28a;background:#173226}.opt.wrong{border-color:#d9686a;background:#3a1d20}
.explain{display:none;margin-top:1vh;color:var(--mut);font-size:clamp(15px,1.4vw,19px);line-height:1.5}
.explain.show{display:block}
.title-s{justify-content:center}
.title-s .tag{color:var(--acc);font-size:15px;letter-spacing:.2em}
.note{display:none;position:absolute;left:7vw;right:7vw;bottom:8vh;background:#0b0f13ee;border:1px dashed var(--acc2);border-radius:10px;padding:1.4vh 1.2vw;color:#f3d7b0;font-size:15px;line-height:1.6}
body.notes .note{display:block}
.bar{position:fixed;left:0;bottom:0;height:3px;background:var(--acc);transition:width .3s}
.hud{position:fixed;right:2vw;bottom:2.2vh;color:var(--mut);font-size:13px;display:flex;gap:1em;align-items:center}
.hud button{background:none;border:1px solid var(--line);color:var(--mut);border-radius:6px;padding:.2em .7em;cursor:pointer}
.src li{font-size:clamp(13px,1.15vw,16px)!important}
.src a{color:var(--acc)}
.src{display:grid;grid-template-columns:1fr 1fr;gap:1.4vh 3vw!important}
.src small{display:block;color:var(--mut);font-size:.85em;margin-top:.2em}
.inf{font-size:.6em;color:var(--acc2);border:1px solid var(--acc2);border-radius:5px;padding:0 .35em;margin-left:.4em;vertical-align:middle}
ul.b li.inference:before{background:transparent;border:1.5px solid var(--acc2)}
.title-s .defs{flex-direction:row;margin-top:3vh}.title-s .def{max-width:46%}
.legend{font-size:12px;color:var(--mut)}
"""

JS = r"""
const S=[...document.querySelectorAll('section')];let i=0;
function go(n){i=Math.max(0,Math.min(S.length-1,n));S.forEach((s,k)=>s.classList.toggle('on',k===i));
document.querySelector('.bar').style.width=((i+1)/S.length*100)+'%';document.getElementById('pg').textContent=(i+1)+' / '+S.length;
history.replaceState(null,'','#'+(i+1));}
document.addEventListener('keydown',e=>{if(['ArrowRight','PageDown',' '].includes(e.key)){e.preventDefault();go(i+1)}
else if(['ArrowLeft','PageUp'].includes(e.key))go(i-1);else if(e.key==='n'||e.key==='N')document.body.classList.toggle('notes');
else if(e.key==='Home')go(0);else if(e.key==='End')go(S.length-1);});
document.querySelectorAll('.cite a').forEach(a=>a.addEventListener('click',e=>{e.preventDefault();go(S.length-1)}));
document.querySelectorAll('.quiz').forEach(q=>{const ans=+q.dataset.answer;q.querySelectorAll('.opt').forEach((b,k)=>b.addEventListener('click',()=>{
q.querySelectorAll('.opt').forEach((x,j)=>x.classList.toggle('right',j===ans));if(k!==ans)b.classList.add('wrong');q.querySelector('.explain').classList.add('show');}))});
let tx=null;document.addEventListener('touchstart',e=>tx=e.touches[0].clientX);document.addEventListener('touchend',e=>{if(tx===null)return;const d=e.changedTouches[0].clientX-tx;if(Math.abs(d)>50)go(i+(d<0?1:-1));tx=null});
go((parseInt(location.hash.slice(1))||1)-1);
"""


EV = {}


def cites(c):
    """claim id → 顯示頁名；滑鼠停留顯示 claim 原文。"""
    if not c:
        return ""
    chips = []
    for x in c:
        ev = EV.get(x, {})
        warn = "⚠ " if ev.get("text", "").startswith("⚠") else ""
        chips.append(f'<a href="#src" title="[{E(x)}] {E(ev.get("text", ""))}">{warn}{E(x)}</a>')
    return '<span class="cite">' + "".join(chips) + "</span>"


def render_slide(s, objectives):
    k = s.get("kind")
    obj = s.get("objective")
    head = f'<div class="obj">{E(obj)} · {E(objectives[obj][0])}</div>' if obj in objectives else ""
    defs = s.get("defines", [])
    aside = ""
    if defs:
        aside = '<aside class="defs"><div class="h">名詞小卡</div>' + "".join(
            f'<div class="def"><b>{E(d["term"])}</b><span>{E(d["def"])}</span></div>' for d in defs) + "</aside>"
    note = f'<div class="note">🗒 {E(s["note"])}</div>' if s.get("note") else ""
    if k == "title":
        tdefs = "".join(f'<div class="def"><b>{E(d["term"])}</b><span>{E(d["def"])}</span></div>' for d in defs)
        return (f'<section class="title-s"><div class="tag">LLM WIKI → TEACHING DECK</div><h1>{E(s["title"])}</h1>'
                f'<div class="sub">{E(s.get("subtitle",""))}</div><div class="defs">{tdefs}</div>{note}</section>')
    main = ""
    if s.get("bullets"):
        main += '<ul class="b">' + "".join(
            f'<li class="{E(b.get("type", "fact"))}">{E(b["text"])}'
            f'{"<span class=inf>推論</span>" if b.get("type") == "inference" else ""}{cites(b.get("cite"))}</li>'
            for b in s["bullets"]) + "</ul>"
    if k == "flow":
        main = '<div class="flow">' + "".join(f'<div class="step"><b>{E(x["label"])}</b><span>{E(x["text"])}</span></div>'
                                             for x in s.get("flow", [])) + "</div>" + main
    if k == "compare" and s.get("table"):
        t = s["table"]
        main = ("<table><tr>" + "".join(f"<th>{E(c)}</th>" for c in t["columns"]) + "</tr>" +
                "".join("<tr>" + "".join(f"<td>{E(str(c))}</td>" for c in r) + "</tr>" for r in t["rows"]) +
                f"</table><div style='margin-top:1vh'>{cites(t.get('cite'))}</div>") + main
    if k == "timeline":
        main = '<div class="tl">' + "".join(
            f'<div class="tli"><span class="y">{E(x["year"])}</span><b>{E(x["name"])}</b><span>{E(x["text"])}</span>{cites(x.get("cite"))}</div>'
            for x in s.get("timeline", [])) + "</div>" + main
    if k == "quiz":
        q = s["quiz"]
        main = (f'<div class="quiz" data-answer="{int(q["answer"])}"><div class="q">{E(q["q"])}</div>' +
                "".join(f'<button class="opt">{chr(65+j)}. {E(o)}</button>' for j, o in enumerate(q["options"])) +
                f'<div class="explain">✔ {E(q["explain"])}{cites(q.get("cite"))}</div></div>')
    cls = "body" if aside else "body full"
    sub = f'<div class="sub">{E(s["subtitle"])}</div>' if s.get("subtitle") else ""
    return f'<section>{head}<h2>{E(s["title"])}</h2>{sub}<div class="{cls}"><div>{main}</div>{aside}</div>{note}</section>'


def sources_slide(used_claims, raw):
    """依原始論文分組，列出本簡報實際用到的 wiki 頁。"""
    by_raw = {}
    for cid in used_claims:
        ev = EV.get(cid)
        if not ev:
            continue
        for r in ev["raw"] or ["(wiki 推論)"]:
            by_raw.setdefault(r, set()).add(ev["page"])
    items = []
    for r in sorted(by_raw, key=lambda r: raw.get(r, {}).get("meta", {}).get("year", "9")):
        pg = "、".join(f"[[{p}]]" for p in sorted(by_raw[r]))
        if r in raw:
            m = raw[r]["meta"]
            items.append(f'<li><a href="{E(m["url"])}" target="_blank">{E(m["title"].strip(chr(34)))}</a> ({E(m["year"])})'
                         f'<small>wiki 頁：{E(pg)}</small></li>')
        else:
            items.append(f'<li>Wiki 中標為 (推論) 的整理<small>wiki 頁：{E(pg)}</small></li>')
    return (f'<section id="src"><h2>資料來源</h2><div class="sub legend">引用標籤 = Wiki claim id（頁名#第幾條）；'
            f'Wiki claim 再追溯到 raw/ 中的原始論文。實心點 = 論文事實、空心橘點 = 推論、橘字 = 比喻。</div>'
            f'<ul class="b src">{"".join(items)}</ul></section>')


def render(slides, objectives, title, evidence, raw) -> str:
    EV.clear()
    EV.update(evidence)
    used = set()
    for s in slides:
        for b in s.get("bullets", []):
            used |= set(b.get("cite", []))
        used |= set((s.get("table") or {}).get("cite", []))
        for x in s.get("timeline", []):
            used |= set(x.get("cite", []))
        used |= set((s.get("quiz") or {}).get("cite", []))
    body = "".join(render_slide(s, objectives) for s in slides) + sources_slide(used, raw)
    return (f'<!DOCTYPE html><html lang="zh-Hant"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
            f'<title>{E(title)}</title><style>{CSS}</style></head><body><div class="deck">{body}</div><div class="bar"></div>'
            f'<div class="hud"><span>← → 換頁 · N 講者備註</span><span id="pg"></span></div><script>{JS}</script></body></html>')
