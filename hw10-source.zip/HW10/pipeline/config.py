"""簡報任務設定（loop 規格的「目標／限制／完成標準／停止條件」都集中在這裡）。"""
TOPIC = "VLA（Vision-Language-Action）模型是什麼？"
AUDIENCE = "修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學"

# 目標：學習目標（含檢索關鍵字）
OBJECTIVES = {
    "O1": ("說出 VLA 的定義，以及它和 LLM / VLM 的關係", ["vla", "VLM", "定義", "rt2"]),
    "O2": ("理解動作怎麼變成模型輸出：離散 token vs 連續動作", ["動作", "token", "bin", "diffusion", "flow", "fast"]),
    "O3": ("知道 VLA 的資料從哪來：跨機體資料與 co-fine-tuning", ["embodiment", "co-fine", "OXE", "資料"]),
    "O4": ("理解為什麼需要 action chunking 才能高頻控制", ["chunk", "Hz", "頻率"]),
    "O5": ("能比較 RT-1 → π0 的演進與代表模型", ["timeline", "時間線", "OpenVLA", "Octo", "π0"]),
}

# 限制：觀眾不熟的術語，第一次出現的那張投影片必須用 defines 解釋
TERMS = {
    "VLA": r"\bVLA\b",
    "VLM": r"\bVLM\b",
    "policy": r"\bpolicy\b|策略",
    "embodiment": r"embodiment|機體",
    "DoF": r"DoF|自由度",
    "co-fine-tuning": r"co-fine-tun",
    "action chunk": r"chunk",
    "diffusion": r"diffusion|擴散",
    "flow matching": r"flow matching",
    "控制頻率": r"\bHz\b|控制頻率",
    "正遷移": r"positive transfer|正遷移",
}

# 完成標準
MAX_BULLETS = 5
MAX_BULLET_CHARS = 60
SLIDE_RANGE = (10, 14)          # 內容頁；加上自動產生的「資料來源」頁共 11–15 頁（講義：8–15 頁）
TOP_K_PER_OBJECTIVE = 4
MIN_FACTS_PER_OBJECTIVE = 2
MIN_RELEVANT_PAGES = 3          # 講義：相關頁面少於 3 頁就一開始停下

# 停止條件（每一圈的硬上限）
MAX_QUERY_RETRY = 2             # 覆蓋不足時擴大檢索的次數
MAX_OUTLINE_REPAIR = 2          # 大綱 程式檢查 → 修
MAX_HUMAN_ROUNDS = 5            # 人工退回的次數上限
MAX_SLIDE_FIX = 2               # 每一頁：程式檢查 → 修（小圈）
MAX_REVIEW_ROUNDS = 2           # 每一頁：AI 審查退回的次數
MAX_RENDER_FIX = 2              # 每一頁：渲染溢出 → 退回逐頁稿縮短
