"""LLM Wiki → 教學 HTML 簡報：graph v4（v3 對照第 10 講重畫；v4 依 v3 的 Groq 實跑結果修正檢查器）。

  load_wiki → lint_wiki → query_wiki ⟲(覆蓋不足就擴大檢索) → evidence_cards → outline ⟲(程式檢查)
  → human_gate(人工確認，可退回大綱) → draft_pages(逐頁稿；每頁內部：寫→檢查→修 ≤2)
  → ai_review(換一個模型、新對話、只看該頁和它的證據；不過就只退回那一頁)
  → check_coverage(有論文完全沒用到就退回大綱，大圈，最多 1 次)
  → render_html → check_render(溢出的那頁退回逐頁稿縮短) → finalize(檢查報告)

用法：
  python3 pipeline/graph.py --run v3 --llm groq            # 需要 HW10/.env 裡的 GROQ_API_KEY
  python3 pipeline/graph.py --run v3 --llm groq --resume   # 中斷後從 checkpoint 繼續
  加 --auto-approve 可略過人工確認（不建議）
"""
from __future__ import annotations
import argparse, json, re, shutil, sys, time
from html.parser import HTMLParser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import config as C
from engine import Graph, END
from wiki import load_wiki, load_raw, claims, ROOT
from lint import lint, conflicts
from checks import check_outline, check_slide, check_deck, coverage, terms_in, slide_text, grounded_units
from llm import make_llm, WaitingForLLM
import prompts as P
import render as R
import render_check as RC

g = Graph()
LLM = None
ARGS = None


def rd(st) -> Path:
    return ROOT / "runs" / st["run"]


def event(st, **kw):
    kw["t"] = time.strftime("%H:%M:%S")
    st.setdefault("events", []).append(kw)
    print("     ·", json.dumps(kw, ensure_ascii=False)[:160])


def cnt(st, sid, k):
    return st.setdefault("counters", {}).setdefault(sid, {}).get(k, 0)


def inc(st, sid, k):
    c = st.setdefault("counters", {}).setdefault(sid, {})
    c[k] = c.get(k, 0) + 1
    return c[k]


# ── 1. 取得資料 ────────────────────────────────────────────────
@g.node("load_wiki")
def load_wiki_node(st):
    pages = load_wiki()
    return {"pages": len(pages), "raw_sources": len(load_raw())}


@g.node("lint_wiki")
def lint_wiki_node(st):
    st["lint_errors"] = lint()
    st["conflicts"] = [f"{n}: {b[:80]}" for n, b in conflicts()]
    return {"lint_errors": len(st["lint_errors"]), "conflicts": len(st["conflicts"])}


g.edge("load_wiki", "lint_wiki")
g.edge("lint_wiki", lambda st: "query_wiki" if not st["lint_errors"] else "stop")


@g.node("stop")
def stop(st):
    st["status_final"] = "stopped: " + st.get("stop_reason", "wiki lint 未通過，請先修 wiki（python3 pipeline/lint.py）")
    write_report(st)
    return {"reason": st["status_final"]}


g.edge("stop", END)


# ── 2. 查詢 Wiki + 覆蓋率關卡 ─────────────────────────────────────
@g.node("query_wiki")
def query_wiki(st):
    pages = load_wiki()
    k = C.TOP_K_PER_OBJECTIVE + st.get("visits", {}).get("query_wiki", 0)
    retrieval, ctx = {}, set()
    for oid, (_, kws) in C.OBJECTIVES.items():
        scored = []
        for n, p in pages.items():
            if p.meta.get("type") == "meta":
                continue
            hay = (n + " " + str(p.meta.get("summary", "")) + " " + p.body).lower()
            sc = sum(hay.count(kw.lower()) for kw in kws) + (3 if n in [kw.lower() for kw in kws] else 0)
            sc *= 1.5 if p.meta.get("type") == "concept" else 1
            scored.append((round(sc, 1), n))
        retrieval[oid] = [n for sc, n in sorted(scored, reverse=True)[:k] if sc > 0]
        ctx |= set(retrieval[oid])
    ev = claims(pages, sorted(ctx))
    thin = [o for o, ns in retrieval.items()
            if sum(1 for c in ev.values() if c["page"] in ns and c["kind"] == "fact") < C.MIN_FACTS_PER_OBJECTIVE]
    st.update(retrieval=retrieval, context=sorted(ctx), evidence=ev, thin=thin)
    (rd(st) / "sources.md").write_text("# 檢索結果\n\n" + "\n".join(
        f"- **{o}** {C.OBJECTIVES[o][0]}：{', '.join(f'[[{n}]]' for n in ns)}" for o, ns in retrieval.items()) +
        f"\n\n共 {len(ctx)} 頁、{len(ev)} 條 claim（推論 {sum(c['kind']=='inference' for c in ev.values())} 條）\n",
        encoding="utf-8")
    return {"k": k, "pages": len(ctx), "claims": len(ev), "thin": thin}


def route_query(st):
    if len(st["context"]) < C.MIN_RELEVANT_PAGES:
        st["stop_reason"] = f"相關頁面只有 {len(st['context'])} 頁 < {C.MIN_RELEVANT_PAGES}，資料不足就停（不硬湊）"
        return "stop"
    if st["thin"]:
        if st["visits"]["query_wiki"] <= C.MAX_QUERY_RETRY:
            return "query_wiki"
        st["stop_reason"] = f"擴大檢索後 {st['thin']} 仍不足 {C.MIN_FACTS_PER_OBJECTIVE} 條事實，需要先 ingest 更多資料"
        return "stop"
    return "evidence_cards"


g.edge("query_wiki", route_query)


@g.node("evidence_cards")
def evidence_cards(st):
    """證據卡：依原始論文分組（每張卡只含一篇論文的 claim）；推論另成一張卡。"""
    d = rd(st) / "cards"
    d.mkdir(exist_ok=True)
    raw = load_raw()
    groups = {}
    for cid, c in st["evidence"].items():
        for r in (c["raw"] or ["_inference"]):
            groups.setdefault(r, []).append(cid)
    for r, ids in groups.items():
        title = raw[r]["meta"]["title"].strip('"') if r in raw else "Wiki 中的推論（無論文出處）"
        (d / f"{r}.md").write_text(f"# 證據卡：{title}\n\n" + "\n".join(
            f"- [{i}] ({st['evidence'][i]['kind']}) {st['evidence'][i]['text']}" for i in ids) + "\n", encoding="utf-8")
    return {"cards": {r: len(v) for r, v in groups.items()}}


g.edge("evidence_cards", "outline")


# ── 3. 大綱（LLM）→ 程式檢查 → 人工確認 ─────────────────────────────
@g.node("outline")
def outline(st):
    pt = {n: p.body for n, p in load_wiki().items()}
    n = st.get("visits", {}).get("outline", 0) + 1
    prev = st.get("outline")
    out = LLM(f"outline_{n}", P.outline_prompt(st["evidence"], pt["index"], st.get("human_feedback"), prev,
                                                st.get("outline_errors") or None), role="writer")
    new = out["slides"]
    old = {s["id"]: s for s in (prev or [])}
    st["outline_changed"] = [s["id"] for s in new if old.get(s["id"]) != s]
    st["outline"] = new
    st["human_feedback"] = None
    return {"slides": len(new), "changed": len(st["outline_changed"])}


g.edge("outline", "check_outline")


@g.node("check_outline")
def check_outline_node(st):
    errs = check_outline(st["outline"], st["evidence"])
    st["outline_errors"] = errs
    by = {}
    for e in errs:
        by[e["type"]] = by.get(e["type"], 0) + 1
    st.setdefault("check_log", []).append({"stage": "outline", "n": len(errs), "by_type": by})
    return {"errors": len(errs), "by_type": by}


def route_outline(st):
    if not st["outline_errors"]:
        return "human_gate"
    if inc(st, "_outline", "repair") <= C.MAX_OUTLINE_REPAIR:
        return "outline"
    st["stop_reason"] = f"大綱修 {C.MAX_OUTLINE_REPAIR} 次仍有錯"
    return "stop"


g.edge("check_outline", route_outline)


def outline_md(st):
    rows = ["| id | kind | 目標 | 標題 | claims | 介紹術語 |", "|---|---|---|---|---|---|"]
    for s in st["outline"]:
        rows.append(f"| {s['id']} | {s.get('kind')} | {s.get('objective') or ''} | {s.get('title')} | "
                    f"{len(s.get('claims', []))} | {', '.join(s.get('introduces', []))} |")
    return "\n".join(rows)


@g.node("human_gate")
def human_gate(st):
    md = outline_md(st)
    (rd(st) / "outline.md").write_text(f"# 大綱（第 {st['visits'].get('outline', 0)} 版）\n\n{md}\n", encoding="utf-8")
    hd = rd(st) / "human"
    hd.mkdir(exist_ok=True)
    if ARGS.auto_approve:
        decision = "y"
    elif sys.stdin.isatty():
        print("\n" + md + "\n")
        decision = ask_human("👤 人工確認大綱：輸入 y 通過，或打修改意見（太長請用 @檔案路徑）> ")
    else:
        f = hd / f"outline_{st['visits'].get('outline', 0)}.txt"
        if not f.exists():
            raise WaitingForLLM(f"等待人工確認：在 {f} 寫 y 或修改意見後 --resume")
        decision = f.read_text(encoding="utf-8").strip()
    approved = decision.lower() in ("y", "yes", "ok")
    st.setdefault("human_log", []).append({"outline_version": st["visits"].get("outline", 0),
                                           "decision": "approve" if approved else "revise",
                                           "feedback": None if approved else decision,
                                           "auto": bool(ARGS.auto_approve)})
    if not approved:
        st["human_feedback"] = decision
    else:
        planned = {s["id"] for s in st["outline"]}
        # v5 修正：原本只和「上一版大綱」比，大綱連修好幾版時，前幾版的改動會被漏掉（s07/s09/s10/s11 沒重寫）
        dp = st.get("drafted_plan", {})
        stale = {x["id"] for x in st["outline"] if dp.get(x["id"]) != x}
        st["dirty"] = (sorted((stale | set(st.get("feedback", {}))) & planned) if st.get("slides") else sorted(planned))
        for sid in st["dirty"]:
            st.get("unresolved", {}).pop(sid, None)
        st["slides"] = {k: v for k, v in st.get("slides", {}).items() if k in planned}
    return {"approved": approved}


def route_human(st):
    if st["human_log"][-1]["decision"] == "approve":
        return "draft_pages"
    if len(st["human_log"]) <= C.MAX_HUMAN_ROUNDS:
        return "outline"
    st["stop_reason"] = "人工退回次數超過上限"
    return "stop"


g.edge("human_gate", route_human)


def ask_human(prompt):
    """v5：空白 Enter 曾被當成「通過」，長意見又被終端機截斷 → 必須明確輸入，且支援 @檔案。"""
    while True:
        ans = input(prompt).strip()
        if ans.startswith("@"):
            f = Path(ans[1:].strip()).expanduser()
            f = f if f.is_absolute() else ROOT / f
            if f.exists():
                txt = f.read_text(encoding="utf-8").strip()
                print(f"   已讀取 {f.name}（{len(txt)} 字）")
                return txt
            print(f"   找不到 {f}")
            continue
        if ans:
            return ans
        print("   請輸入 y 或意見（不能空白）")


# ── 4. 逐頁稿（LLM，只看大綱這一頁 + 對應證據卡）＋ 每頁小圈 ───────────────
def planned_defined_before(st, sid):
    out = set()
    for s in st["outline"]:
        if s["id"] == sid:
            break
        out |= set(s.get("introduces", []))
    return out


def must_define(st, plan):
    before = planned_defined_before(st, plan["id"])
    use = terms_in(plan.get("title", "") + " " + plan.get("purpose", "")) | set(plan.get("introduces", []))
    return use - before, before


@g.node("draft_pages")
def draft_pages(st):
    plans = {s["id"]: s for s in st["outline"]}
    fb_all = st.setdefault("feedback", {})
    done, still_bad = [], []
    for sid in [s["id"] for s in st["outline"] if s["id"] in st.get("dirty", [])]:
        plan = plans[sid]
        must, before = must_define(st, plan)
        cards = P.cards_text(st["evidence"], set(plan.get("claims", [])))
        fb = fb_all.pop(sid, None)
        prev = st["slides"].get(sid) if fb else None
        last_valid = None
        for attempt in range(C.MAX_SLIDE_FIX + 1):
            n = inc(st, sid, "draft_calls")
            slide = LLM(f"draft_{sid}_{n}", P.slide_prompt(plan, cards, must, before, fb, prev), role="writer")
            if isinstance(slide, dict):
                slide.update(id=sid, kind=plan.get("kind"), objective=plan.get("objective"))
            errs = check_slide(slide, plan, st["evidence"], before)
            event(st, node="draft_pages", slide=sid, call=n, errors=[f"{e['type']}: {e['msg']}" for e in errs])
            if not any(e["type"] == "schema" for e in errs):
                last_valid = slide
            if not errs:
                break
            sig = sorted(e["type"] + e["msg"] for e in errs)
            if fb and sig == sorted(e["type"] + e["msg"] for e in fb):
                # v4 剎車：同樣的錯誤連續出現兩次，代表再修也沒用（v3 的 s09 同一個錯重寫了 12 次）
                event(st, node="draft_pages", slide=sid, call=n, errors=["repeated_error: 同樣的錯誤連續兩次，停止重寫並交給人工"])
                break
            fb, prev = errs, slide
        # 格式一直不對時，保留最後一個「格式正確」的版本；都沒有就放空白頁並列為未解決
        slide = last_valid or {"id": sid, "kind": "content", "objective": plan.get("objective"),
                               "title": plan.get("title", sid), "bullets": []}
        st["slides"][sid] = slide
        if errs:
            still_bad.append(sid)
            st.setdefault("unresolved", {})[sid] = errs
        else:
            st.get("unresolved", {}).pop(sid, None)
        st.setdefault("drafted_plan", {})[sid] = plan
        (rd(st) / "drafts").mkdir(exist_ok=True)
        (rd(st) / "drafts" / f"{sid}.json").write_text(json.dumps(slide, ensure_ascii=False, indent=1), encoding="utf-8")
        done.append(sid)
        # 每寫完一頁就 checkpoint：當掉時 --resume 不會重寫已完成的頁
        st["dirty"] = [x for x in st["dirty"] if x != sid]
        st["to_review"] = sorted(set(st.get("to_review", [])) | {sid})
        g.save(st, rd(st))
    return {"drafted": done, "unresolved_after_fix": still_bad}


g.edge("draft_pages", "ai_review")


# ── 5. AI 審查（另一個模型、新對話、只看成品與來源）────────────────────
def slide_view(s):
    lines = [f"標題：{s.get('title','')}"]
    for i, b in enumerate(s.get("bullets", []), 1):
        lines.append(f"bullet {i} [{b.get('type','fact')}] {b.get('text','')}  (cite: {', '.join(b.get('cite', []))})")
    for x in s.get("flow", []):
        lines.append(f"流程：{x.get('label')} — {x.get('text')}")
    t = s.get("table")
    if t:
        lines.append("表格欄位：" + " | ".join(map(str, t.get("columns", []))) + f"  (cite: {', '.join(t.get('cite', []))})")
        lines += ["table row: " + " | ".join(map(str, r)) for r in t.get("rows", [])]
    for x in s.get("timeline", []):
        lines.append(f"timeline {x.get('year')} {x.get('name')}：{x.get('text')}  (cite: {', '.join(x.get('cite', []))})")
    q = s.get("quiz")
    if q:
        lines.append(f"quiz：{q.get('q')} 選項：{q.get('options')} 正解：{q.get('answer')} 解說：{q.get('explain')} (cite: {', '.join(q.get('cite', []))})")
    for d in s.get("defines", []):
        lines.append(f"名詞解釋 {d.get('term')}：{d.get('def')}")
    return "\n".join(lines)


@g.node("ai_review")
def ai_review(st):
    failed = list(st.get("review_failed_pending", []))
    for sid in list(st.get("to_review", [])):
        s = st["slides"][sid]
        cited = sorted({c for _, cs, _, _ in grounded_units(s) for c in cs if c in st["evidence"]})
        if not cited:
            continue
        n = inc(st, sid, "review_calls")
        res = LLM(f"review_{sid}_{n}", P.review_prompt(slide_view(s), "\n".join(
            f"[{c}] ({st['evidence'][c]['kind']}) {st['evidence'][c]['text']}" for c in cited)), role="reviewer")
        issues = res.get("issues", []) if res.get("verdict") == "fail" else []
        event(st, node="ai_review", slide=sid, call=n, verdict=res.get("verdict"),
              issues=[f"{i.get('type')}: {i.get('where')} — {i.get('problem')}" for i in issues])
        st.setdefault("review_log", []).append({"slide": sid, "call": n, "verdict": res.get("verdict"), "issues": issues})
        st.setdefault("reviewed", []).append(sid)
        if issues:
            if cnt(st, sid, "review_returns") < C.MAX_REVIEW_ROUNDS:
                inc(st, sid, "review_returns")
                st.setdefault("feedback", {})[sid] = [{"slide": sid, "type": "ai_review_" + str(i.get("type")),
                                                       "msg": f"{i.get('where')}：{i.get('problem')}；建議：{i.get('fix')}"}
                                                      for i in issues]
                failed.append(sid)
            else:
                st.setdefault("unresolved", {})[sid] = [{"type": "ai_review", "msg": json.dumps(issues, ensure_ascii=False)}]
        # 每審完一頁就 checkpoint
        st["to_review"] = [x for x in st["to_review"] if x != sid]
        st["review_failed_pending"] = failed
        g.save(st, rd(st))
    st["to_review"] = []
    st["review_failed_pending"] = []
    st["dirty"] = failed
    return {"failed": failed}


g.edge("ai_review", lambda st: "draft_pages" if st["dirty"] else "check_deck")


# ── 6. 整份檢查：術語實際首次出現 + 論文覆蓋率 ──────────────────────────
@g.node("check_deck")
def check_deck_node(st):
    slides = [st["slides"][s["id"]] for s in st["outline"]]
    errs = check_deck(slides)
    dp = st.get("drafted_plan", {})
    for p in st["outline"]:
        if p["id"] in dp and dp[p["id"]] != p:
            errs.append({"slide": p["id"], "type": "stale_slide", "msg": "這頁是依照舊版大綱寫的，請依新版大綱重寫"})
    cov = coverage(slides, st["evidence"])
    st["coverage"] = cov
    st.setdefault("check_log", []).append({"stage": "deck", "n": len(errs), "raw_unused": cov["raw_unused"]})
    for e in errs:
        if cnt(st, e["slide"], "deck_returns") < C.MAX_SLIDE_FIX:
            inc(st, e["slide"], "deck_returns")
            st.setdefault("feedback", {}).setdefault(e["slide"], []).append(e)
    st["dirty"] = sorted(st.get("feedback", {}).keys())
    st["coverage_return"] = False
    if not st["dirty"] and cov["raw_unused"] and cnt(st, "_deck", "coverage_returns") < 1:
        inc(st, "_deck", "coverage_returns")
        st["coverage_return"] = True
        st["human_feedback"] = (f"論文 {cov['raw_unused']} 在證據卡裡有內容，但整份簡報完全沒用到。"
                                f"請在不增加總張數上限的前提下，把它們放進最相關的投影片（加入它們的 claim）。")
    return {"deck_errors": len(errs), "raw_used": cov["raw_used"], "raw_unused": cov["raw_unused"],
            "back_to_outline": st["coverage_return"]}


g.edge("check_deck", lambda st: "outline" if st["coverage_return"] else ("draft_pages" if st["dirty"] else "render_html"))


# ── 7. 渲染（模板，不改任何字）→ 渲染檢查 ──────────────────────────────
@g.node("render_html")
def render_html(st):
    slides = [st["slides"][s["id"]] for s in st["outline"]]
    out = rd(st) / "deck.html"
    out.write_text(R.render(slides, C.OBJECTIVES, C.TOPIC, st["evidence"], load_raw()), encoding="utf-8")
    return {"deck": str(out.relative_to(ROOT))}


g.edge("render_html", "check_render")


class _Count(HTMLParser):
    def __init__(self):
        super().__init__()
        self.sections, self.ext = 0, []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        self.sections += tag == "section"
        if tag in ("script", "link", "img") and (a.get("src") or a.get("href") or "").startswith("http"):
            self.ext.append(tag)


@g.node("check_render")
def check_render(st):
    slides = [st["slides"][s["id"]] for s in st["outline"]]
    html = rd(st) / "deck.html"
    c = _Count()
    c.feed(html.read_text(encoding="utf-8"))
    method, over = RC.check(html, slides, rd(st) / "shots")
    st["render_method"] = method
    bad = {slides[i]["id"]: px for i, px in enumerate(over) if px > 0}
    st.setdefault("check_log", []).append({"stage": "render", "method": method, "overflow": bad,
                                           "sections": c.sections, "external": c.ext})
    st["dirty"] = []
    if not method.startswith("playwright"):
        # v4：估算法在 v3 誤報 s08/s09 溢出（Playwright 實測為 0px）→ 不可靠的檢查只警告、不退件
        if bad:
            st.setdefault("warnings", []).append({"stage": "render", "msg": f"估算可能溢出：{bad}（未安裝 Playwright，只警告不退件）"})
        bad = {}
    for sid, px in bad.items():
        if cnt(st, sid, "render_returns") < C.MAX_RENDER_FIX:
            inc(st, sid, "render_returns")
            st.setdefault("feedback", {})[sid] = [{"slide": sid, "type": "overflow",
                                                   "msg": f"渲染後超出畫面約 {px}px：請減少 bullet 數或縮短句子，不要刪掉關鍵事實"}]
            st["dirty"].append(sid)
        else:
            st.setdefault("unresolved", {})[sid] = [{"type": "overflow", "msg": f"{px}px"}]
    return {"method": method, "overflow": bad, "sections": c.sections, "external": c.ext}


g.edge("check_render", lambda st: "draft_pages" if st["dirty"] else "human_final")


# ── 8. 人工驗收（講義：人在指定關卡介入）：可以把特定幾頁退回逐頁稿 ─────────────
@g.node("human_final")
def human_final(st):
    rows = []
    for s in st["outline"]:
        c = st.get("counters", {}).get(s["id"], {})
        flag = "⚠ 未解決" if s["id"] in st.get("unresolved", {}) else ""
        rows.append(f"  {s['id']}  {s.get('title','')[:40]:<40}  稿{c.get('draft_calls',0)} 審{c.get('review_calls',0)} {flag}")
    hd = rd(st) / "human"
    hd.mkdir(exist_ok=True)
    n = len([h for h in st.get("human_log", []) if h.get("stage") == "final"]) + 1
    if ARGS.auto_approve:
        decision = "y"
    elif sys.stdin.isatty():
        print(f"\n成品：runs/{st['run']}/deck.html（請先用瀏覽器打開看過）\n" + "\n".join(rows))
        print("👤 人工驗收：輸入 y 通過；或用「s10: 意見; s11: 意見」把指定頁退回逐頁稿")
        print("   意見很長時請寫在檔案裡，輸入 @檔案路徑（macOS 終端機單行輸入上限約 1024 bytes，長中文會被截斷）")
        decision = ask_human("> ")
    else:
        f = hd / f"final_{n}.txt"
        if not f.exists():
            raise WaitingForLLM(f"等待人工驗收：在 {f} 寫 y 或「s10: 意見; s11: 意見」後 --resume")
        decision = f.read_text(encoding="utf-8").strip()
    approved = re.sub(r"[\s、，。,.;；:：]", "", decision).lower() in ("y", "yes", "ok")   # v5：輸入法多打「、」被當成退回
    st.setdefault("human_log", []).append({"stage": "final", "round": n, "decision": "approve" if approved else "revise",
                                           "feedback": None if approved else decision, "auto": bool(ARGS.auto_approve)})
    st["dirty"] = []
    st["final_to_outline"] = False
    if not approved:
        ids = {s["id"] for s in st["outline"]}
        for part in re.split(r"[;；\n]+", decision):
            sid, _, note = part.partition(":") if ":" in part else part.partition("：")
            sid = sid.strip()
            if sid.lower() == "outline" and note.strip():
                # 大綱層級的問題（缺 claim、頁面主題不對）→ 退回大綱，這是比較大的圈
                st["human_feedback"] = note.strip()
                st["final_to_outline"] = True
                continue
            if sid in ids and note.strip():
                st.setdefault("feedback", {})[sid] = [{"slide": sid, "type": "human_review", "msg": note.strip()}]
                st["dirty"].append(sid)
                st.get("unresolved", {}).pop(sid, None)
                # 人工介入後，這頁的自動退件次數重新計算
                st["counters"].setdefault(sid, {}).update(review_returns=0, render_returns=0)
        event(st, node="human_final", round=n, returned=st["dirty"], feedback=decision[:300])
    return {"approved": approved, "returned": st["dirty"]}


def route_final(st):
    if st.get("final_to_outline"):
        return "outline"
    if st["dirty"]:
        # v5 修正：原本把「通過」也算進退回次數，第 6 輪的退回被上限擋掉後，竟然直接 finalize 成 done
        # 人工驗收是人明確下的決定，不設上限（上限只用在自動迴圈）。
        # v5 教訓：人工輪數的上限兩度擋下真正的退回（把通過、--reopen 都算進去）
        return "draft_pages"
        for sid in st["dirty"]:
            st.setdefault("unresolved", {})[sid] = [{"type": "human_rounds_exceeded", "msg": "人工退回次數超過上限，未重寫"}]
        st["dirty"] = []
    return "finalize"


g.edge("human_final", route_final)


@g.node("finalize")
def finalize(st):
    ok = not st.get("unresolved")
    if ok and st.get("llm") != "fake":
        (ROOT / "output").mkdir(exist_ok=True)
        shutil.copy(rd(st) / "deck.html", ROOT / "output" / "slides.html")
    st["status_final"] = "done" if ok else f"done_with_issues: {list(st['unresolved'])}"
    write_report(st)
    return {"status": st["status_final"]}


g.edge("finalize", END)


# ── 檢查報告 ────────────────────────────────────────────────────
def write_report(st):
    d = rd(st)
    trace = [json.loads(l) for l in (d / "trace.jsonl").read_text().splitlines()] if (d / "trace.jsonl").exists() else []
    calls = [json.loads(l) for l in (d / "llm" / "calls.jsonl").read_text().splitlines()] if (d / "llm" / "calls.jsonl").exists() else []
    visits = {}
    for t in trace:
        if t.get("event") != "wait_llm":
            visits[t["node"]] = visits.get(t["node"], 0) + 1
    L = [f"# 檢查報告 — run `{st['run']}`", "", f"- 狀態：**{st.get('status_final', st.get('status'))}**",
         f"- LLM：{st.get('llm')}；模型：{st.get('models')}",
         f"- LLM 呼叫 {sum(1 for c in calls if 'model' in c)} 次，prompt tokens {sum(c.get('prompt_tokens') or 0 for c in calls)}，"
         f"completion tokens {sum(c.get('completion_tokens') or 0 for c in calls)}，429 等待 {sum(1 for c in calls if c.get('event')=='rate_limited')} 次",
         f"- 渲染檢查方式：{st.get('render_method', '-')}", "", "## 節點執行次數（graph 上每個圈轉了幾次）", "",
         "| 節點 | 次數 |", "|---|---|"] + [f"| {k} | {v} |" for k, v in visits.items()]
    L += ["", "## 各關卡檢查結果", "", "| 關卡 | 結果 |", "|---|---|"]
    for c in st.get("check_log", []):
        L.append(f"| {c['stage']} | {json.dumps({k: v for k, v in c.items() if k != 'stage'}, ensure_ascii=False)} |")
    L += ["", "## 人工確認", ""] + [(f"- 人工驗收第 {h['round']} 輪：" if h.get("stage") == "final" else f"- 大綱第 {h.get('outline_version')} 版：") + f"{h['decision']}" +
                                    (f"（意見：{h['feedback']}）" if h.get('feedback') else "") +
                                    ("（--auto-approve）" if h.get("auto") else "") for h in st.get("human_log", [])]
    L += ["", "## 逐頁紀錄（小圈）", "", "| 頁 | 逐頁稿呼叫 | AI 審查呼叫 | 審查退回 | 渲染退回 | 整份檢查退回 |", "|---|---|---|---|---|---|"]
    for s in st.get("outline", []):
        c = st.get("counters", {}).get(s["id"], {})
        L.append(f"| {s['id']} {s.get('title','')} | {c.get('draft_calls',0)} | {c.get('review_calls',0)} | "
                 f"{c.get('review_returns',0)} | {c.get('render_returns',0)} | {c.get('deck_returns',0)} |")
    err_types = {}
    for e in st.get("events", []):
        for x in e.get("errors", []) + e.get("issues", []):
            k = (e["node"], x.split(":")[0])
            err_types[k] = err_types.get(k, 0) + 1
    L += ["", "## 錯誤類型統計（哪個節點最常出錯）", "", "| 節點 | 錯誤類型 | 次數 |", "|---|---|---|"]
    L += [f"| {k[0]} | {k[1]} | {v} |" for k, v in sorted(err_types.items(), key=lambda x: -x[1])]
    cov = st.get("coverage")
    if cov:
        L += ["", "## 覆蓋率", "", f"- 用到的 claim：{cov['claims_used']}", f"- 用到的論文：{cov['raw_used']}",
              f"- 沒用到的論文：{cov['raw_unused'] or '無'}"]
    if st.get("conflicts"):
        L += ["", "## Wiki 中的矛盾（⚠）", ""] + [f"- {c}" for c in st["conflicts"]]
    if st.get("warnings"):
        L += ["", "## 警告", ""] + [f"- {w['stage']}: {w['msg']}" for w in st["warnings"]]
    if st.get("unresolved"):
        L += ["", "## 未解決（已達上限，需人工處理）", ""] + [f"- {k}: {v}" for k, v in st["unresolved"].items()]
    L += ["", "## 事件時間線", ""] + [f"- {e['t']} `{e['node']}` {e.get('slide','')} 第{e.get('call','')}次 "
                                     f"{'✔' if not (e.get('errors') or e.get('issues')) else '✘ ' + '；'.join(e.get('errors', []) + e.get('issues', []))[:300]}"
                                     for e in st.get("events", [])]
    (d / "report.md").write_text("\n".join(L) + "\n", encoding="utf-8")


def main():
    global LLM, ARGS
    ap = argparse.ArgumentParser()
    ap.add_argument("--run", default="v4")
    ap.add_argument("--llm", default="groq", choices=["groq", "agent", "anthropic", "fake"])
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--auto-approve", action="store_true")
    ap.add_argument("--reopen", action="store_true", help="已跑完的 run 回到人工驗收關卡")
    ARGS = ap.parse_args()
    run_dir = ROOT / "runs" / ARGS.run
    sp = run_dir / "state.json"
    if not ARGS.resume and run_dir.exists() and any(run_dir.iterdir()):
        sys.exit(f"runs/{ARGS.run} 已存在；換一個 --run 名稱，或加 --resume 繼續")
    run_dir.mkdir(parents=True, exist_ok=True)
    LLM = make_llm(ARGS.llm, run_dir)
    st = json.loads(sp.read_text()) if ARGS.resume and sp.exists() else {"run": ARGS.run, "slides": {}}
    if ARGS.reopen:
        st["_next"] = "human_final"
    st["llm"] = ARGS.llm
    st["models"] = getattr(LLM, "models", None)
    print(f"[graph v4] run={ARGS.run} llm={ARGS.llm} start={st.get('_next', 'load_wiki')}")
    st = g.run(st, "load_wiki", run_dir)
    print(f"[graph v4] status = {st['status']}")
    print(f"[graph v4] 檢查報告：runs/{ARGS.run}/report.md")


if __name__ == "__main__":
    main()
