"""Wiki lint：斷鏈、孤兒頁、缺引用、數字無出處、index 缺頁。可單獨執行，也是 graph 的節點。"""
from __future__ import annotations
import re, sys
from wiki import load_wiki, load_raw, numbers, CITE_RE


def lint(pages=None, raw=None) -> list[dict]:
    pages = pages or load_wiki()
    raw = raw or load_raw()
    errs = []
    linked = set()
    for pg in pages.values():
        linked |= pg.links
        for l in pg.links - pages.keys():
            errs.append({"page": pg.name, "type": "broken_link", "detail": l})
        for c in pg.cites - raw.keys():
            errs.append({"page": pg.name, "type": "unknown_source", "detail": c})
        declared = set(pg.meta.get("sources") or [])
        if pg.cites - declared:
            errs.append({"page": pg.name, "type": "frontmatter_sources", "detail": sorted(pg.cites - declared)})
        if pg.meta.get("type") == "meta":
            continue
        for b in pg.bullets:
            cites = CITE_RE.findall(b)
            if not cites and "(推論)" not in b:
                errs.append({"page": pg.name, "type": "uncited_claim", "detail": b[:80]})
                continue
            if "(推論)" in b and not re.sub(r"\[\[[^\]]+\]\]|\(推論\)|[\s、,，與和及相關見等\-|]", "", b):
                errs.append({"page": pg.name, "type": "nav_as_claim", "detail": "只有連結的「相關」句被當成推論 claim，請改成「- 相關：[[a]]、[[b]]」導覽列：" + b[:60]})
            if "(推論)" in b and numbers(b):
                errs.append({"page": pg.name, "type": "number_in_inference", "detail": b[:80]})
            if b.lstrip("-| ").startswith("⚠") and len(set(cites)) < 2:
                errs.append({"page": pg.name, "type": "conflict_needs_two_sources", "detail": b[:80]})
            if cites:
                src_nums = set().union(*(numbers(raw[c]["text"]) for c in cites if c in raw))
                missing = numbers(CITE_RE.sub("", b)) - src_nums
                if missing:
                    errs.append({"page": pg.name, "type": "ungrounded_number",
                                 "detail": f"{sorted(missing)} in: {b[:70]}"})
    index = pages.get("index")
    for name, pg in pages.items():
        if pg.meta.get("type") == "meta":
            continue
        if index and name not in index.links:
            errs.append({"page": name, "type": "missing_from_index", "detail": ""})
        if name not in linked:
            errs.append({"page": name, "type": "orphan", "detail": ""})
    return errs


def conflicts(pages=None):
    pages = pages or load_wiki()
    return [(p.name, b) for p in pages.values() for b in p.bullets if b.lstrip("-| ").startswith("⚠")]


if __name__ == "__main__":
    for name, b in conflicts():
        print(f"[conflict] {name}: {b[:100]}")
    e = lint()
    for x in e:
        print(f"[{x['type']}] {x['page']}: {x['detail']}")
    print(f"{len(e)} issue(s)")
    sys.exit(1 if e else 0)
