# AGENTS.md — LLM Wiki schema（VLA 入門）

需求來源：`docs/requirements.md`（先討論、後生成）。這份手冊和需求摘要逐條對應。

## 三層結構
| 層 | 路徑 | 誰能寫 |
|---|---|---|
| Raw sources | `raw/*.md` | 人放進來，**LLM 只能讀、不能改** |
| Wiki | `wiki/**` | LLM 維護（人讀） |
| Schema | `AGENTS.md`（本檔） | 人和 LLM 討論後再改 |

## 讀者與語言
- 讀者：修過 ML、懂 Transformer/LLM，但沒碰過機器人的同學。
- 繁體中文，術語第一次出現時附英文。

## 頁面規則
1. 每頁開頭放 YAML frontmatter：`name`（整個 wiki 唯一）、`type`（source / concept / meta）、`summary`（一行）、`sources`（這頁引用到的 raw id）。
2. **每一條事實句**寫成 bullet，句尾用 `[[src:<raw-id>]]` 標出處；沒有出處的句子要標 `(推論)`，而且推論句不能有數字。
3. 頁面之間用 `[[<name>]]` 互相連結。
4. 數字必須能在被引用的 raw 檔中找到原文。
5. **矛盾**：兩篇論文說法衝突時，寫成 `- ⚠ 矛盾：A 說…[[src:a]]；B 說…[[src:b]]`，另起一行 `(推論)` 說明可能原因。不要刪掉任何一方。

## 操作
- **ingest（一次一篇）**：讀一篇 raw → 寫 `sources/<id>.md` → 更新相關 `concepts/*`（可能有好幾頁）→ 更新 `index.md` → 在 `log.md` 加一行 `## [日期] ingest | <id>` → 跑 lint → `git commit -m "ingest: <id>"`。
- **query**：先讀 `index.md` 找相關頁，再讀頁面回答並附上引用。
- **lint**：`python3 pipeline/lint.py`，檢查斷鏈、孤兒頁、index 缺頁、句子沒有出處、數字在出處找不到、推論句含數字、frontmatter 少列來源、矛盾句來源少於 2 個；矛盾清單會另外印出來。
- **產出簡報**：`python3 pipeline/graph.py`（流程見 REPORT.md）。
