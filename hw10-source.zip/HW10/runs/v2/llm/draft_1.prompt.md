依照大綱把每張投影片寫成完整內容。主題：VLA（Vision-Language-Action）模型是什麼？
大綱：
[
 {
  "id": "s01",
  "kind": "title",
  "objective": null,
  "title": "VLA 是什麼？讓大模型學會動手",
  "claims": [],
  "introduces": [
   "VLA"
  ],
  "purpose": "開場，給出 VLA 全名"
 },
 {
  "id": "s02",
  "kind": "flow",
  "objective": "O1",
  "title": "從 LLM → VLM → VLA",
  "claims": [
   "vla#1",
   "vla#2",
   "rt2#1"
  ],
  "introduces": [
   "VLM"
  ],
  "purpose": "用熟悉的 LLM 當錨點，VLA 只是多一種輸出"
 },
 {
  "id": "s03",
  "kind": "content",
  "objective": "O1",
  "title": "為什麼要借用 VLM？",
  "claims": [
   "vla#3",
   "rt2#9",
   "rt2#7",
   "rt2#11"
  ],
  "introduces": [
   "policy"
  ],
  "purpose": "網路知識轉移與限制"
 },
 {
  "id": "s04",
  "kind": "content",
  "objective": "O1",
  "title": "誰算 VLA？誰不算？",
  "claims": [
   "vla#4",
   "vla#5",
   "vla#6",
   "octo#2"
  ],
  "introduces": [],
  "purpose": "釐清 VLA 與一般機器人 policy 的界線"
 },
 {
  "id": "s05",
  "kind": "content",
  "objective": "O2",
  "title": "動作怎麼變成 token？",
  "claims": [
   "rt2#3",
   "action-representation#3",
   "openvla#3"
  ],
  "introduces": [
   "DoF"
  ],
  "purpose": "256 bin 離散化"
 },
 {
  "id": "s06",
  "kind": "content",
  "objective": "O2",
  "title": "另一條路：diffusion 與 flow matching",
  "claims": [
   "continuous-action-heads#1",
   "continuous-action-heads#2",
   "continuous-action-heads#3",
   "continuous-action-heads#4"
  ],
  "introduces": [
   "diffusion",
   "flow matching",
   "action chunk"
  ],
  "purpose": "連續動作頭的直覺"
 },
 {
  "id": "s07",
  "kind": "quiz",
  "objective": "O2",
  "title": "小測驗：動作表示",
  "claims": [
   "action-representation#7"
  ],
  "introduces": [],
  "purpose": "分辨離散 vs 連續"
 },
 {
  "id": "s08",
  "kind": "content",
  "objective": "O3",
  "title": "資料從哪來？跨 embodiment 學習",
  "claims": [
   "oxe#1",
   "oxe#2",
   "oxe#4",
   "cross-embodiment#4",
   "cross-embodiment#6"
  ],
  "introduces": [
   "embodiment",
   "正遷移"
  ],
  "purpose": "OXE 與正遷移"
 },
 {
  "id": "s09",
  "kind": "content",
  "objective": "O3",
  "title": "Co-fine-tuning：別讓 VLM 失憶",
  "claims": [
   "co-fine-tuning#1",
   "co-fine-tuning#2",
   "co-fine-tuning#3",
   "co-fine-tuning#4"
  ],
  "introduces": [
   "co-fine-tuning"
  ],
  "purpose": "混訓保留網路常識"
 },
 {
  "id": "s10",
  "kind": "content",
  "objective": "O4",
  "title": "大模型太慢？Action chunking",
  "claims": [
   "action-chunking#1",
   "action-chunking#2",
   "action-chunking#3",
   "action-chunking#4"
  ],
  "introduces": [
   "控制頻率"
  ],
  "purpose": "把思考頻率與控制頻率分開"
 },
 {
  "id": "s11",
  "kind": "timeline",
  "objective": "O5",
  "title": "VLA 演進：2022 → 2024",
  "claims": [
   "vla-timeline#1",
   "vla-timeline#2",
   "vla-timeline#3",
   "vla-timeline#4",
   "vla-timeline#5",
   "vla-timeline#6",
   "vla-timeline#8"
  ],
  "introduces": [],
  "purpose": "串起六個代表工作"
 },
 {
  "id": "s12",
  "kind": "compare",
  "objective": "O5",
  "title": "代表模型比一比",
  "claims": [
   "rt2#3",
   "rt2#5",
   "rt2#10",
   "octo#1",
   "octo#3",
   "openvla#1",
   "openvla#2",
   "openvla#8",
   "pi0#1",
   "pi0#3",
   "pi0#4",
   "openvla#5"
  ],
  "introduces": [],
  "purpose": "參數、資料、動作表示、速度"
 },
 {
  "id": "s13",
  "kind": "quiz",
  "objective": "O4",
  "title": "小測驗：π0 怎麼做到 50 Hz？",
  "claims": [
   "pi0#3"
  ],
  "introduces": [],
  "purpose": "檢查 chunking 觀念"
 },
 {
  "id": "s14",
  "kind": "summary",
  "objective": null,
  "title": "重點回顧",
  "claims": [
   "vla#1",
   "action-representation#8",
   "cross-embodiment#3",
   "co-fine-tuning#3",
   "action-chunking#1"
  ],
  "introduces": [],
  "purpose": "三個設計問題總結"
 }
]

Evidence pack：

=== [[action-chunking]] ===
[action-chunking#1] (fact) 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步
[action-chunking#2] (fact) π0 一次輸出 H=50 步，控制頻率可達 50 Hz
[action-chunking#3] (fact) 對比：RT-2 55B 每步都要跑一次大模型，只有 1-3 Hz ；OpenVLA 在 RTX 4090 約 6 Hz
[action-chunking#4] (inference) 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)

=== [[action-representation]] ===
[action-representation#1] (fact) RT-1 把 11 個動作維度各離散成 256 個 bin
[action-representation#2] (fact) RT-2 把每維離散成 256 個 bin，一個動作變成 8 個整數，再寫成文字 token
[action-representation#3] (fact) 好處是可以直接沿用語言模型的 next-token 預測訓練 VLM
[action-representation#4] (fact) PaLM-E 和 OpenVLA 都用「覆寫最少用的 256 個 token」來放動作
[action-representation#5] (fact) OpenVLA 以第 1 到第 99 百分位決定 bin 範圍，避免極端值
[action-representation#6] (fact) Octo 用 diffusion action head 輸出連續動作
[action-representation#7] (fact) π0 用 flow matching 的 action expert 輸出連續動作，不做離散化
[action-representation#8] (fact) 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服

=== [[co-fine-tuning]] ===
[co-fine-tuning#1] (fact) 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）
[co-fine-tuning#2] (fact) RT-2 中機器人資料約佔 PaLI-X 混合資料 50%、PaLM-E 66%
[co-fine-tuning#3] (fact) 效果：55B 模型 co-fine-tune 泛化平均 63，只用機器人資料 fine-tune 為 52
[co-fine-tuning#4] (inference) 直覺：只餵機器人資料，VLM 會忘掉網路上學到的常識；混著訓練能保留下來 (推論)

=== [[continuous-action-heads]] ===
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作
[continuous-action-heads#3] (inference) 共同直覺：從雜訊出發，一步步「修正」成合理的動作軌跡，能表示多峰（同一情境有多種合理做法）的動作分佈 (推論)
[continuous-action-heads#4] (fact) 對照組：OpenVLA fine-tune 後比 Diffusion Policy 高 20.4%，顯示離散 token 路線在其實驗中仍有競爭力

=== [[cross-embodiment]] ===
[cross-embodiment#1] (inference) embodiment 指機器人的「身體」：手臂型號、感測器、動作空間 (推論)
[cross-embodiment#2] (fact) Open X-Embodiment 匯集 22 種機器人、527 種技能的資料
[cross-embodiment#3] (fact) RT-X 證明用別台機器人的資料訓練，能提升各台機器人的能力（positive transfer）
[cross-embodiment#4] (fact) Octo 從 OXE 挑 800k 條軌跡 ；OpenVLA 挑 970k 條
[cross-embodiment#5] (fact) π0 混用 7 種機器人配置，並加入約 9.1% 開源資料
[cross-embodiment#6] (fact) 呼應 RT-1 的結論：資料多樣性比資料量更重要

=== [[octo]] ===
[octo#1] (fact) 兩種尺寸：Octo-Small 27M、Octo-Base 93M 參數
[octo#2] (fact) 不是建在預訓練 VLM 上，因此是「通用機器人 policy」而非 RT-2 定義的 VLA
[octo#3] (fact) 從 Open X-Embodiment 的 25 個資料集挑出 800k 條軌跡預訓練
[octo#4] (fact) Transformer + 可學習的 readout token（類似 BERT 的 [CLS]）；分塊遮罩注意力讓 fine-tune 時可增減輸入/輸出
[octo#5] (fact) 用 diffusion action head 預測一段連續動作（20 個 diffusion 步），見 [[continuous-action-heads]] 與 [[action-chunking]]
[octo#6] (fact) 任務可用語言（t5-base 編碼）或目標影像指定
[octo#7] (fact) Zero-shot 比 RT-1-X 高 29% 成功率，與 55B 的 RT-2-X 表現相近
[octo#8] (fact) 單張 A5000 消費級 GPU、約 100 筆示範、約 5 小時即可 fine-tune；平均比次佳基準高 52%

=== [[openvla]] ===
[openvla#1] (fact) 7B 參數開源 VLA：Prismatic-7B = 600M 視覺編碼器（融合 SigLIP 與 DINOv2）+ 2 層 MLP projector + Llama 2 7B
[openvla#2] (fact) 在 Open X-Embodiment 中挑 970k 條軌跡訓練
[openvla#3] (fact) 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token ，見 [[action-representation]]
[openvla#4] (fact) 訓練：64 張 A100 跑 14 天（21,500 A100-hours）
[openvla#5] (fact) 在 29 個任務上比 55B 的 RT-2-X 高 16.5% 絕對成功率，參數少 7 倍
[openvla#6] (fact) fine-tune 後比 Diffusion Policy 高 20.4%
[openvla#7] (fact) LoRA（rank 32，只訓練約 1.4% 參數）成功率 68.2%，全參數 fine-tune 69.7%；單張 A100 約 10-15 小時
[openvla#8] (fact) 一張 RTX 4090 約 6 Hz、約 15GB 記憶體

=== [[oxe]] ===
[oxe#1] (fact) 匯集 22 種機器人的資料，由 21 個機構合作
[oxe#2] (fact) 涵蓋 527 種技能（160,266 個任務）
[oxe#3] (fact) 用統一的資料格式釋出
[oxe#4] (fact) 用這份資料訓練的 RT-X 模型（RT-1-X、RT-2-X）出現正遷移（positive transfer），提升多種機器人的能力
[oxe#5] (inference) 這是 [[cross-embodiment]] 的代表性資料集，後來 [[octo]]、[[openvla]] 都從中挑資料預訓練 (推論)

=== [[pi0]] ===
[pi0#1] (fact) 在預訓練 VLM（PaliGemma 3B）上加一個 300M 參數的 action expert，總計 3.3B
[pi0#2] (fact) action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 ，見 [[continuous-action-heads]]
[pi0#3] (fact) 一次輸出 H=50 步的 action chunk，靈巧任務控制頻率最高 50 Hz ，見 [[action-chunking]]
[pi0#4] (fact) 超過 10,000 小時機器人資料；7 種機器人配置、68 個任務；約 9.1% 是開源資料（OXE、Bridge v2、DROID）
[pi0#5] (fact) 訓練分兩段：廣泛資料 pre-training 得到通用基底，再用少量高品質資料 post-training 到特定任務（簡單任務約 5 小時資料，最難的 100 小時以上）
[pi0#6] (fact) 示範任務：摺衣服、收拾餐桌、組紙箱、裝雞蛋、裝購物袋

=== [[rt2]] ===
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作
[rt2#2] (fact) 核心做法：把動作表示成文字 token，直接放進 VLM 的訓練資料
[rt2#3] (fact) 動作 = 6-DoF 末端位移與旋轉 + 夾爪開合 + 終止指令；連續維度離散成 256 個 bin，每個動作 = 8 個整數
[rt2#4] (fact) PaLI-X 本來就有 1000 以內每個整數的 token，可直接對應；PaLM-E 沒有，因此覆寫 256 個最少用到的 token 當動作 token
[rt2#5] (fact) 模型：RT-2-PaLI-X（5B、55B）、RT-2-PaLM-E（12B）
[rt2#6] (fact) 見 [[co-fine-tuning]]：機器人資料約佔 PaLI-X 混合資料 50%、PaLM-E 66%；55B 模型 co-fine-tune 泛化平均 63，只 fine-tune 為 52
[rt2#7] (fact) 未見情境平均：RT-2 兩個版本都是 62，RT-1 為 32，約 2 倍提升
[rt2#8] (fact) 約 6,000 次評估
[rt2#9] (fact) 湧現能力：認得新物體、理解機器人資料沒有的指令（把東西放到某個數字上）、簡單推理（選最小的物體）、chain-of-thought（拿石頭當鐵鎚）
[rt2#10] (fact) 55B 只能跑 1-3 Hz，5B 約 5 Hz，放在雲端 TPU 上由機器人透過網路呼叫
[rt2#11] (fact) 限制：網路資料不會教機器人新動作，技能仍受限於機器人資料中出現過的動作

=== [[vla]] ===
[vla#1] (fact) VLA 是把 vision-language model（VLM）微調成直接輸出機器人動作的模型
[vla#2] (fact) 輸入：相機影像 + 自然語言指令；輸出：機器人下一步（或下一段）的動作
[vla#3] (fact) 關鍵在「借用」VLM 從網路圖文學到的知識，讓機器人理解沒在機器人資料中看過的物體與指令
[vla#4] (fact) RT-1 用 Transformer 直接學動作，但沒有用網路規模預訓練的 VLM
[vla#5] (fact) Octo 是通用機器人 policy，但不是建在預訓練 VLM 上
[vla#6] (fact) RT-2、OpenVLA、π0 都建在預訓練 VLM 上，屬於 VLA

=== [[vla-timeline]] ===
[vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |
[vla-timeline#2] (fact) 2023 | [[rt2]] | 把 VLM 變成 VLA，動作寫成文字 token，co-fine-tune  |
[vla-timeline#3] (fact) 2023 | [[oxe]] | 22 種機器人資料大集合，RT-X 正遷移  |
[vla-timeline#4] (fact) 2024 | [[octo]] | 93M 開源通用 policy，diffusion head  |
[vla-timeline#5] (fact) 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5%  |
[vla-timeline#6] (fact) 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服  |
[vla-timeline#7] (inference) 趨勢一：從封閉大模型走向開源可微調 (推論)
[vla-timeline#8] (inference) 趨勢二：動作從離散 token 走向連續 chunk (推論)

每張投影片 JSON：
{"id":"s01","kind":"title|content|flow|compare|timeline|quiz|summary","objective":"O1..O5 或 null",
 "title":"...","subtitle":"(可選)",
 "bullets":[{"text":"≤60字","cite":["claim id，如 rt2#3"],"type":"fact|inference|analogy"}],
 "defines":[{"term":"術語(須與術語表同名)","def":"一句白話解釋"}],
 "flow":[{"label":"...","text":"..."}],                      (kind=flow)
 "table":{"columns":[...],"rows":[[...]],"cite":[...]},       (kind=compare)
 "timeline":[{"year":"2023","name":"RT-2","text":"...","cite":[...]}], (kind=timeline)
 "quiz":{"q":"...","options":["..."],"answer":0,"explain":"...","cite":[...]}, (kind=quiz)
 "note":"講者備註"}
規則：
1. 只能使用下方 Evidence pack 的 claim；每個 bullet / 表格 / 時間線 / quiz 解說都要 cite claim id（如 rt2#3）。
2. 所有數字必須出現在被 cite 的 claim 中。引用 (inference) claim 的句子必須標 type=inference（畫面上會標「推論」）；
   自己的比喻標 type=analogy（不需 cite，不可含數字）。
3. 觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學。下列術語第一次出現的那張投影片必須放進 defines：['VLA', 'VLM', 'policy', 'embodiment', 'DoF', 'co-fine-tuning', 'action chunk', 'diffusion', 'flow matching', '控制頻率', '正遷移']。
4. 每張最多 5 個 bullet，每個 ≤60 字；總張數 10–16。
5. 第一張 kind=title，至少 1 張 quiz、1 張 summary；每個學習目標至少 1 張。
6. 繁體中文，術語保留英文。只輸出 JSON。
輸出 JSON：{"slides":[...]}