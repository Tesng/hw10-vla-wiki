# 檢查報告 — run `v5`

- 狀態：**done**
- LLM：groq；模型：{'writer': 'openai/gpt-oss-120b', 'reviewer': 'qwen/qwen3.8-27b'}
- LLM 呼叫 152 次，prompt tokens 152049，completion tokens 45631，429 等待 13 次
- 渲染檢查方式：playwright

## 節點執行次數（graph 上每個圈轉了幾次）

| 節點 | 次數 |
|---|---|
| load_wiki | 1 |
| lint_wiki | 1 |
| query_wiki | 1 |
| evidence_cards | 1 |
| outline | 5 |
| check_outline | 4 |
| human_gate | 2 |
| draft_pages | 13 |
| ai_review | 12 |
| check_deck | 7 |
| render_html | 7 |
| check_render | 7 |
| human_final | 11 |
| finalize | 7 |
| (manual) | 3 |

## 各關卡檢查結果

| 關卡 | 結果 |
|---|---|
| outline | {"n": 0, "by_type": {}} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "playwright", "overflow": {}, "sections": 12, "external": []} |
| outline | {"n": 1, "by_type": {"typo": 1}} |
| outline | {"n": 1, "by_type": {"typo": 1}} |
| outline | {"n": 0, "by_type": {}} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "playwright", "overflow": {}, "sections": 13, "external": []} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "playwright", "overflow": {}, "sections": 13, "external": []} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "playwright", "overflow": {}, "sections": 13, "external": []} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "playwright", "overflow": {}, "sections": 13, "external": []} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "playwright", "overflow": {}, "sections": 13, "external": []} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "playwright", "overflow": {}, "sections": 13, "external": []} |

## 人工確認

- 大綱第 1 版：approve
- 人工驗收第 1 輪：revise（意見：、y）
- 人工驗收第 2 輪：revise（意見：outline: s02 標題錯字「與與」要改，s10 小測驗要分配 2 到 3 條 fact claim 而且只有一個正解，s07 不要把 chunking 和 diffusion、flow matching 放在同一張表比較（類別不同），改成比較 Octo 的 diffusion 和 π0 的 flow matching，s09 表格只比較有證據的欄位不要用「—」填空，s11 結論不要全是推論，加入 2 條 fact claim; s04: 表格每一格都要和欄位標題對得上，不要寫 N/A，只比較證據裡有的東西）
- 大綱第 4 版：approve
- 人工驗收第 3 輪：approve
- 人工驗收第 4 輪：approve
- 人工驗收第 5 輪：approve
- 人工驗收第 6 輪：revise（意見：s03: 第4、5點錯了，action chunk 不是把動作離散成 token，而是一次預測未來好幾步的動作，請刪掉這兩點，並把 action chunk 的名詞解釋改成「模型一次預測的一整段未來動作」; s04: 表格不要用「—」和 N/A，只比較證據裡有的欄位，例如接上 VLM 的難易與適合的控制頻率; s07: 刪掉「flow matching 是一次性映射、只需一次前向傳播、較快」，證據沒有這樣說，名詞解釋也一起改; s09: 刪掉「資料規模」這一欄，因為全部都是未提供; s11: 第1點主詞錯了，在 29 個任務贏 RT-2-X 16.5% 的是 OpenVLA，不是所有 VLA; s12: 「訓練時間最少 5 倍」意思錯了，原文是訓練時間最多可減少 5 倍; s01: policy 的名詞解釋不要寫「在強化學習中」，改成機器人看到當下狀態後決定動作的決策函式）
- 人工驗收第 7 輪：approve
- 人工驗收第 8 輪：revise（意見：s04: 表格中「離散 token (FAST)」那一列寫「低頻或不適高頻」是錯的，FAST 的重點正是讓離散 token 也能處理 50 Hz 的高頻動作，請把這一列改成「離散 token（256 bin）」並寫「高頻時相鄰 token 幾乎一樣、容易照抄」，FAST 另外用一句 bullet 說明它用 DCT+BPE 壓縮解決這個問題; s07: 名詞解釋中 flow matching 不要寫「一次產生結果」，證據沒有說只需一次，改成「學一個把雜訊一步步推向目標動作的方向場」，並確認每個 bullet 不超過 60 字）
- 人工驗收第 9 輪：revise（意見：s04: 表格中「離散 token (FAST)」那一列寫「低頻或不適高頻」是錯的，FAST 的重點正是讓離散 token 也能處理 50 Hz 的高頻動作，請把這一列改成「離散 token（256 bin）」並寫「高頻時相鄰 token 幾乎一樣、容易照抄」，FAST 另外用一句 bullet 說明它用 DCT+BPE 壓縮解決這個問題; s07: 名詞解釋中 flow matching 不要寫「一次產生結果」，證據沒有說只需一次，改成「學一個把雜訊一步步推向目標動作的方向場」，並確認每個 bullet 不超過 60 字）
- 人工驗收第 10 輪：revise（意見：s04: 表格中「離散 token (FAST)」那一列寫「低頻或不適高頻」是錯的，FAST 的重點正是讓離散 token 也能處理 50 Hz 的高頻動作，請把這一列改成「離散 token（256 bin）」並寫「高頻時相鄰 token 幾乎一樣、容易照抄」，FAST 另外用一句 bullet 說明它用 DCT+BPE 壓縮解決這個問題; s07: 名詞解釋中 flow matching 不要寫「一次產生結果」，證據沒有說只需一次，改成「學一個把雜訊一步步推向目標動作的方向場」，並確認每個 bullet 不超過 60 字）
- 人工驗收第 11 輪：approve

## 逐頁紀錄（小圈）

| 頁 | 逐頁稿呼叫 | AI 審查呼叫 | 審查退回 | 渲染退回 | 整份檢查退回 |
|---|---|---|---|---|---|
| s01 VLA（Vision‑Language‑Action）模型概覽 | 2 | 0 | 0 | 0 | 0 |
| s02 VLA 定義與 LLM / VLM 的關係 | 2 | 2 | 0 | 0 | 0 |
| s03 離散 token 與連續動作的表徵方式 | 5 | 3 | 0 | 0 | 0 |
| s04 離散 vs 連續：效能與頻率比較 | 11 | 9 | 0 | 0 | 0 |
| s05 資料來源：跨機體資料與 co‑fine‑tuning | 1 | 1 | 0 | 0 | 0 |
| s06 Action Chunking：提升控制頻率的關鍵 | 2 | 2 | 1 | 0 | 0 |
| s07 Octo Diffusion vs π0 Flow Matching | 15 | 7 | 0 | 0 | 0 |
| s08 從 RT‑1 到 π0 的演進路線 | 2 | 2 | 1 | 0 | 0 |
| s09 RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異 | 6 | 5 | 0 | 0 | 0 |
| s10 小測驗：檢測概念掌握 | 5 | 1 | 0 | 0 | 0 |
| s11 總結與未來展望 | 7 | 3 | 0 | 0 | 0 |
| s12 未來挑戰與研究方向 | 5 | 3 | 1 | 0 | 0 |

## 錯誤類型統計（哪個節點最常出錯）

| 節點 | 錯誤類型 | 次數 |
|---|---|---|
| draft_pages | inference_as_fact | 19 |
| ai_review | unsupported | 13 |
| ai_review | table_mismatch | 11 |
| draft_pages | too_long | 9 |
| draft_pages | ungrounded_number | 5 |
| draft_pages | uncited | 5 |
| draft_pages | disguised_claim | 4 |
| draft_pages | repeated_error | 4 |
| draft_pages | schema | 3 |
| draft_pages | undefined_term | 2 |
| draft_pages | bad_cite | 2 |
| ai_review | misleading | 2 |
| ai_review | wrong_attribution | 2 |
| (manual) | graph_bug | 1 |
| ai_review | reversed | 1 |

## 覆蓋率

- 用到的 claim：28
- 用到的論文：['fast', 'octo', 'openvla', 'oxe', 'pi0', 'rt1', 'rt2']
- 沒用到的論文：無

## Wiki 中的矛盾（⚠）

- action-representation: - ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 [[src:pi0]]；FAST 則顯示離散 token 的 π0-FA

## 事件時間線

- 12:21:30 `draft_pages` s01 第1次 ✔
- 12:21:31 `draft_pages` s02 第1次 ✔
- 12:21:32 `draft_pages` s03 第1次 ✘ undefined_term: 術語「diffusion」在這頁第一次出現，必須放進 defines；undefined_term: 術語「flow matching」在這頁第一次出現，必須放進 defines
- 12:21:34 `draft_pages` s03 第2次 ✔
- 12:21:39 `draft_pages` s04 第1次 ✘ disguised_claim: bullet 5 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉；ungrounded_number: table row 的數字 ['10', '20', '256'] 不在所引 claim ['action-representation#8', 'action-representation#10'] 中
- 12:21:54 `draft_pages` s04 第2次 ✔
- 12:22:13 `draft_pages` s05 第1次 ✔
- 12:22:30 `draft_pages` s06 第1次 ✔
- 12:22:44 `draft_pages` s07 第1次 ✘ too_long: bullet 3 有 64 字，上限 60：請至少刪掉 9 個字，或拆成兩個 bullet；disguised_claim: bullet 4 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉；disguised_claim: bullet 5 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉；inference_as_fact: table row 引用 (推論) claim 卻標成
- 12:23:14 `draft_pages` s07 第2次 ✘ too_long: bullet 3 有 61 字，上限 60：請至少刪掉 6 個字，或拆成兩個 bullet；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference
- 12:03:32 `draft_pages` s07 第4次 ✘ inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference
- 12:03:33 `draft_pages` s07 第5次 ✘ inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference
- 12:03:33 `draft_pages` s07 第5次 ✘ repeated_error: 同樣的錯誤連續兩次，停止重寫並交給人工
- 12:03:35 `draft_pages` s08 第1次 ✔
- 12:03:37 `draft_pages` s09 第1次 ✘ ungrounded_number: bullet 3 的數字 ['50'] 不在所引 claim ['pi0#2'] 中
- 12:03:59 `draft_pages` s09 第2次 ✔
- 12:04:03 `draft_pages` s10 第1次 ✘ uncited: quiz explain 沒有引用 claim
- 12:04:20 `draft_pages` s10 第2次 ✘ bad_cite: quiz explain 引用了不存在的 claim [claim1]
- 12:04:33 `draft_pages` s10 第3次 ✘ bad_cite: quiz explain 引用了不存在的 claim [claim0]
- 12:04:41 `draft_pages` s11 第1次 ✘ disguised_claim: bullet 3 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉；uncited: bullet 4 沒有引用 claim
- 12:04:57 `draft_pages` s11 第2次 ✘ inference_as_fact: bullet 3 引用 (推論) claim 卻標成 fact：請把 type 改成 inference
- 12:05:09 `draft_pages` s11 第3次 ✔
- 12:05:09 `ai_review` s02 第1次 ✔
- 12:05:10 `ai_review` s03 第1次 ✔
- 12:05:12 `ai_review` s04 第1次 ✘ table_mismatch: table row: 離散 token — 欄位標題為「token 數量」，但儲存格內容填的是「256 bin」（分箱數量/詞彙表大小），兩者概念不同。證據 #9 提到 256 bin 是離散化的方式，而非最終輸出的 token 數量。；table_mismatch: table row: 連續輸出（DCT+BPE） — 欄位標題為「token 數量」，儲存格內容為「從 700 個 token 降到 53 個」。雖然數字正確，但「從...降到...」是過程描述，不是最終的 token 數量值。此外，該行標題「連續輸出」與內容「DCT+BPE」矛盾，因為 DCT+
- 12:05:12 `ai_review` s05 第1次 ✔
- 12:06:26 `ai_review` s06 第1次 ✘ wrong_attribution: bullet 2 — 投影片稱「若一次輸出 H=50 步，控制頻率可達 50 Hz」，暗示這是通用原理或特定模型（未指明）的特性。但證據 [action-chunking#2] 明確指出這是 **π0** 模型的特性（「π0 一次輸出 H=50 步...」）。投影片省略了主體 π0，容易讓讀者誤以為任何模型只要 chunk size 為 50 就能達到 50 Hz，或者誤將此數據歸因於標題中的通用概念而非特定模型。
- 12:06:28 `ai_review` s07 第1次 ✘ unsupported: bullet 1 — 投影片稱 Chunking「提升思考與控制的頻率分離」，但證據 [action-chunking#4] 僅說明其直覺是「把『思考頻率』和『控制頻率』分開」，並未提及「提升」這一效果或程度，屬於過度解讀。；unsupported: bullet 3 — 投影片稱 π0「只需一次前向即可產生完整動作序列」，但證據 [continuous-action-heads#2] 僅說明使用 conditional flow matching 產生連續動作，並未明確指出步數為「一次前向」或「只需一次」。雖然 Flow Matching 通常比 Diffusion
- 12:08:03 `ai_review` s08 第1次 ✘ unsupported: bullet 1 — 投影片稱 RT-1「展示了基本 VLA 框架」，但證據 [vla-timeline#1] 僅列出技術規格（35M Transformer, 130k 示範, 動作離散成 token），並未提及它展示了 VLA 框架或具有此歷史地位。；unsupported: bullet 2 — 投影片稱 RT-2「進一步將視覺語言模型擴展為 VLA」，證據 [vla-timeline#2] 僅說「把 VLM 變成 VLA」。「進一步」暗示了與前一代（RT-1）的比較關係，但證據中沒有提供 RT-1 與 RT-2 的對比資訊，屬於推論。；unsupported:
- 12:09:59 `ai_review` s09 第1次 ✘ table_mismatch: table row: π0 — 表格欄位標題為 'Inference Speed'，但 π0 這一列的內容寫的是 '約 100 ms（π0‑FAST 約 750 ms）'。根據證據 [action-representation#11]，100 ms 是 diffusion 版 π0 的速度，而 750 ms 是 π0-FAST 的速度。將 π0-FAST 的速度放在 π0 的欄位中，且未明確區分兩者，導致數據歸屬混亂，容易讓讀者誤以為 π0 本身有兩種速度或混淆了模型版本。
- 12:10:59 `ai_review` s11 第1次 ✔
- 12:11:01 `draft_pages` s04 第3次 ✔
- 12:11:02 `draft_pages` s06 第2次 ✔
- 12:11:19 `draft_pages` s07 第6次 ✘ inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference
- 12:11:33 `draft_pages` s07 第7次 ✘ inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference；inference_as_fact: table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference
- 12:11:33 `draft_pages` s07 第7次 ✘ repeated_error: 同樣的錯誤連續兩次，停止重寫並交給人工
- 12:11:55 `draft_pages` s08 第2次 ✔
- 12:12:17 `draft_pages` s09 第3次 ✔
- 12:12:19 `ai_review` s04 第2次 ✘ table_mismatch: table row: 離散 token — 表格中「離散 token」對應的「token 數量」填為 700，但根據證據 [action-representation#10]，700 是 FAST 壓縮前（50 Hz 1 秒動作）的樣本數，並非離散 token 表示方式本身的固定 token 數量。此外，證據 [action-representation#9] 提到離散 token 在高頻時相鄰相關，並未給出離散 token 的具體數量為 700。將 700 直接歸類為離散 token 的 token 數量容易誤導讀者認為離散表示固定為 700 tokens，而
- 12:12:19 `ai_review` s06 第2次 ✔
- 12:12:20 `ai_review` s07 第2次 ✔
- 12:12:20 `ai_review` s08 第2次 ✔
- 12:14:26 `ai_review` s09 第2次 ✔
- 12:14:27 `draft_pages` s04 第4次 ✔
- 12:14:30 `ai_review` s04 第3次 ✘ unsupported: bullet 3 — 投影片寫「1 秒 700 個樣本」，但證據 [action-representation#10] 明確寫的是「50 Hz 的 1 秒動作從 700 個 token 降到 53 個」。證據中的 700 是指壓縮前的 token 數量（或等效單位），而非原始物理樣本數（50Hz 下 1 秒應為 50 個樣本點，若考慮多維度可能更多，但證據原文用詞為 token）。將「token」改為「樣本」屬於改變了證據中的關鍵術語，且 50Hz 對應 700 個樣本在數值上也不合邏輯（除非是多維度，但證據未說明維度，只說 token）。更嚴謹地說，證據說的是「70
- 12:17:29 `human_final`  第次 ✔
- 13:12:54 `human_final`  第次 ✔
- 13:42:03 `draft_pages` s02 第2次 ✔
- 13:42:22 `draft_pages` s03 第3次 ✘ too_long: bullet 4 有 61 字，上限 60：請至少刪掉 6 個字，或拆成兩個 bullet
- 13:42:29 `draft_pages` s03 第4次 ✔
- 13:42:46 `draft_pages` s04 第5次 ✔
- 13:43:05 `draft_pages` s12 第1次 ✘ schema: bullets 第 3 項的 type 是「conflict」，只能是 fact、inference 或 analogy（矛盾的內容請用 fact 並把兩邊都寫出來）
- 13:43:13 `draft_pages` s12 第2次 ✘ too_long: bullet 3 有 93 字，上限 60：請至少刪掉 38 個字，或拆成兩個 bullet
- 13:43:36 `draft_pages` s12 第3次 ✔
- 13:43:37 `ai_review` s02 第2次 ✔
- 13:43:37 `ai_review` s03 第2次 ✔
- 13:43:40 `ai_review` s04 第4次 ✘ unsupported: bullet 3 — 投影片寫「1 秒 700 個樣本」，但證據 [action-representation#10] 明確寫的是「50 Hz 的 1 秒動作從 700 個 token 降到 53 個」。證據中的 700 指的是壓縮前的 token 數量（或等效單位），而非原始物理樣本數（50Hz 下 1 秒應為 50 個樣本點，若考慮多維度可能更多，但證據原文用詞為 token）。將「token」改為「樣本」屬於改變了證據中的關鍵術語，且 700 這個數字在證據中是作為壓縮前的 token 數出現的。；table_mismatch: table row: 離散 to
- 13:43:53 `ai_review` s12 第1次 ✔
- 13:44:04 `draft_pages` s04 第6次 ✘ too_long: bullet 3 有 64 字，上限 60：請至少刪掉 9 個字，或拆成兩個 bullet
- 13:44:07 `draft_pages` s04 第7次 ✔
- 13:44:08 `ai_review` s04 第5次 ✔
- -- `(manual)`  第次 ✘ graph_bug: 大綱連修多版後，只和上一版比較，s07/s09/s10/s11 沒有依新版大綱重寫 → 修正 human_gate 的比較基準並補寫這 4 頁
- 14:23:49 `draft_pages` s07 第8次 ✘ schema: defines 第 2 項必須是物件 {"term": "術語", "def": "白話解釋"}
- 14:23:51 `draft_pages` s07 第9次 ✘ too_long: bullet 2 有 63 字，上限 60：請至少刪掉 8 個字，或拆成兩個 bullet
- 14:23:52 `draft_pages` s07 第10次 ✘ too_long: bullet 2 有 61 字，上限 60：請至少刪掉 6 個字，或拆成兩個 bullet
- 14:23:54 `draft_pages` s09 第4次 ✔
- 14:24:04 `draft_pages` s10 第4次 ✘ schema: quiz.explain 裡寫了 claim id；claim id 只能放在 quiz.cite，解說文字不要出現
- 14:24:23 `draft_pages` s10 第5次 ✔
- 14:24:33 `draft_pages` s11 第4次 ✘ ungrounded_number: bullet 2 的數字 ['0'] 不在所引 claim ['vla-timeline#6'] 中；uncited: bullet 3 沒有引用 claim；uncited: bullet 4 沒有引用 claim；uncited: bullet 5 沒有引用 claim
- 14:24:46 `draft_pages` s11 第5次 ✘ ungrounded_number: bullet 2 的數字 ['0'] 不在所引 claim ['vla-timeline#6'] 中
- 14:24:59 `draft_pages` s11 第6次 ✘ ungrounded_number: bullet 2 的數字 ['0'] 不在所引 claim ['vla-timeline#6'] 中
- 14:24:59 `draft_pages` s11 第6次 ✘ repeated_error: 同樣的錯誤連續兩次，停止重寫並交給人工
- 14:25:00 `ai_review` s07 第3次 ✔
- 14:25:02 `ai_review` s09 第3次 ✘ table_mismatch: table row: RT‑2 — 表格中 RT-2 的「資料規模」欄位填寫為「同 RT‑1 參數規模」。首先，「參數規模」屬於模型架構參數，而非資料規模（應為示範數量或資料集大小）；其次，證據 [rt2#1] 僅說明 RT-2 是微調 VLM，並未提供具體的參數數量或資料規模數字，更未說明其與 RT-1 相同。RT-1 是 35M 的小型 Transformer，而 RT-2 基於大型 VLM（如 PaLM-E），兩者參數規模差異巨大，此處描述嚴重錯誤且混淆了欄位定義。；table_mismatch: table row: OpenVLA — 表格中 Open
- 14:25:02 `ai_review` s10 第1次 ✔
- 14:25:11 `ai_review` s11 第2次 ✔
- 14:25:27 `draft_pages` s09 第5次 ✔
- 14:25:28 `ai_review` s09 第4次 ✔
- 14:30:08 `human_final`  第次 ✔
- 14:39:41 `draft_pages` s01 第2次 ✔
- 14:39:42 `draft_pages` s03 第5次 ✔
- 14:39:44 `draft_pages` s04 第8次 ✔
- 14:39:50 `draft_pages` s07 第11次 ✘ too_long: bullet 2 有 61 字，上限 60：請至少刪掉 6 個字，或拆成兩個 bullet
- 14:40:05 `draft_pages` s07 第12次 ✘ too_long: bullet 2 有 61 字，上限 60：請至少刪掉 6 個字，或拆成兩個 bullet
- 14:40:05 `draft_pages` s07 第12次 ✘ repeated_error: 同樣的錯誤連續兩次，停止重寫並交給人工
- 14:40:20 `draft_pages` s09 第6次 ✔
- 14:40:31 `draft_pages` s11 第7次 ✔
- 14:40:49 `draft_pages` s12 第4次 ✔
- 14:40:49 `ai_review` s03 第3次 ✔
- 14:40:50 `ai_review` s04 第6次 ✔
- 14:40:50 `ai_review` s07 第4次 ✔
- 14:40:51 `ai_review` s09 第5次 ✔
- 14:40:51 `ai_review` s11 第3次 ✔
- 14:40:54 `ai_review` s12 第2次 ✘ reversed: bullet 2 — 投影片寫「訓練時間最多可減少 5 倍」，但證據 [fast#5] 寫的是「訓練時間最多少 5 倍」。在中文語境中，「減少 5 倍」通常被理解為時間變短（效率提升），而「少 5 倍」若嚴格對應英文 '5x less' 或 '5x faster' 也是指效率提升。然而，仔細看證據原文「訓練時間最多少 5 倍」，這裡的「少」字在中文裡搭配「倍數」是語法錯誤或極度罕見的用法，通常應為「快 5 倍」或「減少 80%」。但更關鍵的是，如果證據原文是「5x less training time」，投影片寫「減少 5 倍」是符合直覺的。讓我們再仔細看證據：`訓練時間最
- 14:41:05 `draft_pages` s12 第5次 ✔
- 14:42:23 `ai_review` s12 第3次 ✔
- 14:54:47 `human_final`  第次 ✔
- 14:54:48 `draft_pages` s04 第9次 ✔
- 14:54:50 `draft_pages` s07 第13次 ✔
- 14:54:50 `ai_review` s04 第7次 ✔
- 14:54:51 `ai_review` s07 第5次 ✔
- 14:54:58 `human_final`  第次 ✔
- 14:55:00 `draft_pages` s04 第10次 ✔
- 14:55:01 `draft_pages` s07 第14次 ✔
- 14:55:02 `ai_review` s04 第8次 ✔
- 14:55:02 `ai_review` s07 第6次 ✔
- 14:55:06 `human_final`  第次 ✔
- 14:57:45 `draft_pages` s04 第11次 ✔
- 14:57:46 `draft_pages` s07 第15次 ✔
- 14:57:46 `ai_review` s04 第9次 ✔
- 14:57:46 `ai_review` s07 第7次 ✔
