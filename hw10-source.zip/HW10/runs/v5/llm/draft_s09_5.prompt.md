你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s09",
 "kind": "compare",
 "objective": "O5",
 "title": "RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異",
 "claims": [
  "vla-timeline#1",
  "rt2#1",
  "openvla#3",
  "pi0#2"
 ],
 "introduces": [],
 "purpose": "對比四個代表模型在動作表徵、資料規模與推論速度上的差異"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[openvla]] ===
[openvla#3] (fact) 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token ，見 [[action-representation]]

=== [[pi0]] ===
[pi0#2] (fact) action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 ，見 [[continuous-action-heads]]

=== [[rt2]] ===
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作

=== [[vla-timeline]] ===
[vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'diffusion', 'embodiment', 'flow matching', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s09",
 "kind": "compare",
 "objective": "O5",
 "title": "RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異",
 "table": {
  "columns": [
   "模型",
   "動作表徵",
   "資料規模",
   "推論方式"
  ],
  "rows": [
   [
    "RT‑1",
    "動作離散化為 token",
    "35M 參數、130k 示範",
    "離散 token 輸出"
   ],
   [
    "RT‑2",
    "直接輸出機器人動作（VLA）",
    "同 RT‑1 參數規模",
    "離散 token 輸出"
   ],
   [
    "OpenVLA",
    "每維 256 個 bin，覆寫 Llama 最少用的 256 token",
    "同 RT‑1 參數規模",
    "離散 token 輸出"
   ],
   [
    "π0",
    "條件 flow matching 直接產生連續動作",
    "同 RT‑1 參數規模",
    "連續動作輸出"
   ]
  ],
  "cite": [
   "vla-timeline#1",
   "rt2#1",
   "openvla#3",
   "pi0#2"
  ]
 },
 "bullets": [
  {
   "text": "RT‑1 以 35M Transformer、130k 示範，將每個動作維度離散成 token",
   "cite": [
    "vla-timeline#1"
   ],
   "type": "fact"
  },
  {
   "text": "RT‑2 提出 VLA 概念，微調 VLM 直接輸出機器人動作",
   "cite": [
    "rt2#1"
   ],
   "type": "fact"
  },
  {
   "text": "OpenVLA 以 256 個 bin 覆寫 Llama 最少用的 256 個 token，仍屬離散化",
   "cite": [
    "openvla#3"
   ],
   "type": "fact"
  },
  {
   "text": "π0 使用 conditional flow matching，模型直接產生連續動作",
   "cite": [
    "pi0#2"
   ],
   "type": "fact"
  },
  {
   "text": "從離散 token 到連續動作的演進，提升了推論的流暢度與精細度",
   "type": "inference",
   "cite": [
    "pi0#2"
   ]
  }
 ],
 "defines": [],
 "note": "強調四個模型在動作表徵的演變：從最早的離散 token 到最後的連續輸出，讓觀眾感受技術的漸進與效能衝擊。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s09",
  "type": "ai_review_table_mismatch",
  "msg": "table row: RT‑2：表格中 RT-2 的「資料規模」欄位填寫為「同 RT‑1 參數規模」。首先，「參數規模」屬於模型架構參數，而非資料規模（應為示範數量或資料集大小）；其次，證據 [rt2#1] 僅說明 RT-2 是微調 VLM，並未提供具體的參數數量或資料規模數字，更未說明其與 RT-1 相同。RT-1 是 35M 的小型 Transformer，而 RT-2 基於大型 VLM（如 PaLM-E），兩者參數規模差異巨大，此處描述嚴重錯誤且混淆了欄位定義。；建議：將「資料規模」欄位改為證據支持的內容，或若無具體數據則標註為「未提供」或「基於大型 VLM」。切勿填寫「同 RT-1 參數規模」，因為這在事實上是錯誤的，且與欄位標題「資料規模」不符。"
 },
 {
  "slide": "s09",
  "type": "ai_review_table_mismatch",
  "msg": "table row: OpenVLA：表格中 OpenVLA 的「資料規模」欄位填寫為「同 RT‑1 參數規模」。同樣地，「參數規模」不是「資料規模」。此外，證據 [openvla#3] 僅描述動作離散化方法，未提及參數規模或資料規模與 RT-1 相同。OpenVLA 通常基於 Llama-2 7B，參數規模遠大於 RT-1 的 35M。；建議：修正欄位內容，不要將參數規模填入資料規模欄位。若無證據支持具體數字，應留空或標註「未提供」。"
 },
 {
  "slide": "s09",
  "type": "ai_review_table_mismatch",
  "msg": "table row: π0：表格中 π0 的「資料規模」欄位填寫為「同 RT‑1 參數規模」。同樣存在欄位錯位（參數 vs 資料）及事實錯誤（π0 基於大型 VLM，參數遠大於 RT-1）。證據 [pi0#2] 僅描述 action expert 和 flow matching，未提及參數規模與 RT-1 相同。；建議：修正欄位內容，移除錯誤的參數比較，並確保欄位標題與內容對應。"
 },
 {
  "slide": "s09",
  "type": "ai_review_unsupported",
  "msg": "bullet 5：標記為 [inference] 的推論「提升了推論的流暢度與精細度」。證據 [pi0#2] 僅說明 π0 使用 conditional flow matching 直接輸出連續動作，並未提供關於「推論流暢度」（如速度、延遲）或「精細度」（如任務成功率、誤差）的比較數據或結論。雖然連續動作通常被認為更平滑，但證據中沒有支持「提升」這一比較性結論的依據，屬於過度推論。；建議：修改為更保守的陳述，例如「從離散 token 轉向連續動作，旨在提供更平滑的動作輸出」，或刪除關於「提升流暢度與精細度」的具體效果斷言，除非有額外證據支持。"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。