你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s07",
 "kind": "compare",
 "objective": "O4",
 "title": "Chunking 與 Diffusion / Flow Matching 的比較",
 "claims": [
  "continuous-action-heads#1",
  "continuous-action-heads#2",
  "action-chunking#4"
 ],
 "introduces": [
  "diffusion",
  "flow matching"
 ],
 "purpose": "比較 chunk‑based 預測與 diffusion / flow matching 兩種連續動作生成方式"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-chunking]] ===
[action-chunking#4] (inference) 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)

=== [[continuous-action-heads]] ===
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作

這頁必須在 defines 解釋的術語：['diffusion', 'flow matching']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s07",
 "kind": "compare",
 "objective": "O4",
 "title": "Chunking 與 Diffusion / Flow Matching 的比較",
 "table": {
  "columns": [
   "Method",
   "Generation Steps",
   "Key Mechanism"
  ],
  "rows": [
   [
    "Chunking",
    "一次多算幾步，分離思考頻率與控制頻率",
    "在推論時一次產生多個連續動作 chunk"
   ],
   [
    "Diffusion (Octo)",
    "20 個去噪步",
    "Transformer readout token 接 diffusion action head，逐步去噪產生連續動作"
   ],
   [
    "Flow Matching (π0)",
    "一次前向",
    "使用 conditional flow matching 由 300M action expert 權重直接產生連續動作"
   ]
  ],
  "cite": [
   "action-chunking#4",
   "continuous-action-heads#1",
   "continuous-action-heads#2"
  ]
 },
 "bullets": [
  {
   "text": "Chunking 讓大模型在推論時一次產生多步，提升思考與控制的頻率分離",
   "cite": [
    "action-chunking#4"
   ],
   "type": "inference"
  },
  {
   "text": "Octo 以 diffusion head 透過 20 步去噪，逐步生成連續動作 chunk",
   "cite": [
    "continuous-action-heads#1"
   ],
   "type": "fact"
  },
  {
   "text": "π0 採用 conditional flow matching，只需一次前向即可產生完整動作序列",
   "cite": [
    "continuous-action-heads#2"
   ],
   "type": "fact"
  }
 ],
 "defines": [
  {
   "term": "diffusion",
   "def": "透過多步去噪，將隨機噪聲逐漸轉換為連續動作序列的生成方法"
  },
  {
   "term": "flow matching",
   "def": "學習噪聲到目標分布的流向，使模型一次前向即可直接產生連續動作"
  }
 ],
 "note": "說明 chunk‑based 預測的效率優勢，並比較 diffusion 需要多步去噪 vs flow matching 的一次性生成。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s07",
  "type": "ai_review_unsupported",
  "msg": "bullet 1：投影片稱 Chunking「提升思考與控制的頻率分離」，但證據 [action-chunking#4] 僅說明其直覺是「把『思考頻率』和『控制頻率』分開」，並未提及「提升」這一效果或程度，屬於過度解讀。；建議：改為「Chunking 讓大模型在推論時一次產生多步，以分離思考頻率與控制頻率」"
 },
 {
  "slide": "s07",
  "type": "ai_review_unsupported",
  "msg": "bullet 3：投影片稱 π0「只需一次前向即可產生完整動作序列」，但證據 [continuous-action-heads#2] 僅說明使用 conditional flow matching 產生連續動作，並未明確指出步數為「一次前向」或「只需一次」。雖然 Flow Matching 通常比 Diffusion 步數少，但證據未提供此具體數字或「一次」的斷言，屬於無中生有的細節。；建議：刪除「只需一次前向」，改為「π0 採用 conditional flow matching 產生連續動作序列」"
 },
 {
  "slide": "s07",
  "type": "ai_review_unsupported",
  "msg": "table row: Flow Matching (π0)：Generation Steps 欄位填寫「一次前向」，證據 [continuous-action-heads#2] 未提及具體步數或「一次前向」的說法，屬於證據未支持的細節。；建議：改為「較少步數」或「Flow Matching 步數」，或根據其他可靠來源確認，若無證據則刪除具體步數描述"
 },
 {
  "slide": "s07",
  "type": "ai_review_unsupported",
  "msg": "table row: Flow Matching (π0)：Key Mechanism 欄位提到「由 300M action expert 權重直接產生」，證據 [continuous-action-heads#2] 確實提到「300M 的 action expert 權重」，但投影片將其描述為「直接產生」，而證據僅說「用 conditional flow matching 產生」。雖然機制描述大致符合，但「直接」一詞可能暗示無中間過程，與 Flow Matching 的迭代或流式性質可能略有出入，且證據未強調「直接」。不過主要問題在於上一個欄位的「一次前向」。此處可視為可接受，但需確認「直接」是否為誤導。更嚴格的檢查是：證據說「掛一組...權重，用...產生」，投影片說「由...權重直接產生」，語意相近。主要錯誤仍在步數。；建議：建議將 Generation Steps 改為「Flow Matching 步數」或留空，Key Mechanism 保持不變或微調為「使用 300M action expert 與 conditional flow matching 產生連續動作」"
 },
 {
  "slide": "s07",
  "type": "ai_review_unsupported",
  "msg": "名詞解釋 flow matching：解釋中稱「使模型一次前向即可直接產生連續動作」，證據 [continuous-action-heads#2] 未支持「一次前向」這一具體步數描述。Flow Matching 通常需要多步（雖然比 Diffusion 少），證據未提供此細節。；建議：刪除「一次前向」，改為「使模型能以較少步數產生連續動作」或僅描述機制「學習噪聲到目標分布的流向，以產生連續動作」"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。