你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s03",
 "kind": "content",
 "objective": "O2",
 "title": "離散 token vs 連續動作的表徵方式",
 "claims": [
  "action-representation#1",
  "action-representation#6",
  "action-representation#7"
 ],
 "introduces": [
  "action chunk"
 ],
 "purpose": "說明動作如何被編碼為離散 token 或連續向量，並引出 action chunk 的概念"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#1] (fact) RT-1 把 11 個動作維度各離散成 256 個 bin
[action-representation#6] (fact) Octo 用 diffusion action head 輸出連續動作
[action-representation#7] (fact) π0 用 flow matching 的 action expert 輸出連續動作，不做離散化

這頁必須在 defines 解釋的術語：['action chunk']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'policy']

你上一版的這頁：
{
 "id": "s03",
 "kind": "content",
 "objective": "O2",
 "title": "離散 token vs 連續動作的表徵方式",
 "bullets": [
  {
   "text": "RT-1 將 11 個動作維度各離散成 256 個 bin，形成離散 token",
   "cite": [
    "action-representation#1"
   ],
   "type": "fact"
  },
  {
   "text": "Octo 使用 diffusion action head 直接輸出連續動作向量",
   "cite": [
    "action-representation#6"
   ],
   "type": "fact"
  },
  {
   "text": "π0 透過 flow matching 的 action expert 產生連續動作，不做離散化",
   "cite": [
    "action-representation#7"
   ],
   "type": "fact"
  },
  {
   "text": "離散化讓模型可利用語言模型的 token 預訓練，而連續化則保留更細緻的控制資訊",
   "cite": [
    "action-representation#1",
    "action-representation#6",
    "action-representation#7"
   ],
   "type": "inference"
  }
 ],
 "defines": [
  {
   "term": "action chunk",
   "def": "將一段連續的機器人動作切分為固定長度的向量序列，供模型一次處理"
  }
 ],
 "note": "說明離散 vs 連續的差異後，引出 action chunk 作為兩者的橋樑"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s03",
  "type": "undefined_term",
  "msg": "術語「diffusion」在這頁第一次出現，必須放進 defines"
 },
 {
  "slide": "s03",
  "type": "undefined_term",
  "msg": "術語「flow matching」在這頁第一次出現，必須放進 defines"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"content","objective","title","bullets":[{"text","cite":["claim id"],"type":"fact|inference|analogy"}],"defines":[{"term","def"}],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。