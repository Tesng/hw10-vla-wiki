你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異
bullet 1 [fact] RT‑2 首次將 Vision‑Language‑Action 模型微調，使 VLM 直接產生機器人動作  (cite: rt2#1)
bullet 2 [fact] OpenVLA 以 256 個離散 bin 取代連續動作，覆寫 Llama 最少使用的 token  (cite: openvla#3)
bullet 3 [fact] π0 以條件 flow matching 訓練，直接輸出連續動作，適用靈巧任務  (cite: pi0#2)
bullet 4 [conflict] π0‑FAST 雖能在摺衣服任務追平 diffusion 版 π0，但推論較慢（約 750 ms）  (cite: action-representation#11)
表格欄位：Model | Action Representation | Data Scale | Inference Speed  (cite: rt2#1, openvla#3, pi0#2, action-representation#11)
table row: RT‑1 | — | — | —
table row: RT‑2 | VLA 直接輸出機器人動作 | — | —
table row: OpenVLA | 每維 256 個離散 bin（第1‑99百分位） | — | —
table row: π0 | 連續動作 via conditional flow matching | — | 約 100 ms

證據（claim id → 原文）：
[action-representation#11] (fact) ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 ；FAST 則顯示離散 token 的 π0-FAST 在摺衣服上也能追平 diffusion 版 π0，但推論較慢（約 750 ms 對 100 ms）
[openvla#3] (fact) 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token ，見 [[action-representation]]
[pi0#2] (fact) action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 ，見 [[continuous-action-heads]]
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
- inference（推論）句也要查：推論不能和證據矛盾（例如證據說 A 比較慢，推論卻說 A 提升速度）
真正的比喻不用查證。
若這頁是 quiz：只有 answer 指到的那個選項必須正確且有證據支持；其他選項是「故意設計的錯誤選項」，本來就應該是錯的，
不要要求把它們改成正確。要檢查的是：正解有沒有證據支持、是不是剛好只有一個選項正確（如果有兩個以上都對，type 用 misleading）、
解說有沒有講清楚為什麼其他選項錯。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。