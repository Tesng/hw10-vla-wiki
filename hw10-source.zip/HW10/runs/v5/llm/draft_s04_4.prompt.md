你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "claims": [
  "action-representation#8",
  "action-representation#9",
  "action-representation#10"
 ],
 "introduces": [
  "控制頻率"
 ],
 "purpose": "比較離散 token 與連續輸出在高頻控制上的優缺點"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#8] (fact) 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服
[action-representation#9] (fact) 樸素的 256 bin 在高頻時相鄰 token 高度相關，模型容易陷入「照抄」的局部解
[action-representation#10] (fact) FAST 先做 DCT 再用 BPE 壓縮，50 Hz 的 1 秒動作從 700 個 token 降到 53 個

這頁必須在 defines 解釋的術語：['控制頻率']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'policy']

你上一版的這頁：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "table": {
  "columns": [
   "表示方式",
   "控制頻率",
   "token 數量"
  ],
  "rows": [
   [
    "離散 token",
    "較低",
    "700"
   ],
   [
    "連續輸出 (π0)",
    "50 Hz",
    "53"
   ]
  ],
  "cite": [
   "action-representation#8",
   "action-representation#9",
   "action-representation#10"
  ]
 },
 "bullets": [
  {
   "text": "離散 token 最容易接上 VLM，但在高頻控制上受限",
   "cite": [
    "action-representation#8"
   ],
   "type": "fact"
  },
  {
   "text": "相鄰 token 高度相關會導致模型照抄局部解",
   "cite": [
    "action-representation#9"
   ],
   "type": "fact"
  },
  {
   "text": "FAST 先做 DCT 再用 BPE 壓縮，將 1 秒 700 個樣本降至 53 個 token",
   "cite": [
    "action-representation#10"
   ],
   "type": "fact"
  },
  {
   "text": "連續輸出更適合靈巧動作，如 π0 以 50 Hz 摺衣服",
   "cite": [
    "action-representation#8"
   ],
   "type": "fact"
  }
 ],
 "defines": [
  {
   "term": "控制頻率",
   "def": "機器人每秒執行控制指令的次數，頻率越高可實現更細緻的動作"
  }
 ],
 "note": "提醒觀眾：離散化易於與視覺語言模型結合，但若要高頻、靈巧的動作，連續化與壓縮技術更具優勢。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s04",
  "type": "ai_review_table_mismatch",
  "msg": "table row: 離散 token：表格中「離散 token」對應的「token 數量」填為 700，但根據證據 [action-representation#10]，700 是 FAST 壓縮前（50 Hz 1 秒動作）的樣本數，並非離散 token 表示方式本身的固定 token 數量。此外，證據 [action-representation#9] 提到離散 token 在高頻時相鄰相關，並未給出離散 token 的具體數量為 700。將 700 直接歸類為離散 token 的 token 數量容易誤導讀者認為離散表示固定為 700 tokens，而實際上 700 是原始數據點數，FAST 將其壓縮為 53 tokens。；建議：建議將表格欄位改為「原始樣本數 (1s @ 50Hz)」或明確標註 700 為「壓縮前樣本數」，或將該欄位改為「壓縮後 token 數」並填入 FAST 的 53（若比較對象是 FAST），或留空/標註 N/A 若無具體離散 token 數量數據。若意圖比較 FAST 與連續輸出，應明確標示 700 為 FAST 的輸入樣本數，而非離散 token 的通用屬性。"
 },
 {
  "slide": "s04",
  "type": "ai_review_table_mismatch",
  "msg": "table row: 連續輸出 (π0)：表格中「連續輸出 (π0)」對應的「token 數量」填為 53。然而，證據 [action-representation#10] 指出 53 是 FAST（離散 token 方法）壓縮後的 token 數量，而非連續輸出 π0 的 token 數量。連續輸出通常不產生離散 token，或者其維度與離散 token 數量不可直接比較。將 FAST 的 53 tokens 歸到連續輸出 π0 名下是錯誤歸屬。；建議：應將 53 移至「離散 token (FAST)」那一列（如果該列代表 FAST 方法），或將連續輸出的 token 數量標註為 N/A 或具體的向量維度（若證據提供）。根據證據，53 是 FAST 的結果，應歸屬於離散/FAST 方法。"
 },
 {
  "slide": "s04",
  "type": "ai_review_misleading",
  "msg": "bullet 3：Bullet 3 說「將 1 秒 700 個樣本降至 53 個 token」，這與證據 [action-representation#10] 一致。但結合表格來看，表格將 700 歸為離散 token 的數量，53 歸為連續輸出的數量，這與 Bullet 3 的描述（FAST 是離散方法，產出 53 tokens）矛盾。表格的歸屬錯誤導致整體邏輯混亂。；建議：修正表格，使 700 和 53 都正確歸屬於 FAST（離散）方法的壓縮前後對比，或明確區分不同方法的指標。"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。