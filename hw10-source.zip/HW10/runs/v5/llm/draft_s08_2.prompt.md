你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s08",
 "kind": "timeline",
 "objective": "O5",
 "title": "從 RT‑1 到 π0 的演進路線",
 "claims": [
  "vla-timeline#1",
  "vla-timeline#2",
  "vla-timeline#5",
  "vla-timeline#6"
 ],
 "introduces": [],
 "purpose": "呈現主要模型的時間線，說明每個階段的技術突破"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[vla-timeline]] ===
[vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |
[vla-timeline#2] (fact) 2023 | [[rt2]] | 把 VLM 變成 VLA，動作寫成文字 token，co-fine-tune  |
[vla-timeline#5] (fact) 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5%  |
[vla-timeline#6] (fact) 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服  |

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'diffusion', 'embodiment', 'flow matching', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s08",
 "kind": "timeline",
 "objective": "O5",
 "title": "從 RT‑1 到 π0 的演進路線",
 "timeline": [
  {
   "year": "2022",
   "name": "RT‑1",
   "text": "35M Transformer，130k 示範，動作離散成 token",
   "cite": [
    "vla-timeline#1"
   ]
  },
  {
   "year": "2023",
   "name": "RT‑2",
   "text": "把 VLM 變成 VLA，動作寫成文字 token，co‑fine‑tune",
   "cite": [
    "vla-timeline#2"
   ]
  },
  {
   "year": "2024",
   "name": "OpenVLA",
   "text": "7B 開源 VLA，贏 55B RT‑2‑X 16.5%",
   "cite": [
    "vla-timeline#5"
   ]
  },
  {
   "year": "2024",
   "name": "π0",
   "text": "3.3B，flow matching，50 Hz 摺衣服",
   "cite": [
    "vla-timeline#6"
   ]
  }
 ],
 "bullets": [
  {
   "text": "RT‑1 用小型 Transformer 直接將離散動作編碼為 token，展示了基本 VLA 框架",
   "cite": [
    "vla-timeline#1"
   ],
   "type": "fact"
  },
  {
   "text": "RT‑2 進一步將視覺語言模型擴展為 VLA，透過文字 token 表示動作並共同微調",
   "cite": [
    "vla-timeline#2"
   ],
   "type": "fact"
  },
  {
   "text": "OpenVLA 以 7B 參數開源，對抗更大模型 RT‑2‑X，取得 16.5% 的相對優勢",
   "cite": [
    "vla-timeline#5"
   ],
   "type": "fact"
  },
  {
   "text": "π0 採用 flow matching 技術，實現 50 Hz 的高頻控制，成功摺衣服",
   "cite": [
    "vla-timeline#6"
   ],
   "type": "fact"
  }
 ],
 "defines": [],
 "note": "強調每一步的技術突破如何累積，讓觀眾看到從離散 token 到高頻 flow matching 的演變"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s08",
  "type": "ai_review_unsupported",
  "msg": "bullet 1：投影片稱 RT-1「展示了基本 VLA 框架」，但證據 [vla-timeline#1] 僅列出技術規格（35M Transformer, 130k 示範, 動作離散成 token），並未提及它展示了 VLA 框架或具有此歷史地位。；建議：刪除「展示了基本 VLA 框架」，改為描述其技術特徵，例如：「RT-1 使用 35M Transformer 將離散動作編碼為 token」。"
 },
 {
  "slide": "s08",
  "type": "ai_review_unsupported",
  "msg": "bullet 2：投影片稱 RT-2「進一步將視覺語言模型擴展為 VLA」，證據 [vla-timeline#2] 僅說「把 VLM 變成 VLA」。「進一步」暗示了與前一代（RT-1）的比較關係，但證據中沒有提供 RT-1 與 RT-2 的對比資訊，屬於推論。；建議：刪除「進一步」，直接陳述：「RT-2 將視覺語言模型擴展為 VLA，透過文字 token 表示動作並共同微調」。"
 },
 {
  "slide": "s08",
  "type": "ai_review_unsupported",
  "msg": "bullet 3：投影片稱 OpenVLA「對抗更大模型 RT-2-X」，證據 [vla-timeline#5] 僅說「贏 55B RT-2-X 16.5%」。「對抗」一詞帶有主觀敘事色彩，證據僅陳述了性能比較結果，未描述兩者之間的對抗關係。；建議：改為客觀陳述：「OpenVLA 以 7B 參數開源，在性能上超越 55B 的 RT-2-X 16.5%」。"
 },
 {
  "slide": "s08",
  "type": "ai_review_unsupported",
  "msg": "bullet 4：投影片稱 π0「成功摺衣服」，證據 [vla-timeline#6] 僅列出「50 Hz 摺衣服」。雖然「摺衣服」是任務名稱，但「成功」一詞暗示了任務完成的結果或成功率，證據中未明確說明是否「成功」完成，僅列出了該任務。；建議：改為：「π0 採用 flow matching 技術，實現 50 Hz 的高頻控制，執行摺衣服任務」。"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"timeline","objective","title","timeline":[{"year","name","text","cite":["claim id"]}],"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。