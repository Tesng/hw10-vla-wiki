你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s06",
 "kind": "content",
 "objective": "O4",
 "title": "Action Chunking：提升控制頻率的關鍵",
 "claims": [
  "action-chunking#1",
  "action-chunking#2",
  "action-chunking#3"
 ],
 "introduces": [],
 "purpose": "解釋為何一次預測多步動作能把推論頻率與控制頻率分離"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-chunking]] ===
[action-chunking#1] (fact) 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步
[action-chunking#2] (fact) π0 一次輸出 H=50 步，控制頻率可達 50 Hz
[action-chunking#3] (fact) 對比：RT-2 55B 每步都要跑一次大模型，只有 1-3 Hz ；OpenVLA 在 RTX 4090 約 6 Hz

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s06",
 "kind": "content",
 "objective": "O4",
 "title": "Action Chunking：提升控制頻率的關鍵",
 "bullets": [
  {
   "text": "模型一次輸出未來多步動作（稱為 chunk），而非逐步預測",
   "cite": [
    "action-chunking#1"
   ],
   "type": "fact"
  },
  {
   "text": "若一次輸出 H=50 步，控制頻率可達 50 Hz",
   "cite": [
    "action-chunking#2"
   ],
   "type": "fact"
  },
  {
   "text": "RT‑2 55B 每步都要跑一次大模型，實測僅 1‑3 Hz；OpenVLA 在 RTX 4090 約 6 Hz",
   "cite": [
    "action-chunking#3"
   ],
   "type": "fact"
  },
  {
   "text": "因此，action‑chunking 能把推論頻率與控制頻率分離，提升實時控制能力",
   "cite": [
    "action-chunking#1",
    "action-chunking#2"
   ],
   "type": "inference"
  }
 ],
 "defines": [],
 "note": "說明一次預測多步的概念，並比較 RT‑2 與 OpenVLA 的實測頻率，讓觀眾感受頻率提升的實際意義。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s06",
  "type": "ai_review_wrong_attribution",
  "msg": "bullet 2：投影片稱「若一次輸出 H=50 步，控制頻率可達 50 Hz」，暗示這是通用原理或特定模型（未指明）的特性。但證據 [action-chunking#2] 明確指出這是 **π0** 模型的特性（「π0 一次輸出 H=50 步...」）。投影片省略了主體 π0，容易讓讀者誤以為任何模型只要 chunk size 為 50 就能達到 50 Hz，或者誤將此數據歸因於標題中的通用概念而非特定模型。；建議：改為「π0 模型一次輸出 H=50 步，控制頻率可達 50 Hz」或明確標註此數據來源於 π0。"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"content","objective","title","bullets":[{"text","cite":["claim id"],"type":"fact|inference|analogy"}],"defines":[{"term","def"}],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。