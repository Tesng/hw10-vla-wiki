你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：Octo Diffusion vs π0 Flow Matching
bullet 1 [fact] Octo 透過 diffusion action head，經 20 個去噪步產出連續動作  (cite: continuous-action-heads#1)
bullet 2 [fact] π0 用 300M action expert，透過 conditional flow matching 產生連續動作  (cite: continuous-action-heads#2)
表格欄位：Model | Action Head | Generation Process  (cite: continuous-action-heads#1, continuous-action-heads#2, action-representation#6)
table row: Octo | Diffusion action head | Readout token → diffusion head → 20 denoising steps產生連續動作 chunk
table row: π0 | Conditional flow matching expert | Action expert (300M) 使用 flow matching 直接產生連續動作
名詞解釋 diffusion：逐步去噪的生成方法，從噪聲逐漸恢復目標訊號
名詞解釋 flow matching：學一個把雜訊一步步推向目標動作的方向場

證據（claim id → 原文）：
[action-representation#6] (fact) Octo 用 diffusion action head 輸出連續動作
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
- inference（推論）句也要查：推論不能和證據矛盾（例如證據說 A 比較慢，推論卻說 A 提升速度）
真正的比喻不用查證。
若這頁是 quiz：只有 answer 指到的那個選項必須正確且有證據支持；其他選項是「故意設計的錯誤選項」，本來就應該是錯的，
不要要求把它們改成正確。要檢查的是：正解有沒有證據支持、是不是剛好只有一個選項正確（如果有兩個以上都對，type 用 misleading）、
解說有沒有講清楚為什麼其他選項錯。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。