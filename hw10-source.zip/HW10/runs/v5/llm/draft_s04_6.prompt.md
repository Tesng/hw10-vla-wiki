你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "claims": [
  "action-representation#8",
  "action-representation#9",
  "action-representation#10"
 ],
 "introduces": [
  "控制頻率"
 ],
 "purpose": "比較離散 token 與連續輸出在高頻控制上的優缺點"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#8] (fact) 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服
[action-representation#9] (fact) 樸素的 256 bin 在高頻時相鄰 token 高度相關，模型容易陷入「照抄」的局部解
[action-representation#10] (fact) FAST 先做 DCT 再用 BPE 壓縮，50 Hz 的 1 秒動作從 700 個 token 降到 53 個

這頁必須在 defines 解釋的術語：['控制頻率']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'policy']

你上一版的這頁：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "table": {
  "columns": [
   "表示方式",
   "控制頻率",
   "壓縮後 token 數"
  ],
  "rows": [
   [
    "離散 token (FAST)",
    "50 Hz",
    "53"
   ],
   [
    "連續輸出 (π0)",
    "50 Hz",
    ""
   ]
  ],
  "cite": [
   "action-representation#8",
   "action-representation#9",
   "action-representation#10"
  ]
 },
 "bullets": [
  {
   "text": "離散 token 最容易接上 VLM，但在高頻控制上受限",
   "cite": [
    "action-representation#8"
   ],
   "type": "fact"
  },
  {
   "text": "相鄰離散 token 高度相關，模型易陷入照抄局部解",
   "cite": [
    "action-representation#9"
   ],
   "type": "fact"
  },
  {
   "text": "FAST 先做 DCT 再用 BPE 壓縮，將 1 秒 700 個樣本降至 53 個 token",
   "cite": [
    "action-representation#10"
   ],
   "type": "fact"
  },
  {
   "text": "連續輸出更適合靈巧動作，如 π0 以 50 Hz 摺衣服",
   "cite": [
    "action-representation#8"
   ],
   "type": "fact"
  }
 ],
 "defines": [
  {
   "term": "控制頻率",
   "def": "機器人每秒執行控制指令的次數，頻率越高可實現更細緻的動作"
  }
 ],
 "note": "提醒觀眾：離散化易於與視覺語言模型結合，但若要高頻、靈巧的動作，連續化與壓縮技術更具優勢。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s04",
  "type": "ai_review_unsupported",
  "msg": "bullet 3：投影片寫「1 秒 700 個樣本」，但證據 [action-representation#10] 明確寫的是「50 Hz 的 1 秒動作從 700 個 token 降到 53 個」。證據中的 700 指的是壓縮前的 token 數量（或等效單位），而非原始物理樣本數（50Hz 下 1 秒應為 50 個樣本點，若考慮多維度可能更多，但證據原文用詞為 token）。將「token」改為「樣本」屬於改變了證據中的關鍵術語，且 700 這個數字在證據中是作為壓縮前的 token 數出現的。；建議：改為「FAST 先做 DCT 再用 BPE 壓縮，將 50 Hz 的 1 秒動作從 700 個 token 降至 53 個 token」"
 },
 {
  "slide": "s04",
  "type": "ai_review_table_mismatch",
  "msg": "table row: 離散 token (FAST)：表格中「離散 token (FAST)」對應的「控制頻率」欄位填的是「50 Hz」。雖然證據 [action-representation#10] 提到 FAST 處理 50 Hz 的動作，但證據 [action-representation#8] 指出「離散 token...在高頻控制上受限」，且通常離散 token 方法（如 FAST）是為了降低頻率或處理特定頻率，而連續輸出（π0）才特別強調適合高頻。更關鍵的是，表格將 FAST 和 π0 都標記為 50 Hz，這本身可能沒錯（如果 FAST 也用於 50Hz 場景），但結合 bullet 1 說離散 token 在高頻受限，這裡直接寫 50Hz 可能讓讀者誤以為離散 token 能輕鬆達到 50Hz 的高頻控制，而證據暗示其受限。不過，最明顯的錯誤在於證據 [action-representation#10] 說 FAST 是將 50Hz 的動作壓縮，所以 50Hz 是輸入頻率。但通常 FAST 這類方法是用來降低生成頻率或處理低頻序列。讓我們再仔細看證據。證據 #10 說 FAST 處理 50Hz 的動作。證據 #8 說連續輸出更適合高頻。如果 FAST 也能處理 50Hz，那表格填 50Hz 似乎符合證據 #10。但是，通常離散 token 的瓶頸在於頻率。如果證據沒有明確說 FAST 的*輸出*控制頻率是 50Hz，而是說它*處理* 50Hz 的動作，那麼表格欄位「控制頻率」若指輸出頻率，則可能有誤。然而，更嚴格的檢查是：證據 #10 說「50 Hz 的 1 秒動作...降到 53 個 token」。這意味著輸入是 50Hz。FAST 的輸出頻率通常低於輸入或等於輸入？如果 FAST 生成 53 個 token 代表 1 秒，那輸出頻率就是 53 Hz？或者這 53 個 token 是經過 BPE 後的表示，解碼後恢復為 50Hz？證據未明確說明 FAST 的*輸出*控制頻率。但對比 π0 明確說「以 50 Hz 摺衣服」，FAST 的 50Hz 是作為*輸入*特徵出現的。將輸入頻率直接填在「控制頻率」（通常指輸出執行頻率）欄位可能具有誤導性，或者至少證據支持不足（unsupported）。；建議：建議確認 FAST 的輸出控制頻率。若證據僅提及處理 50Hz 輸入，則不應直接斷言其控制頻率為 50Hz，或應標註為「輸入 50Hz」。若 FAST 實際輸出頻率不同，則此處為錯。基於證據 #10 的措辭「50 Hz 的 1 秒動作...」，這描述的是動作序列的頻率，而非 FAST 模型的輸出控制頻率。因此填 50Hz 屬於 unsupported 或 misleading。"
 },
 {
  "slide": "s04",
  "type": "ai_review_table_mismatch",
  "msg": "table row: 連續輸出 (π0)：表格中「連續輸出 (π0)」對應的「壓縮後 token 數」欄位為空。雖然連續輸出確實沒有離散 token 的概念，但表格設計上留空可能讓讀者困惑，或者應該填寫「N/A」或「-」。不過，這不算嚴重錯誤。主要問題在於上一行。；建議：建議填寫「N/A」或「-」以明確表示不適用。"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。