你是教學簡報設計者。主題：VLA（Vision-Language-Action）模型是什麼？
觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
學習目標：
- O1: 說出 VLA 的定義，以及它和 LLM / VLM 的關係
- O2: 理解動作怎麼變成模型輸出：離散 token vs 連續動作
- O3: 知道 VLA 的資料從哪來：跨機體資料與 co-fine-tuning
- O4: 理解為什麼需要 action chunking 才能高頻控制
- O5: 能比較 RT-1 → π0 的演進與代表模型

Wiki index：

# VLA Wiki — Index

## Concepts
- [[vla]] — VLA 的定義與三個設計問題
- [[action-representation]] — 離散 token vs 連續動作
- [[co-fine-tuning]] — 機器人資料 + 網路資料混訓
- [[cross-embodiment]] — 跨機器人資料與正遷移
- [[action-chunking]] — 一次預測一段動作
- [[continuous-action-heads]] — diffusion / flow matching
- [[vla-timeline]] — 2022–2025 演進

## Sources
- [[rt1]] — RT-1 (2022)
- [[rt2]] — RT-2 (2023)
- [[oxe]] — Open X-Embodiment (2023)
- [[octo]] — Octo (2024)
- [[openvla]] — OpenVLA (2024)
- [[pi0]] — π0 (2024)
- [[fast]] — FAST (2025)


證據卡（只能使用這些 claim；每條前面是 claim id）：

=== [[action-chunking]] ===
[action-chunking#1] (fact) 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步
[action-chunking#2] (fact) π0 一次輸出 H=50 步，控制頻率可達 50 Hz
[action-chunking#3] (fact) 對比：RT-2 55B 每步都要跑一次大模型，只有 1-3 Hz ；OpenVLA 在 RTX 4090 約 6 Hz
[action-chunking#4] (inference) 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)

=== [[action-representation]] ===
[action-representation#1] (fact) RT-1 把 11 個動作維度各離散成 256 個 bin
[action-representation#2] (fact) RT-2 把每維離散成 256 個 bin，一個動作變成 8 個整數，再寫成文字 token
[action-representation#3] (fact) 好處是可以直接沿用語言模型的 next-token 預測訓練 VLM
[action-representation#4] (fact) PaLM-E 和 OpenVLA 都用「覆寫最少用的 256 個 token」來放動作
[action-representation#5] (fact) OpenVLA 以第 1 到第 99 百分位決定 bin 範圍，避免極端值
[action-representation#6] (fact) Octo 用 diffusion action head 輸出連續動作
[action-representation#7] (fact) π0 用 flow matching 的 action expert 輸出連續動作，不做離散化
[action-representation#8] (fact) 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服
[action-representation#9] (fact) 樸素的 256 bin 在高頻時相鄰 token 高度相關，模型容易陷入「照抄」的局部解
[action-representation#10] (fact) FAST 先做 DCT 再用 BPE 壓縮，50 Hz 的 1 秒動作從 700 個 token 降到 53 個
[action-representation#11] (conflict) ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 ；FAST 則顯示離散 token 的 π0-FAST 在摺衣服上也能追平 diffusion 版 π0，但推論較慢（約 750 ms 對 100 ms）
[action-representation#12] (inference) 可能原因：差別不在「離散或連續」本身，而在 token 化方式是否壓掉高頻冗餘；兩者在訓練速度與推論速度上各有取捨 (推論)

=== [[co-fine-tuning]] ===
[co-fine-tuning#1] (fact) 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）
[co-fine-tuning#2] (fact) RT-2 中機器人資料約佔 PaLI-X 混合資料 50%、PaLM-E 66%
[co-fine-tuning#3] (fact) 效果：55B 模型 co-fine-tune 泛化平均 63，只用機器人資料 fine-tune 為 52
[co-fine-tuning#4] (inference) 直覺：只餵機器人資料，VLM 會忘掉網路上學到的常識；混著訓練能保留下來 (推論)

=== [[continuous-action-heads]] ===
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作
[continuous-action-heads#3] (inference) 共同直覺：從雜訊出發，一步步「修正」成合理的動作軌跡，能表示多峰（同一情境有多種合理做法）的動作分佈 (推論)
[continuous-action-heads#4] (fact) 對照組：OpenVLA fine-tune 後比 Diffusion Policy 高 20.4%，顯示離散 token 路線在其實驗中仍有競爭力

=== [[cross-embodiment]] ===
[cross-embodiment#1] (inference) embodiment 指機器人的「身體」：手臂型號、感測器、動作空間 (推論)
[cross-embodiment#2] (fact) Open X-Embodiment 匯集 22 種機器人、527 種技能的資料
[cross-embodiment#3] (fact) RT-X 證明用別台機器人的資料訓練，能提升各台機器人的能力（positive transfer）
[cross-embodiment#4] (fact) Octo 從 OXE 挑 800k 條軌跡 ；OpenVLA 挑 970k 條
[cross-embodiment#5] (fact) π0 混用 7 種機器人配置，並加入約 9.1% 開源資料
[cross-embodiment#6] (fact) 呼應 RT-1 的結論：資料多樣性比資料量更重要

=== [[fast]] ===
[fast#1] (fact) 問題：以往 VLA 每個時間步、每個維度各切 256 個 bin；控制頻率一高，相鄰 token 幾乎一樣，模型學到「照抄前一個」就能讓 loss 很低
[fast#2] (fact) 做法：每個維度先做離散餘弦轉換（DCT）→ 係數四捨五入（丟掉不重要的）→ 低頻在前攤平 → 用 BPE 壓縮，詞表預設 1024
[fast#3] (fact) 壓縮效果：50 Hz 摺 T 恤的 1 秒動作，原本 700 個 token，FAST 只要 53 個（13.2 倍）
[fast#4] (fact) 每段動作約 30 個 token／手臂，幾乎不隨控制頻率增加
[fast#5] (fact) π0-FAST（自回歸、離散 token）在摺衣服等任務上追平用 diffusion 的 π0，訓練時間最多少 5 倍
[fast#6] (fact) 代價：在 4090 上每段動作推論約 750 ms，diffusion 版 π0 約 100 ms

=== [[octo]] ===
[octo#1] (fact) 兩種尺寸：Octo-Small 27M、Octo-Base 93M 參數
[octo#2] (fact) 不是建在預訓練 VLM 上，因此是「通用機器人 policy」而非 RT-2 定義的 VLA
[octo#3] (fact) 從 Open X-Embodiment 的 25 個資料集挑出 800k 條軌跡預訓練
[octo#4] (fact) Transformer + 可學習的 readout token（類似 BERT 的 [CLS]）；分塊遮罩注意力讓 fine-tune 時可增減輸入/輸出
[octo#5] (fact) 用 diffusion action head 預測一段連續動作（20 個 diffusion 步），見 [[continuous-action-heads]] 與 [[action-chunking]]
[octo#6] (fact) 任務可用語言（t5-base 編碼）或目標影像指定
[octo#7] (fact) Zero-shot 比 RT-1-X 高 29% 成功率，與 55B 的 RT-2-X 表現相近
[octo#8] (fact) 單張 A5000 消費級 GPU、約 100 筆示範、約 5 小時即可 fine-tune；平均比次佳基準高 52%

=== [[openvla]] ===
[openvla#1] (fact) 7B 參數開源 VLA：Prismatic-7B = 600M 視覺編碼器（融合 SigLIP 與 DINOv2）+ 2 層 MLP projector + Llama 2 7B
[openvla#2] (fact) 在 Open X-Embodiment 中挑 970k 條軌跡訓練
[openvla#3] (fact) 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token ，見 [[action-representation]]
[openvla#4] (fact) 訓練：64 張 A100 跑 14 天（21,500 A100-hours）
[openvla#5] (fact) 在 29 個任務上比 55B 的 RT-2-X 高 16.5% 絕對成功率，參數少 7 倍
[openvla#6] (fact) fine-tune 後比 Diffusion Policy 高 20.4%
[openvla#7] (fact) LoRA（rank 32，只訓練約 1.4% 參數）成功率 68.2%，全參數 fine-tune 69.7%；單張 A100 約 10-15 小時
[openvla#8] (fact) 一張 RTX 4090 約 6 Hz、約 15GB 記憶體

=== [[oxe]] ===
[oxe#1] (fact) 匯集 22 種機器人的資料，由 21 個機構合作
[oxe#2] (fact) 涵蓋 527 種技能（160,266 個任務）
[oxe#3] (fact) 用統一的資料格式釋出
[oxe#4] (fact) 用這份資料訓練的 RT-X 模型（RT-1-X、RT-2-X）出現正遷移（positive transfer），提升多種機器人的能力
[oxe#5] (inference) 這是 [[cross-embodiment]] 的代表性資料集，後來 [[octo]]、[[openvla]] 都從中挑資料預訓練 (推論)

=== [[pi0]] ===
[pi0#1] (fact) 在預訓練 VLM（PaliGemma 3B）上加一個 300M 參數的 action expert，總計 3.3B
[pi0#2] (fact) action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 ，見 [[continuous-action-heads]]
[pi0#3] (fact) 一次輸出 H=50 步的 action chunk，靈巧任務控制頻率最高 50 Hz ，見 [[action-chunking]]
[pi0#4] (fact) 超過 10,000 小時機器人資料；7 種機器人配置、68 個任務；約 9.1% 是開源資料（OXE、Bridge v2、DROID）
[pi0#5] (fact) 訓練分兩段：廣泛資料 pre-training 得到通用基底，再用少量高品質資料 post-training 到特定任務（簡單任務約 5 小時資料，最難的 100 小時以上）
[pi0#6] (fact) 示範任務：摺衣服、收拾餐桌、組紙箱、裝雞蛋、裝購物袋

=== [[rt2]] ===
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作
[rt2#2] (fact) 核心做法：把動作表示成文字 token，直接放進 VLM 的訓練資料
[rt2#3] (fact) 動作 = 6-DoF 末端位移與旋轉 + 夾爪開合 + 終止指令；連續維度離散成 256 個 bin，每個動作 = 8 個整數
[rt2#4] (fact) PaLI-X 本來就有 1000 以內每個整數的 token，可直接對應；PaLM-E 沒有，因此覆寫 256 個最少用到的 token 當動作 token
[rt2#5] (fact) 模型：RT-2-PaLI-X（5B、55B）、RT-2-PaLM-E（12B）
[rt2#6] (fact) 見 [[co-fine-tuning]]：機器人資料約佔 PaLI-X 混合資料 50%、PaLM-E 66%；55B 模型 co-fine-tune 泛化平均 63，只 fine-tune 為 52
[rt2#7] (fact) 未見情境平均：RT-2 兩個版本都是 62，RT-1 為 32，約 2 倍提升
[rt2#8] (fact) 約 6,000 次評估
[rt2#9] (fact) 湧現能力：認得新物體、理解機器人資料沒有的指令（把東西放到某個數字上）、簡單推理（選最小的物體）、chain-of-thought（拿石頭當鐵鎚）
[rt2#10] (fact) 55B 只能跑 1-3 Hz，5B 約 5 Hz，放在雲端 TPU 上由機器人透過網路呼叫
[rt2#11] (fact) 限制：網路資料不會教機器人新動作，技能仍受限於機器人資料中出現過的動作

=== [[vla]] ===
[vla#1] (fact) VLA 是把 vision-language model（VLM）微調成直接輸出機器人動作的模型
[vla#2] (fact) 輸入：相機影像 + 自然語言指令；輸出：機器人下一步（或下一段）的動作
[vla#3] (fact) 關鍵在「借用」VLM 從網路圖文學到的知識，讓機器人理解沒在機器人資料中看過的物體與指令
[vla#4] (fact) RT-1 用 Transformer 直接學動作，但沒有用網路規模預訓練的 VLM
[vla#5] (fact) Octo 是通用機器人 policy，但不是建在預訓練 VLM 上
[vla#6] (fact) RT-2、OpenVLA、π0 都建在預訓練 VLM 上，屬於 VLA

=== [[vla-timeline]] ===
[vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |
[vla-timeline#2] (fact) 2023 | [[rt2]] | 把 VLM 變成 VLA，動作寫成文字 token，co-fine-tune  |
[vla-timeline#3] (fact) 2023 | [[oxe]] | 22 種機器人資料大集合，RT-X 正遷移  |
[vla-timeline#4] (fact) 2024 | [[octo]] | 93M 開源通用 policy，diffusion head  |
[vla-timeline#5] (fact) 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5%  |
[vla-timeline#6] (fact) 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服  |
[vla-timeline#7] (fact) 2025 | [[fast]] | DCT + BPE 動作 token 化，離散路線追平 diffusion  |
[vla-timeline#8] (inference) 趨勢一：從封閉大模型走向開源可微調 (推論)
[vla-timeline#9] (inference) 趨勢二：動作從離散 token 走向連續 chunk，但 FAST 讓離散路線重新有競爭力 (推論)

上一版大綱：
[
 {
  "id": "s01",
  "kind": "title",
  "objective": null,
  "title": "VLA（Vision‑Language‑Action）模型概覽",
  "claims": [],
  "introduces": [
   "VLA",
   "VLM",
   "policy"
  ],
  "purpose": "說明本次簡報主題與核心概念"
 },
 {
  "id": "s02",
  "kind": "content",
  "objective": "O1",
  "title": "VLA 定義與與 LLM / VLM 的關係",
  "claims": [
   "vla#1",
   "vla#2",
   "vla#3"
  ],
  "introduces": [],
  "purpose": "讓觀眾能說出 VLA 的定義，並了解它是把預訓練 VLM 微調成直接輸出機器人動作的模型"
 },
 {
  "id": "s03",
  "kind": "content",
  "objective": "O2",
  "title": "離散 token vs 連續動作的表徵方式",
  "claims": [
   "action-representation#1",
   "action-representation#6",
   "action-representation#7"
  ],
  "introduces": [
   "action chunk"
  ],
  "purpose": "說明動作如何被編碼為離散 token 或連續向量，並引出 action chunk 的概念"
 },
 {
  "id": "s04",
  "kind": "compare",
  "objective": "O2",
  "title": "離散 vs 連續：效能與頻率比較",
  "claims": [
   "action-representation#8",
   "action-representation#9",
   "action-representation#10"
  ],
  "introduces": [
   "控制頻率"
  ],
  "purpose": "比較離散 token 與連續輸出在高頻控制上的優缺點"
 },
 {
  "id": "s05",
  "kind": "content",
  "objective": "O3",
  "title": "資料來源：跨機體資料與 co‑fine‑tuning",
  "claims": [
   "cross-embodiment#2",
   "cross-embodiment#3",
   "co-fine-tuning#1"
  ],
  "introduces": [
   "co-fine-tuning",
   "embodiment",
   "正遷移"
  ],
  "purpose": "說明 VLA 訓練資料如何結合多機體軌跡與大規模視覺語言資料"
 },
 {
  "id": "s06",
  "kind": "content",
  "objective": "O4",
  "title": "Action Chunking：提升控制頻率的關鍵",
  "claims": [
   "action-chunking#1",
   "action-chunking#2",
   "action-chunking#3"
  ],
  "introduces": [],
  "purpose": "解釋為何一次預測多步動作能把推論頻率與控制頻率分離"
 },
 {
  "id": "s07",
  "kind": "compare",
  "objective": "O4",
  "title": "Chunking 與 Diffusion / Flow Matching 的比較",
  "claims": [
   "continuous-action-heads#1",
   "continuous-action-heads#2",
   "action-chunking#4"
  ],
  "introduces": [
   "diffusion",
   "flow matching"
  ],
  "purpose": "比較 chunk‑based 預測與 diffusion / flow matching 兩種連續動作生成方式"
 },
 {
  "id": "s08",
  "kind": "timeline",
  "objective": "O5",
  "title": "從 RT‑1 到 π0 的演進路線",
  "claims": [
   "vla-timeline#1",
   "vla-timeline#2",
   "vla-timeline#5",
   "vla-timeline#6"
  ],
  "introduces": [],
  "purpose": "呈現主要模型的時間線，說明每個階段的技術突破"
 },
 {
  "id": "s09",
  "kind": "compare",
  "objective": "O5",
  "title": "RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異",
  "claims": [
   "rt2#1",
   "openvla#3",
   "pi0#2",
   "action-representation#11"
  ],
  "introduces": [],
  "purpose": "對比四個代表模型在動作表徵、資料規模與推論速度上的差異，並說明衝突點"
 },
 {
  "id": "s10",
  "kind": "quiz",
  "objective": null,
  "title": "小測驗：檢測概念掌握",
  "claims": [],
  "introduces": [],
  "purpose": "透過選擇題確認觀眾對 VLA 定義、action chunk 與資料來源的理解"
 },
 {
  "id": "s11",
  "kind": "summary",
  "objective": null,
  "title": "總結與未來展望",
  "claims": [
   "vla-timeline#8",
   "vla-timeline#9"
  ],
  "introduces": [],
  "purpose": "回顧學習目標，並討論 VLA 發展的趨勢與開源可微調的方向"
 }
]

人工審閱意見（優先處理）：
s02 標題錯字「與與」要改，s10 小測驗要分配 2 到 3 條 fact claim 而且只有一個正解，s07 不要把 chunking 和 diffusion、flow matching 放在同一張表比較（類別不同），改成比較 Octo 的 diffusion 和 π0 的 flow matching，s09 表格只比較有證據的欄位不要用「—」填空，s11 結論不要全是推論，加入 2 條 fact claim

請規劃 10–14 張投影片的大綱，輸出 JSON：
{"slides":[{"id":"s01","kind":"title|content|flow|compare|timeline|quiz|summary","objective":"O1..O5 或 null",
"title":"...","claims":["這張會用到的 claim id"],"introduces":["這張要解釋的術語"],"purpose":"這張要讓觀眾懂什麼"}]}
規則：
1. 第一張 kind=title；至少 1 張 quiz、1 張 summary；O1–O5 每個至少 1 張；教學順序由淺入深。
2. content/flow/compare/timeline 每張至少 3 條 claim（內容太薄撐不起一頁）；quiz 至少 2 條（正解與解說要有證據）；claim id 必須完全照抄證據卡。
   compare 表格的每一列都要比較「同一類東西」，欄位只放證據裡有的資訊，不要用「—」填空。
3. 術語表：['VLA', 'VLM', 'policy', 'embodiment', 'DoF', 'co-fine-tuning', 'action chunk', 'diffusion', 'flow matching', '控制頻率', '正遷移']。某張的標題或 purpose 用到術語時，該張或更早的投影片必須在 introduces 裡放這個術語。
4. 標成 (conflict) 的 claim 代表論文之間有矛盾，若使用要把兩邊都講清楚。
5. 繁體中文，術語保留英文。