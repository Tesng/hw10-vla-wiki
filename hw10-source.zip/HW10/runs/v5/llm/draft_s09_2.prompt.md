你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s09",
 "kind": "compare",
 "objective": "O5",
 "title": "RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異",
 "claims": [
  "rt2#1",
  "openvla#3",
  "pi0#2",
  "action-representation#11"
 ],
 "introduces": [],
 "purpose": "對比四個代表模型在動作表徵、資料規模與推論速度上的差異，並說明衝突點"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#11] (conflict) ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 ；FAST 則顯示離散 token 的 π0-FAST 在摺衣服上也能追平 diffusion 版 π0，但推論較慢（約 750 ms 對 100 ms）

=== [[openvla]] ===
[openvla#3] (fact) 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token ，見 [[action-representation]]

=== [[pi0]] ===
[pi0#2] (fact) action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 ，見 [[continuous-action-heads]]

=== [[rt2]] ===
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'diffusion', 'embodiment', 'flow matching', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s09",
 "kind": "compare",
 "objective": "O5",
 "title": "RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異",
 "table": {
  "columns": [
   "Model",
   "Action Representation",
   "Data Scale",
   "Inference Speed"
  ],
  "rows": [
   [
    "RT‑1",
    "—",
    "—",
    "—"
   ],
   [
    "RT‑2",
    "VLA 直接輸出機器人動作",
    "—",
    "—"
   ],
   [
    "OpenVLA",
    "每維 256 個離散 bin（第1‑99百分位）",
    "—",
    "—"
   ],
   [
    "π0",
    "連續動作 via conditional flow matching",
    "—",
    "約 100 ms（π0‑FAST 約 750 ms）"
   ]
  ],
  "cite": [
   "rt2#1",
   "openvla#3",
   "pi0#2",
   "action-representation#11"
  ]
 },
 "bullets": [
  {
   "text": "RT‑2 首次將 Vision‑Language‑Action 模型微調，使 VLM 直接產生機器人動作",
   "cite": [
    "rt2#1"
   ],
   "type": "fact"
  },
  {
   "text": "OpenVLA 以 256 個離散 bin 取代連續動作，覆寫 Llama 最少使用的 token",
   "cite": [
    "openvla#3"
   ],
   "type": "fact"
  },
  {
   "text": "π0 以條件 flow matching 訓練，直接輸出連續動作，適用 50 Hz 靈巧任務",
   "cite": [
    "pi0#2"
   ],
   "type": "fact"
  },
  {
   "text": "π0‑FAST 雖能在摺衣服任務追平 diffusion 版 π0，但推論較慢（約 750 ms 對 100 ms）",
   "cite": [
    "action-representation#11"
   ],
   "type": "conflict"
  }
 ],
 "defines": [],
 "note": "比較時強調：離散化 vs 連續化的取捨會影響推論速度與任務靈活度，觀眾可思考哪種方式較適合高頻控制。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s09",
  "type": "ungrounded_number",
  "msg": "bullet 3 的數字 ['50'] 不在所引 claim ['pi0#2'] 中"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。