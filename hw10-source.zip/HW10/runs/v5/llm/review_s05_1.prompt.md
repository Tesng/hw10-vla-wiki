你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：資料來源：跨機體資料與 co‑fine‑tuning
bullet 1 [fact] co‑fine‑tuning 會在微調 VLM 時，同時加入機器人軌跡與大規模視覺語言資料（如 VQA）  (cite: co-fine-tuning#1)
bullet 2 [fact] Open X‑Embodiment 收錄了 22 種機器人、527 種技能的跨機體資料  (cite: cross-embodiment#2)
bullet 3 [inference] RT‑X 的實驗顯示，使用其他機器人的資料訓練，可提升所有機器人的能力，屬於正遷移  (cite: cross-embodiment#3)
名詞解釋 co-fine-tuning：在微調視覺語言模型時，同時使用機器人軌跡資料與大規模的視覺語言資料。
名詞解釋 embodiment：機器人的硬體形態與感測/執行能力的總稱。
名詞解釋 正遷移：從一個領域或機體學到的知識，能提升另一個領域或機體的表現。

證據（claim id → 原文）：
[co-fine-tuning#1] (fact) 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）
[cross-embodiment#2] (fact) Open X-Embodiment 匯集 22 種機器人、527 種技能的資料
[cross-embodiment#3] (fact) RT-X 證明用別台機器人的資料訓練，能提升各台機器人的能力（positive transfer）

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
- inference（推論）句也要查：推論不能和證據矛盾（例如證據說 A 比較慢，推論卻說 A 提升速度）
真正的比喻不用查證。
若這頁是 quiz：只有 answer 指到的那個選項必須正確且有證據支持；其他選項是「故意設計的錯誤選項」，本來就應該是錯的，
不要要求把它們改成正確。要檢查的是：正解有沒有證據支持、是不是剛好只有一個選項正確（如果有兩個以上都對，type 用 misleading）、
解說有沒有講清楚為什麼其他選項錯。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。