你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s12",
 "kind": "flow",
 "objective": null,
 "title": "未來挑戰與研究方向",
 "claims": [
  "action-representation#11",
  "fast#5",
  "fast#6"
 ],
 "introduces": [
  "diffusion",
  "flow matching"
 ],
 "purpose": "討論離散 vs 連續路線的衝突與可能的融合策略"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#11] (conflict) ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 ；FAST 則顯示離散 token 的 π0-FAST 在摺衣服上也能追平 diffusion 版 π0，但推論較慢（約 750 ms 對 100 ms）

=== [[fast]] ===
[fast#5] (fact) π0-FAST（自回歸、離散 token）在摺衣服等任務上追平用 diffusion 的 π0，訓練時間最多少 5 倍
[fast#6] (fact) 代價：在 4090 上每段動作推論約 750 ms，diffusion 版 π0 約 100 ms

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'diffusion', 'embodiment', 'flow matching', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s12",
 "kind": "flow",
 "objective": null,
 "title": "未來挑戰與研究方向",
 "flow": [
  {
   "label": "衝突",
   "text": "π0 連續 flow matching 處理 50 Hz 靈巧任務；π0-FAST 離散 token 在摺衣服上追平 diffusion 版，但推論較慢"
  }
 ],
 "bullets": [
  {
   "text": "π0-FAST（自回歸、離散 token）在摺衣服等任務上追平 diffusion 版 π0，訓練時間最少 5 倍",
   "cite": [
    "fast#5"
   ],
   "type": "fact"
  },
  {
   "text": "在 4090 上每段動作推論約 750 ms，diffusion 版 π0 約 100 ms",
   "cite": [
    "fast#6"
   ],
   "type": "fact"
  },
  {
   "text": "π0 論文以連續 flow matching 處理 50 Hz 靈巧任務；FAST 顯示離散 token 的 π0-FAST 在摺衣服上也能追平 diffusion 版 π0，但推論較慢",
   "cite": [
    "action-representation#11"
   ],
   "type": "fact"
  }
 ],
 "defines": [],
 "note": "強調離散 vs 連續的速度與效能取捨，邀請觀眾思考融合策略"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s12",
  "type": "too_long",
  "msg": "bullet 3 有 93 字，上限 60：請至少刪掉 38 個字，或拆成兩個 bullet"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"flow","objective","title","flow":[{"label","text"}],"bullets":[...同 content],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。