你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s03",
 "kind": "content",
 "objective": "O2",
 "title": "離散 token 與連續動作的表徵方式",
 "claims": [
  "action-representation#1",
  "action-representation#3",
  "action-representation#4"
 ],
 "introduces": [
  "action chunk"
 ],
 "purpose": "說明動作如何被編碼為離散 token 或連續向量，並引出 action chunk 的概念"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#1] (fact) RT-1 把 11 個動作維度各離散成 256 個 bin
[action-representation#3] (fact) 好處是可以直接沿用語言模型的 next-token 預測訓練 VLM
[action-representation#4] (fact) PaLM-E 和 OpenVLA 都用「覆寫最少用的 256 個 token」來放動作

這頁必須在 defines 解釋的術語：['action chunk']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'policy']

你上一版的這頁：
{
 "id": "s03",
 "kind": "content",
 "objective": "O2",
 "title": "離散 token 與連續動作的表徵方式",
 "bullets": [
  {
   "text": "RT-1 將 11 個動作維度各離散成 256 個 bin，形成離散 token",
   "cite": [
    "action-representation#1"
   ],
   "type": "fact"
  },
  {
   "text": "離散化的好處是可直接沿用語言模型的 next‑token 預測訓練方式",
   "cite": [
    "action-representation#3"
   ],
   "type": "fact"
  },
  {
   "text": "PaLM‑E 與 OpenVLA 皆採用「覆寫最少用的 256 個 token」來放置動作資訊",
   "cite": [
    "action-representation#4"
   ],
   "type": "fact"
  },
  {
   "text": "我們將連續動作切成固定長度的 token 序列",
   "cite": [
    "action-representation#1",
    "action-representation#3",
    "action-representation#4"
   ],
   "type": "inference"
  },
  {
   "text": "稱為 action chunk，便於與語言 token 對齊",
   "cite": [
    "action-representation#1",
    "action-representation#3",
    "action-representation#4"
   ],
   "type": "inference"
  }
 ],
 "defines": [
  {
   "term": "action chunk",
   "def": "將連續動作切分成固定長度的 token 序列，方便與語言模型交互"
  }
 ],
 "note": "示範機械手臂動作量化成 token，讓觀眾感受離散化與連續向量的差異"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s03",
  "type": "human_review",
  "msg": "第4、5點錯了，action chunk 不是把動作離散成 token，而是一次預測未來好幾步的動作，請刪掉這兩點，並把 action chunk 的名詞解釋改成「模型一次預測的一整段未來動作」"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"content","objective","title","bullets":[{"text","cite":["claim id"],"type":"fact|inference|analogy"}],"defines":[{"term","def"}],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。