你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：離散 token vs 連續動作的表徵方式
bullet 1 [fact] RT-1 將 11 個動作維度各離散成 256 個 bin，形成離散 token  (cite: action-representation#1)
bullet 2 [fact] Octo 使用 diffusion action head 直接輸出連續動作向量  (cite: action-representation#6)
bullet 3 [fact] π0 透過 flow matching 的 action expert 產生連續動作，不做離散化  (cite: action-representation#7)
bullet 4 [inference] 離散化讓模型可利用語言模型的 token 預訓練，而連續化則保留更細緻的控制資訊  (cite: action-representation#1, action-representation#6, action-representation#7)
名詞解釋 action chunk：將一段連續的機器人動作切分為固定長度的向量序列，供模型一次處理
名詞解釋 diffusion：一種生成模型技術，透過逐步去噪將隨機噪聲轉換為目標資料
名詞解釋 flow matching：利用學習的流場將簡單分布映射到目標動作分布的技術

證據（claim id → 原文）：
[action-representation#1] (fact) RT-1 把 11 個動作維度各離散成 256 個 bin
[action-representation#6] (fact) Octo 用 diffusion action head 輸出連續動作
[action-representation#7] (fact) π0 用 flow matching 的 action expert 輸出連續動作，不做離散化

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
- inference（推論）句也要查：推論不能和證據矛盾（例如證據說 A 比較慢，推論卻說 A 提升速度）
真正的比喻不用查證。
若這頁是 quiz：只有 answer 指到的那個選項必須正確且有證據支持；其他選項是「故意設計的錯誤選項」，本來就應該是錯的，
不要要求把它們改成正確。要檢查的是：正解有沒有證據支持、是不是剛好只有一個選項正確（如果有兩個以上都對，type 用 misleading）、
解說有沒有講清楚為什麼其他選項錯。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。