你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s07",
 "kind": "compare",
 "objective": "O4",
 "title": "Octo Diffusion vs π0 Flow Matching",
 "claims": [
  "continuous-action-heads#1",
  "continuous-action-heads#2",
  "action-representation#6"
 ],
 "introduces": [
  "diffusion",
  "flow matching"
 ],
 "purpose": "比較 Octo 使用 diffusion action head 與 π0 使用 flow matching 產生連續動作的差異"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#6] (fact) Octo 用 diffusion action head 輸出連續動作

=== [[continuous-action-heads]] ===
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作

這頁必須在 defines 解釋的術語：['diffusion', 'flow matching']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s07",
 "kind": "compare",
 "objective": "O4",
 "title": "Octo Diffusion vs π0 Flow Matching",
 "table": {
  "columns": [
   "Model",
   "Action Head",
   "Generation Process"
  ],
  "rows": [
   [
    "Octo",
    "Diffusion action head",
    "Readout token → diffusion head → 20 denoising steps產生連續動作 chunk"
   ],
   [
    "π0",
    "Conditional flow matching expert",
    "Action expert (300M) 使用 flow matching 直接產生連續動作"
   ]
  ],
  "cite": [
   "continuous-action-heads#1",
   "continuous-action-heads#2",
   "action-representation#6"
  ]
 },
 "bullets": [
  {
   "text": "Octo 透過 diffusion action head，經 20 個去噪步產出連續動作",
   "cite": [
    "continuous-action-heads#1"
   ],
   "type": "fact"
  },
  {
   "text": "π0 以 300M action expert，利用 conditional flow matching 直接產生連續動作",
   "cite": [
    "continuous-action-heads#2"
   ],
   "type": "fact"
  },
  {
   "text": "Diffusion 需要多步去噪，計算成本較高；flow matching 為一次性映射，較快",
   "cite": [
    "continuous-action-heads#1",
    "continuous-action-heads#2"
   ],
   "type": "inference"
  }
 ],
 "defines": [
  {
   "term": "diffusion",
   "def": "逐步去噪的生成方法，從噪聲逐漸恢復目標訊號"
  },
  {
   "term": "flow matching",
   "def": "一次性學習噪聲到目標的映射，只需一次前向傳播"
  }
 ],
 "note": "比較兩種連續動作產生方式時，可先問觀眾哪種方法在實務上較易部署"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s07",
  "type": "human_review",
  "msg": "刪掉「flow matching 是一次性映射、只需一次前向傳播、較快」，證據沒有這樣說，名詞解釋也一起改"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。