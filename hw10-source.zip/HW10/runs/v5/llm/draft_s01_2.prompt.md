你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s01",
 "kind": "title",
 "objective": null,
 "title": "VLA（Vision‑Language‑Action）模型概覽",
 "claims": [],
 "introduces": [
  "VLA",
  "VLM",
  "policy"
 ],
 "purpose": "說明本次簡報主題與核心概念"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：


這頁必須在 defines 解釋的術語：['VLA', 'VLM', 'policy']
之前投影片已解釋過、不必再解釋的術語：無

你上一版的這頁：
{
 "id": "s01",
 "kind": "title",
 "title": "VLA（Vision‑Language‑Action）模型概覽",
 "subtitle": "",
 "defines": [
  {
   "term": "VLA",
   "def": "結合視覺、語言與動作的模型，能同時理解影像、文字並產生行為指令"
  },
  {
   "term": "VLM",
   "def": "Vision‑Language Model，專注於從影像與文字中學習共同表示"
  },
  {
   "term": "policy",
   "def": "在強化學習中決定在特定觀測下執行哪個動作的函式"
  }
 ],
 "note": "說明本次簡報主題與核心概念，提醒觀眾這是首次接觸機器人相關的 VLA 架構",
 "objective": null
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s01",
  "type": "human_review",
  "msg": "policy 的名詞解釋不要寫「在強化學習中」，改成機器人看到當下狀態後決定動作的決策函式"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"title","title","subtitle","defines":[{"term","def"}],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。