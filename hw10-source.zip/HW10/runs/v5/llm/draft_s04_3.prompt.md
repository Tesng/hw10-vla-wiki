你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "claims": [
  "action-representation#8",
  "action-representation#9",
  "action-representation#10"
 ],
 "introduces": [
  "控制頻率"
 ],
 "purpose": "比較離散 token 與連續輸出在高頻控制上的優缺點"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#8] (fact) 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服
[action-representation#9] (fact) 樸素的 256 bin 在高頻時相鄰 token 高度相關，模型容易陷入「照抄」的局部解
[action-representation#10] (fact) FAST 先做 DCT 再用 BPE 壓縮，50 Hz 的 1 秒動作從 700 個 token 降到 53 個

這頁必須在 defines 解釋的術語：['控制頻率']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'policy']

你上一版的這頁：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "table": {
  "columns": [
   "表示方式",
   "控制頻率",
   "token 數量"
  ],
  "rows": [
   [
    "離散 token",
    "較低",
    "256 bin"
   ],
   [
    "連續輸出（DCT+BPE）",
    "50 Hz",
    "從 700 個 token 降到 53 個"
   ]
  ],
  "cite": [
   "action-representation#8",
   "action-representation#9",
   "action-representation#10"
  ]
 },
 "bullets": [
  {
   "text": "離散 token 最容易接上 VLM，但在高頻控制上受限",
   "cite": [
    "action-representation#8"
   ],
   "type": "fact"
  },
  {
   "text": "相鄰 token 高度相關會導致模型照抄局部解",
   "cite": [
    "action-representation#9"
   ],
   "type": "fact"
  },
  {
   "text": "FAST 先做 DCT 再用 BPE 壓縮，將 1 秒 700 個樣本降至 53 個 token",
   "cite": [
    "action-representation#10"
   ],
   "type": "fact"
  },
  {
   "text": "連續輸出更適合靈巧動作，如 π0 以 50 Hz 摺衣服",
   "cite": [
    "action-representation#8"
   ],
   "type": "inference"
  }
 ],
 "defines": [
  {
   "term": "控制頻率",
   "def": "機器人每秒執行控制指令的次數，頻率越高可實現更細緻的動作"
  }
 ],
 "note": "提醒觀眾：離散化易於與視覺語言模型結合，但若要高頻、靈巧的動作，連續化與壓縮技術更具優勢。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s04",
  "type": "ai_review_table_mismatch",
  "msg": "table row: 離散 token：欄位標題為「token 數量」，但儲存格內容填的是「256 bin」（分箱數量/詞彙表大小），兩者概念不同。證據 #9 提到 256 bin 是離散化的方式，而非最終輸出的 token 數量。；建議：將「256 bin」改為具體的 token 數量（如證據 #10 中提到的 700 個，若適用），或將欄位標題改為「表示參數/詞彙表大小」以匹配內容。"
 },
 {
  "slide": "s04",
  "type": "ai_review_table_mismatch",
  "msg": "table row: 連續輸出（DCT+BPE）：欄位標題為「token 數量」，儲存格內容為「從 700 個 token 降到 53 個」。雖然數字正確，但「從...降到...」是過程描述，不是最終的 token 數量值。此外，該行標題「連續輸出」與內容「DCT+BPE」矛盾，因為 DCT+BPE 是將連續動作離散化為 token 的方法（FAST 方法），並非純粹的連續輸出。證據 #10 明確指出 FAST 是「先做 DCT 再用 BPE 壓縮」，BPE 產生的是離散 token。；建議：將行標題改為「FAST (DCT+BPE)」或「離散化 (FAST)」，並將 token 數量欄改為「53」或「53 個 token」。"
 },
 {
  "slide": "s04",
  "type": "ai_review_misleading",
  "msg": "bullet 4：標記為 [inference]，但內容「連續輸出更適合靈巧動作，如 π0 以 50 Hz 摺衣服」直接來自證據 #8 的 [fact] 陳述。證據 #8 說「連續輸出更適合高頻、靈巧的動作，例如 π0...」。將其標記為推論可能讓讀者誤以為這是作者的額外推斷，而非原文事實。更嚴重的是，表格中將 DCT+BPE（一種離散化方法）歸類為「連續輸出」，與 bullet 4 的邏輯（連續輸出 vs 離散 token）產生混淆。如果 bullet 4 指的是真正的連續輸出（如 diffusion policy），那麼引用 π0 (通常使用 flow matching/diffusion，屬於連續) 是合理的。但表格將 FAST (離散) 標為連續輸出，導致整頁邏輯混亂。；建議：確認 π0 是否使用連續輸出。若 π0 使用連續輸出，則 bullet 4 應標記為 [fact] 並引用 #8。表格中應區分「連續輸出 (如 π0)」和「離散化方法 (如 FAST)」。目前表格將 FAST 歸類為連續輸出是錯誤的歸類 (wrong_attribution/table_mismatch)。"
 },
 {
  "slide": "s04",
  "type": "ai_review_wrong_attribution",
  "msg": "table row: 連續輸出（DCT+BPE）：DCT+BPE (FAST) 是一種將連續動作序列轉換為離散 token 的方法，其輸出是離散 token，而非「連續輸出」。證據 #10 描述 FAST 產生 53 個 token。將 FAST 歸類為「連續輸出」與證據矛盾，也與 bullet 1 中「離散 token」的對比邏輯衝突。；建議：將該行標題改為「FAST (離散化)」或「DCT+BPE (離散 token)」，以正確反映其離散本質。"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。