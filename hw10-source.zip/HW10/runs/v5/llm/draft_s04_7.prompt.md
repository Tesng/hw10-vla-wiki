你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "claims": [
  "action-representation#8",
  "action-representation#9",
  "action-representation#10"
 ],
 "introduces": [
  "控制頻率"
 ],
 "purpose": "比較離散 token 與連續輸出在高頻控制上的優缺點"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#8] (fact) 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服
[action-representation#9] (fact) 樸素的 256 bin 在高頻時相鄰 token 高度相關，模型容易陷入「照抄」的局部解
[action-representation#10] (fact) FAST 先做 DCT 再用 BPE 壓縮，50 Hz 的 1 秒動作從 700 個 token 降到 53 個

這頁必須在 defines 解釋的術語：['控制頻率']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'policy']

你上一版的這頁：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "table": {
  "columns": [
   "表示方式",
   "控制頻率",
   "壓縮後 token 數"
  ],
  "rows": [
   [
    "離散 token (FAST)",
    "—",
    "53"
   ],
   [
    "連續輸出 (π0)",
    "50 Hz",
    "N/A"
   ]
  ],
  "cite": [
   "action-representation#8",
   "action-representation#9",
   "action-representation#10"
  ]
 },
 "bullets": [
  {
   "text": "離散 token 最容易接上 VLM，但在高頻控制上受限",
   "cite": [
    "action-representation#8"
   ],
   "type": "fact"
  },
  {
   "text": "相鄰離散 token 高度相關，模型易陷入照抄局部解",
   "cite": [
    "action-representation#9"
   ],
   "type": "fact"
  },
  {
   "text": "FAST 先做 DCT 再用 BPE 壓縮，將 50 Hz 的 1 秒動作從 700 個 token 降至 53 個 token",
   "cite": [
    "action-representation#10"
   ],
   "type": "fact"
  },
  {
   "text": "連續輸出更適合靈巧動作，如 π0 以 50 Hz 摺衣服",
   "cite": [
    "action-representation#8"
   ],
   "type": "fact"
  }
 ],
 "defines": [
  {
   "term": "控制頻率",
   "def": "機器人每秒執行控制指令的次數，頻率越高可實現更細緻的動作"
  }
 ],
 "note": "提醒觀眾：離散化易於與視覺語言模型結合，但若要高頻、靈巧的動作，連續化與壓縮技術更具優勢。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s04",
  "type": "too_long",
  "msg": "bullet 3 有 64 字，上限 60：請至少刪掉 9 個字，或拆成兩個 bullet"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。