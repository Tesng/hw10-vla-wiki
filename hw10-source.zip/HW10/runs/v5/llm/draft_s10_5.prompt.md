你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s10",
 "kind": "quiz",
 "objective": null,
 "title": "小測驗：檢測概念掌握",
 "claims": [
  "vla#1",
  "action-chunking#1",
  "co-fine-tuning#1"
 ],
 "introduces": [],
 "purpose": "透過單選題確認觀眾對 VLA 定義、action chunk 與資料來源的理解"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-chunking]] ===
[action-chunking#1] (fact) 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步

=== [[co-fine-tuning]] ===
[co-fine-tuning#1] (fact) 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）

=== [[vla]] ===
[vla#1] (fact) VLA 是把 vision-language model（VLM）微調成直接輸出機器人動作的模型

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'diffusion', 'embodiment', 'flow matching', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s10",
 "kind": "quiz",
 "objective": null,
 "title": "小測驗：檢測概念掌握",
 "quiz": {
  "q": "以下哪項正確描述 VLA 模型的特性？",
  "options": [
   "VLA 是把 vision-language model 微調成直接輸出機器人動作的模型。",
   "VLA 只在訓練時使用機器人軌跡資料，不結合網路規模的 vision-language 資料。",
   "action chunk 指模型一次輸出單一步驟的動作。",
   "co-fine-tuning 只微調 VLM，並不加入機器人軌跡資料。"
  ],
  "answer": 0,
  "explain": "選項 A 正確，根據 [vla#1]，VLA 把 VLM 微調成直接輸出機器人動作。選項 B、D 錯誤，因為 [co-fine-tuning#1] 說明微調時同時加入機器人軌跡與大規模 vision‑language 資料。選項 C 錯誤，根據 [action-chunking#1]，action chunk 是一次輸出多步動作，而非單一步。",
  "cite": [
   "vla#1",
   "action-chunking#1",
   "co-fine-tuning#1"
  ]
 },
 "note": "提醒觀眾注意關鍵詞的正確定義，尤其 action chunk 與 co-fine-tuning 的資料來源差異。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s10",
  "type": "schema",
  "msg": "quiz.explain 裡寫了 claim id；claim id 只能放在 quiz.cite，解說文字不要出現"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"quiz","objective","title","quiz":{"q","options":["A","B","C","D"],"answer":索引,"explain","cite":["claim id"]},"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。