你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：小測驗：檢測概念掌握
quiz：以下哪項正確描述 VLA 模型的特性？ 選項：['VLA 是把 vision-language model 微調成直接輸出機器人動作的模型。', 'VLA 只在訓練時使用機器人軌跡資料，不結合網路規模的 vision-language 資料。', 'action chunk 指模型一次輸出單一步驟的動作。', 'co-fine-tuning 只微調 VLM，並不加入機器人軌跡資料。'] 正解：0 解說：選項 A 正確，因為 VLA 把 VLM 微調成直接輸出機器人動作。選項 B、D 錯誤，微調時同時加入機器人軌跡與大規模 vision‑language 資料。選項 C 錯誤，action chunk 是一次輸出多步動作。 (cite: vla#1, action-chunking#1, co-fine-tuning#1)

證據（claim id → 原文）：
[action-chunking#1] (fact) 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步
[co-fine-tuning#1] (fact) 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）
[vla#1] (fact) VLA 是把 vision-language model（VLM）微調成直接輸出機器人動作的模型

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
- inference（推論）句也要查：推論不能和證據矛盾（例如證據說 A 比較慢，推論卻說 A 提升速度）
真正的比喻不用查證。
若這頁是 quiz：只有 answer 指到的那個選項必須正確且有證據支持；其他選項是「故意設計的錯誤選項」，本來就應該是錯的，
不要要求把它們改成正確。要檢查的是：正解有沒有證據支持、是不是剛好只有一個選項正確（如果有兩個以上都對，type 用 misleading）、
解說有沒有講清楚為什麼其他選項錯。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。