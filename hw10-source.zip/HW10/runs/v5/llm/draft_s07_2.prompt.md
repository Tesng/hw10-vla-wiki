你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s07",
 "kind": "compare",
 "objective": "O4",
 "title": "Chunking 與 Diffusion / Flow Matching 的比較",
 "claims": [
  "continuous-action-heads#1",
  "continuous-action-heads#2",
  "action-chunking#4"
 ],
 "introduces": [
  "diffusion",
  "flow matching"
 ],
 "purpose": "比較 chunk‑based 預測與 diffusion / flow matching 兩種連續動作生成方式"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-chunking]] ===
[action-chunking#4] (inference) 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)

=== [[continuous-action-heads]] ===
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作

這頁必須在 defines 解釋的術語：['diffusion', 'flow matching']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s07",
 "kind": "compare",
 "objective": "O4",
 "title": "Chunking 與 Diffusion / Flow Matching 的比較",
 "table": {
  "columns": [
   "方法",
   "產生方式",
   "步數/資源"
  ],
  "rows": [
   [
    "Chunking",
    "一次推論多步，分離思考頻率與控制頻率",
    "依據 action‑chunking#4，無固定步數"
   ],
   [
    "Diffusion (Octo)",
    "Transformer readout token 接 diffusion action head，逐步去噪",
    "20 個去噪步，見 continuous-action-heads#1"
   ],
   [
    "Flow Matching (π0)",
    "在 PaliGemma 旁掛 300M action expert，使用 conditional flow matching",
    "使用 300M 權重，見 continuous-action-heads#2"
   ]
  ],
  "cite": [
   "action-chunking#4",
   "continuous-action-heads#1",
   "continuous-action-heads#2"
  ]
 },
 "bullets": [
  {
   "text": "Chunking 讓大模型一次產生多個連續動作，降低推論頻率",
   "cite": [
    "action-chunking#4"
   ],
   "type": "inference"
  },
  {
   "text": "Octo 以 diffusion head 產生動作 chunk，需要 20 步去噪",
   "cite": [
    "continuous-action-heads#1"
   ],
   "type": "fact"
  },
  {
   "text": "π0 透過 300M 的 action expert，使用 conditional flow matching 直接產生連續動作",
   "cite": [
    "continuous-action-heads#2"
   ],
   "type": "fact"
  },
  {
   "text": "Diffusion 逐步修正噪聲，適合高維連續空間的細緻控制",
   "type": "analogy"
  },
  {
   "text": "Flow matching 直接學習從噪聲到目標分布的流，計算上更高效",
   "type": "analogy"
  }
 ],
 "defines": [
  {
   "term": "diffusion",
   "def": "一種逐步去噪的生成過程，模型在多個時間步中逐漸將隨機噪聲轉換為目標動作序列。"
  },
  {
   "term": "flow matching",
   "def": "透過學習一個向量場，使噪聲直接流向目標分布，省去多步去噪的迭代。"
  }
 ],
 "note": "說明 chunk‑based 預測如何減少推論次數，並比較 diffusion 與 flow matching 在步數與資源需求上的差異。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s07",
  "type": "too_long",
  "msg": "bullet 3 有 64 字，上限 60：請至少刪掉 9 個字，或拆成兩個 bullet"
 },
 {
  "slide": "s07",
  "type": "disguised_claim",
  "msg": "bullet 4 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉"
 },
 {
  "slide": "s07",
  "type": "disguised_claim",
  "msg": "bullet 5 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉"
 },
 {
  "slide": "s07",
  "type": "inference_as_fact",
  "msg": "table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference"
 },
 {
  "slide": "s07",
  "type": "inference_as_fact",
  "msg": "table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference"
 },
 {
  "slide": "s07",
  "type": "inference_as_fact",
  "msg": "table row 引用 (推論) claim 卻標成 fact：請把 type 改成 inference"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. quiz：正好一個正確選項；其他 3 個選項要能依據證據「明確判定為錯」（例如把事實反過來），解說要說明正解為何對、錯誤選項錯在哪。
6. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。