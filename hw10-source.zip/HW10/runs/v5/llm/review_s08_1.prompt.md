你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：從 RT‑1 到 π0 的演進路線
bullet 1 [fact] RT‑1 用小型 Transformer 直接將離散動作編碼為 token，展示了基本 VLA 框架  (cite: vla-timeline#1)
bullet 2 [fact] RT‑2 進一步將視覺語言模型擴展為 VLA，透過文字 token 表示動作並共同微調  (cite: vla-timeline#2)
bullet 3 [fact] OpenVLA 以 7B 參數開源，對抗更大模型 RT‑2‑X，取得 16.5% 的相對優勢  (cite: vla-timeline#5)
bullet 4 [fact] π0 採用 flow matching 技術，實現 50 Hz 的高頻控制，成功摺衣服  (cite: vla-timeline#6)
timeline 2022 RT‑1：35M Transformer，130k 示範，動作離散成 token  (cite: vla-timeline#1)
timeline 2023 RT‑2：把 VLM 變成 VLA，動作寫成文字 token，co‑fine‑tune  (cite: vla-timeline#2)
timeline 2024 OpenVLA：7B 開源 VLA，贏 55B RT‑2‑X 16.5%  (cite: vla-timeline#5)
timeline 2024 π0：3.3B，flow matching，50 Hz 摺衣服  (cite: vla-timeline#6)

證據（claim id → 原文）：
[vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |
[vla-timeline#2] (fact) 2023 | [[rt2]] | 把 VLM 變成 VLA，動作寫成文字 token，co-fine-tune  |
[vla-timeline#5] (fact) 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5%  |
[vla-timeline#6] (fact) 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服  |

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
- inference（推論）句也要查：推論不能和證據矛盾（例如證據說 A 比較慢，推論卻說 A 提升速度）
真正的比喻不用查證。
若這頁是 quiz：只有 answer 指到的那個選項必須正確且有證據支持；其他選項是「故意設計的錯誤選項」，本來就應該是錯的，
不要要求把它們改成正確。要檢查的是：正解有沒有證據支持、是不是剛好只有一個選項正確（如果有兩個以上都對，type 用 misleading）、
解說有沒有講清楚為什麼其他選項錯。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。