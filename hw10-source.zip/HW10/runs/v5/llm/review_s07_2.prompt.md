你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：Chunking 與 Diffusion / Flow Matching 的比較
bullet 1 [inference] Chunking 讓大模型在推論時一次產生多步，以分離思考頻率與控制頻率  (cite: action-chunking#4)
bullet 2 [fact] Octo 以 diffusion head 透過 20 步去噪，逐步生成連續動作 chunk  (cite: continuous-action-heads#1)
bullet 3 [fact] π0 使用 conditional flow matching 產生連續動作序列  (cite: continuous-action-heads#2)
表格欄位：Method | Generation Steps | Key Mechanism  (cite: action-chunking#4, continuous-action-heads#1, continuous-action-heads#2)
table row: Chunking | 一次多步 | 在推論時一次產生多個連續動作 chunk
table row: Diffusion (Octo) | 20 個去噪步 | Transformer readout token 接 diffusion action head，逐步去噪產生連續動作
table row: Flow Matching (π0) | 較少步數 | 使用 300M action expert 與 conditional flow matching 產生連續動作
名詞解釋 diffusion：透過多步去噪，將隨機噪聲逐漸轉換為連續動作序列的生成方法
名詞解釋 flow matching：學習噪聲到目標分布的流向，使模型能以較少步數產生連續動作

證據（claim id → 原文）：
[action-chunking#4] (inference) 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
- inference（推論）句也要查：推論不能和證據矛盾（例如證據說 A 比較慢，推論卻說 A 提升速度）
真正的比喻不用查證。
若這頁是 quiz：只有 answer 指到的那個選項必須正確且有證據支持；其他選項是「故意設計的錯誤選項」，本來就應該是錯的，
不要要求把它們改成正確。要檢查的是：正解有沒有證據支持、是不是剛好只有一個選項正確（如果有兩個以上都對，type 用 misleading）、
解說有沒有講清楚為什麼其他選項錯。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。