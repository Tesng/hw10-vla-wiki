# 證據卡：Wiki 中的推論（無論文出處）

- [action-chunking#4] (inference) 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)
- [action-representation#12] (inference) 可能原因：差別不在「離散或連續」本身，而在 token 化方式是否壓掉高頻冗餘；兩者在訓練速度與推論速度上各有取捨 (推論)
- [co-fine-tuning#4] (inference) 直覺：只餵機器人資料，VLM 會忘掉網路上學到的常識；混著訓練能保留下來 (推論)
- [continuous-action-heads#3] (inference) 共同直覺：從雜訊出發，一步步「修正」成合理的動作軌跡，能表示多峰（同一情境有多種合理做法）的動作分佈 (推論)
- [cross-embodiment#1] (inference) embodiment 指機器人的「身體」：手臂型號、感測器、動作空間 (推論)
- [oxe#5] (inference) 這是 [[cross-embodiment]] 的代表性資料集，後來 [[octo]]、[[openvla]] 都從中挑資料預訓練 (推論)
- [vla-timeline#8] (inference) 趨勢一：從封閉大模型走向開源可微調 (推論)
- [vla-timeline#9] (inference) 趨勢二：動作從離散 token 走向連續 chunk，但 FAST 讓離散路線重新有競爭力 (推論)
