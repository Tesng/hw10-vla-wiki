# 大綱（第 4 版）

| id | kind | 目標 | 標題 | claims | 介紹術語 |
|---|---|---|---|---|---|
| s01 | title |  | VLA（Vision‑Language‑Action）模型概覽 | 0 | VLA, VLM, policy |
| s02 | content | O1 | VLA 定義與 LLM / VLM 的關係 | 3 |  |
| s03 | content | O2 | 離散 token 與連續動作的表徵方式 | 3 | action chunk |
| s04 | compare | O2 | 離散 vs 連續：效能與頻率比較 | 3 | 控制頻率 |
| s05 | content | O3 | 資料來源：跨機體資料與 co‑fine‑tuning | 3 | co-fine-tuning, embodiment, 正遷移 |
| s06 | content | O4 | Action Chunking：提升控制頻率的關鍵 | 3 | action chunk |
| s07 | compare | O4 | Octo Diffusion vs π0 Flow Matching | 3 | diffusion, flow matching |
| s08 | timeline | O5 | 從 RT‑1 到 π0 的演進路線 | 4 |  |
| s09 | compare | O5 | RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異 | 4 |  |
| s10 | quiz |  | 小測驗：檢測概念掌握 | 3 |  |
| s11 | summary |  | 總結與未來展望 | 2 |  |
| s12 | flow |  | 未來挑戰與研究方向 | 3 | diffusion, flow matching |
