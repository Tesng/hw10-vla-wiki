# 大綱（第 2 版）

| id | kind | 目標 | 標題 | claims | 介紹術語 |
|---|---|---|---|---|---|
| s01 | title |  | Vision‑Language‑Action (VLA) 模型概覽 | 0 | VLA, VLM, policy |
| s02 | content | O1 | VLA 定義與與 LLM / VLM 的關係 | 3 | VLA, VLM, policy |
| s03 | content | O2 | 離散 token vs 連續動作的表示方式 | 3 | action chunk |
| s04 | content | O2 | 離散 token 的實作細節與挑戰 | 3 | action chunk, 控制頻率 |
| s05 | content | O3 | 資料來源：跨機體資料與 co‑fine‑tuning | 3 | co-fine-tuning, embodiment, 正遷移 |
| s06 | content | O4 | Action Chunking：提升控制頻率的關鍵 | 3 | action chunk, 控制頻率 |
| s07 | compare | O5 | RT‑1 → RT‑2 → OpenVLA → π0：模型演進比較 | 3 | diffusion, flow matching |
| s08 | compare | O5 | 離散 vs 連續 Action Head：Octo、π0、FAST 的對照 | 3 | diffusion, flow matching |
| s09 | timeline |  | VLA 研究時間線 2022‑2025 | 3 |  |
| s10 | quiz |  | 小測驗：檢視概念掌握度 | 3 |  |
| s11 | summary |  | 結論與未來方向 | 3 |  |
