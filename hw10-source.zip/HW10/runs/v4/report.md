# 檢查報告 — run `v4`

- 狀態：**done_with_issues: ['s10']**
- LLM：groq；模型：{'writer': 'openai/gpt-oss-120b', 'reviewer': 'qwen/qwen3.8-27b'}
- LLM 呼叫 68 次，prompt tokens 57349，completion tokens 18109，429 等待 3 次
- 渲染檢查方式：heuristic（未使用 Playwright：ModuleNotFoundError）

## 節點執行次數（graph 上每個圈轉了幾次）

| 節點 | 次數 |
|---|---|
| load_wiki | 1 |
| lint_wiki | 1 |
| query_wiki | 1 |
| evidence_cards | 1 |
| outline | 2 |
| check_outline | 2 |
| human_gate | 1 |
| draft_pages | 3 |
| ai_review | 3 |
| check_deck | 1 |
| render_html | 2 |
| check_render | 1 |

## 各關卡檢查結果

| 關卡 | 結果 |
|---|---|
| outline | {"n": 1, "by_type": {"term_order": 1}} |
| outline | {"n": 0, "by_type": {}} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "heuristic（未使用 Playwright：ModuleNotFoundError）", "overflow": {"s07": 24}, "sections": 12, "external": []} |

## 人工確認

- 大綱第 2 版：approve

## 逐頁紀錄（小圈）

| 頁 | 逐頁稿呼叫 | AI 審查呼叫 | 審查退回 | 渲染退回 | 整份檢查退回 |
|---|---|---|---|---|---|
| s01 Vision‑Language‑Action (VLA) 模型概覽 | 1 | 0 | 0 | 0 | 0 |
| s02 VLA 定義與與 LLM / VLM 的關係 | 1 | 1 | 0 | 0 | 0 |
| s03 離散 token vs 連續動作的表示方式 | 4 | 2 | 1 | 0 | 0 |
| s04 離散 token 的實作細節與挑戰 | 2 | 1 | 0 | 0 | 0 |
| s05 資料來源：跨機體資料與 co‑fine‑tuning | 2 | 1 | 0 | 0 | 0 |
| s06 Action Chunking：提升控制頻率的關鍵 | 1 | 1 | 0 | 0 | 0 |
| s07 RT‑1 → RT‑2 → OpenVLA → π0：模型演進比較 | 2 | 2 | 1 | 0 | 0 |
| s08 離散 vs 連續 Action Head：Octo、π0、FAST 的對照 | 5 | 2 | 1 | 0 | 0 |
| s09 VLA 研究時間線 2022‑2025 | 1 | 1 | 0 | 0 | 0 |
| s10 小測驗：檢視概念掌握度 | 5 | 3 | 2 | 0 | 0 |
| s11 結論與未來方向 | 1 | 1 | 0 | 0 | 0 |

## 錯誤類型統計（哪個節點最常出錯）

| 節點 | 錯誤類型 | 次數 |
|---|---|---|
| ai_review | unsupported | 5 |
| draft_pages | undefined_term | 4 |
| draft_pages | disguised_claim | 4 |
| draft_pages | too_long | 3 |
| ai_review | reversed | 3 |
| ai_review | table_mismatch | 2 |
| ai_review | misleading | 2 |
| draft_pages | uncited | 1 |
| draft_pages | repeated_error | 1 |
| draft_pages | schema | 1 |
| ai_review | wrong_attribution | 1 |
| ai_review | disguised_claim | 1 |
| draft_pages | inference_as_fact | 1 |

## 覆蓋率

- 用到的 claim：30
- 用到的論文：['fast', 'octo', 'openvla', 'oxe', 'pi0', 'rt1', 'rt2']
- 沒用到的論文：無

## Wiki 中的矛盾（⚠）

- action-representation: - ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 [[src:pi0]]；FAST 則顯示離散 token 的 π0-FA

## 警告

- render: 估算可能溢出：{'s07': 24}（未安裝 Playwright，只警告不退件）

## 未解決（已達上限，需人工處理）

- s10: [{'type': 'ai_review', 'msg': '[{"where": "quiz option 0", "type": "unsupported", "problem": "選項 0 將「離散 token 接 VLM」與「連續輸出適合高頻動作」結合為一個正確敘述，但題目問的是「哪項敘述正確描述...概念」，通常單選題只有一個正解。然而，選項 3 (co-fine-tuning) 也是完全正確的敘述（對應證據 co-fine-tuning#4）。若這是單選題，存在兩個正確選項（0 和 3），導致題目邏輯錯誤。若這是多選題，則標註「正解：0」是錯誤的，因為 3 也是正確的。根據證據，選項 0 和 3 都忠於證據。因此，將 3 排除在正解之外，或暗示 0 是唯一正解，屬於題目設計錯誤或標註錯誤。", "fix": "若為單選題，需修改選項 3 使其錯誤，或修改選項 0 使其錯誤；若為多選題，正解應包含 0 和 3。"}, {"where": "quiz explanation", "type": "misleading", "problem": "解說僅解釋了選項 0 的正確性，但未說明為何其他選項（特別是選項 3）不正確。然而，選項 3 的內容「co-fine-tuning 在訓練階段混合機器人與網路資料，以保留常識」與證據 [co-fine-tuning#4] 完全一致。因此，解說未指出選項 3 也是正確的，會讓學生誤以為選項 3 是錯誤的，造成誤導。", "fix": "在解說中明確指出選項 3 也是正確的敘述，或調整題目為多選並更新正解。"}]'}]

## 事件時間線

- 11:55:00 `draft_pages` s01 第1次 ✔
- 11:55:08 `draft_pages` s02 第1次 ✔
- 11:55:19 `draft_pages` s03 第1次 ✘ undefined_term: 術語「diffusion」在這頁第一次出現，必須放進 defines；undefined_term: 術語「flow matching」在這頁第一次出現，必須放進 defines
- 11:55:35 `draft_pages` s03 第2次 ✔
- 11:55:45 `draft_pages` s04 第1次 ✘ too_long: bullet 3 有 67 字，上限 60：請至少刪掉 12 個字，或拆成兩個 bullet
- 11:55:59 `draft_pages` s04 第2次 ✔
- 11:56:13 `draft_pages` s05 第1次 ✘ too_long: bullet 3 有 61 字，上限 60：請至少刪掉 6 個字，或拆成兩個 bullet
- 11:56:39 `draft_pages` s05 第2次 ✔
- 11:56:51 `draft_pages` s06 第1次 ✔
- 11:56:55 `draft_pages` s07 第1次 ✔
- 11:57:16 `draft_pages` s08 第1次 ✘ too_long: bullet 2 有 62 字，上限 60：請至少刪掉 7 個字，或拆成兩個 bullet；disguised_claim: bullet 5 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉；uncited: bullet 4 沒有引用 claim
- 11:57:37 `draft_pages` s08 第2次 ✘ disguised_claim: bullet 5 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉
- 11:57:55 `draft_pages` s08 第3次 ✘ disguised_claim: bullet 5 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉
- 11:57:55 `draft_pages` s08 第3次 ✘ repeated_error: 同樣的錯誤連續兩次，停止重寫並交給人工
- 11:58:01 `draft_pages` s09 第1次 ✔
- 11:58:12 `draft_pages` s10 第1次 ✘ schema: quiz.explain 裡寫了 claim id；claim id 只能放在 quiz.cite，解說文字不要出現
- 11:58:30 `draft_pages` s10 第2次 ✔
- 11:58:35 `draft_pages` s11 第1次 ✔
- 11:58:35 `ai_review` s02 第1次 ✔
- 11:58:36 `ai_review` s03 第1次 ✘ unsupported: bullet 4 — 證據 [action-representation#6] 僅說明 Octo 使用 diffusion action head 輸出連續動作，並未提及「避免高頻任務中 token 重複的問題」或「提升模型對細微變化的感知」。這些是推論或額外細節，證據中沒有支持。
- 11:58:36 `ai_review` s04 第1次 ✔
- 11:58:36 `ai_review` s05 第1次 ✔
- 11:58:37 `ai_review` s06 第1次 ✔
- 11:58:39 `ai_review` s07 第1次 ✘ wrong_attribution: bullet 1 — 證據 [rt2#1] 指出 RT-2 提出了 VLA 模型（微調 VLM 輸出動作），但投影片稱 RT-2「首次提出 VLA 概念」。證據中並未提及 RT-1 或其他模型是否提出過類似概念，也未明確說明 RT-2 是「首次」提出該概念，這屬於證據未支持的細節（unsupported）或歸因錯誤。通常 VLA 概念在 RT-1 中已有雛形，RT-2 是將其擴展到通用 VLM。；table_mismatch: table row: OpenVLA — 欄位標題為 'Params'，但儲存格內容為 'Params 7× less than 
- 12:00:16 `ai_review` s08 第1次 ✘ unsupported: bullet 4 — 證據 [fast#5] 僅提到「訓練時間最多少 5 倍」，並未提及「效能接近 diffusion 版 π0」的具體比較結論（雖然 bullet 3 提到了追平，但 bullet 4 將其歸類為 inference 且引用同一來源，暗示該來源直接支持了效能結論，而原文僅支持訓練時間的節省。更嚴謹地說，證據支持訓練時間，但「效能接近」是基於 bullet 3 的事實推導，若 bullet 4 標記為 inference 且引用 fast#5，則該引用不支持「效能接近」這一半的陳述，或者說該陳述混合了事實與推論但引用不足。不過，最明顯的問題在於 bul
- 12:00:16 `ai_review` s09 第1次 ✔
- 12:02:00 `ai_review` s10 第1次 ✘ unsupported: quiz option 0 — 選項 0 被標記為正解，但其內容「離散 token 最適合接上 VLM」與證據 [action-representation#8] 相符，然而選項 1「Action chunk 讓模型一次推論多步，分離思考頻率與控制頻率」也完全符合證據 [action-chunking#4]。這是一道單選題（「以下哪項敘述正確」），但存在兩個正確選項，導致題目邏輯錯誤或答案不唯一。；misleading: quiz explanation — 解說中同時解釋了選項 0 和選項 1 的正確性，這與單選題的設定矛盾，會讓學生困惑。
- 12:03:00 `ai_review` s11 第1次 ✔
- 12:03:01 `draft_pages` s03 第3次 ✘ undefined_term: 術語「diffusion」在這頁第一次出現，必須放進 defines；undefined_term: 術語「flow matching」在這頁第一次出現，必須放進 defines
- 12:03:03 `draft_pages` s03 第4次 ✔
- 12:03:07 `draft_pages` s07 第2次 ✔
- 12:03:39 `draft_pages` s08 第4次 ✘ disguised_claim: bullet 5 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉
- 12:03:55 `draft_pages` s08 第5次 ✔
- 12:04:07 `draft_pages` s10 第3次 ✘ inference_as_fact: quiz 解說用到 (inference) claim：請在解說文字中寫明「（推論）」，或改引用 fact claim
- 12:04:15 `draft_pages` s10 第4次 ✔
- 12:04:16 `ai_review` s03 第2次 ✔
- 12:04:17 `ai_review` s07 第2次 ✔
- 12:04:17 `ai_review` s08 第2次 ✔
- 12:04:18 `ai_review` s10 第2次 ✘ reversed: quiz option 1 — 選項 1 稱 'Action chunk 只會在訓練時一次產生多步，與推論頻率無關'。證據 [action-chunking#4] 明確指出 action chunking 的目的是在推論時一次多算幾步，以分開思考頻率與控制頻率，因此它與推論頻率密切相關，且主要應用於推論階段。；reversed: quiz option 2 — 選項 2 稱 '只使用機器人資料訓練即可保留網路上學到的常識'。證據 [co-fine-tuning#4] 指出 '只餵機器人資料，VLM 會忘掉網路上學到的常識'，必須混著訓練才能保留。；reversed: qui
- 12:04:39 `draft_pages` s10 第5次 ✔
- 12:04:40 `ai_review` s10 第3次 ✘ unsupported: quiz option 0 — 選項 0 將「離散 token 接 VLM」與「連續輸出適合高頻動作」結合為一個正確敘述，但題目問的是「哪項敘述正確描述...概念」，通常單選題只有一個正解。然而，選項 3 (co-fine-tuning) 也是完全正確的敘述（對應證據 co-fine-tuning#4）。若這是單選題，存在兩個正確選項（0 和 3），導致題目邏輯錯誤。若這是多選題，則標註「正解：0」是錯誤的，因為 3 也是正確的。根據證據，選項 0 和 3 都忠於證據。因此，將 3 排除在正解之外，或暗示 0 是唯一正解，屬於題目設計錯誤或標註錯誤。；misleadi
