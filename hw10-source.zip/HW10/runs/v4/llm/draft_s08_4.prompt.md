你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s08",
 "kind": "compare",
 "objective": "O5",
 "title": "離散 vs 連續 Action Head：Octo、π0、FAST 的對照",
 "claims": [
  "continuous-action-heads#1",
  "continuous-action-heads#2",
  "fast#5"
 ],
 "introduces": [
  "diffusion",
  "flow matching"
 ],
 "purpose": "比較 diffusion、flow matching 與離散 token（FAST）三種 action head 的優缺點與實驗結果"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[continuous-action-heads]] ===
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作

=== [[fast]] ===
[fast#5] (fact) π0-FAST（自回歸、離散 token）在摺衣服等任務上追平用 diffusion 的 π0，訓練時間最多少 5 倍

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'diffusion', 'embodiment', 'flow matching', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s08",
 "kind": "compare",
 "objective": "O5",
 "title": "離散 vs 連續 Action Head：Octo、π0、FAST 的對照",
 "table": {
  "columns": [
   "Method",
   "Action Head Type",
   "Generation Process",
   "Training Cost"
  ],
  "rows": [
   [
    "Octo",
    "continuous (diffusion)",
    "Transformer readout token → diffusion head, 20 denoising steps",
    ""
   ],
   [
    "π0",
    "continuous (flow matching)",
    "PaliGemma + 300M action expert, conditional flow matching",
    ""
   ],
   [
    "π0‑FAST",
    "discrete (token)",
    "自回歸離散 token 生成",
    "訓練時間最少 5 倍"
   ]
  ],
  "cite": [
   "continuous-action-heads#1",
   "continuous-action-heads#2",
   "fast#5"
  ]
 },
 "bullets": [
  {
   "text": "Octo 透過 diffusion head 以 20 步去噪產生連續動作 chunk",
   "cite": [
    "continuous-action-heads#1"
   ],
   "type": "fact"
  },
  {
   "text": "π0 用 300M action expert 搭配 conditional flow matching 產生連續動作",
   "cite": [
    "continuous-action-heads#2"
   ],
   "type": "fact"
  },
  {
   "text": "π0‑FAST 以自回歸離散 token 方式，在摺衣服等任務上追平 diffusion 版的 π0",
   "cite": [
    "fast#5"
   ],
   "type": "fact"
  },
  {
   "text": "離散 token（FAST）在訓練上更省時，效能接近 diffusion 版 π0",
   "cite": [
    "fast#5"
   ],
   "type": "inference"
  },
  {
   "text": "選擇 head 取決於資源與即時性需求的平衡",
   "type": "analogy"
  }
 ],
 "defines": [],
 "note": "提醒觀眾：雖然生成方式不同，最終都是在同一 action chunk 空間內做預測。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s08",
  "type": "ai_review_unsupported",
  "msg": "bullet 4：證據 [fast#5] 僅提到「訓練時間最多少 5 倍」，並未提及「效能接近 diffusion 版 π0」的具體比較結論（雖然 bullet 3 提到了追平，但 bullet 4 將其歸類為 inference 且引用同一來源，暗示該來源直接支持了效能結論，而原文僅支持訓練時間的節省。更嚴謹地說，證據支持訓練時間，但「效能接近」是基於 bullet 3 的事實推導，若 bullet 4 標記為 inference 且引用 fast#5，則該引用不支持「效能接近」這一半的陳述，或者說該陳述混合了事實與推論但引用不足。不過，最明顯的問題在於 bullet 4 將「訓練上更省時」和「效能接近」合併，而證據 [fast#5] 只明確支持訓練時間。若視為 inference，則需確認推論是否合理。這裡主要問題是引用 [fast#5] 來支持「效能接近」是不夠的，因為 [fast#5] 原文只說「追平...訓練時間...」，「追平」是事實，不是推論。將事實標記為 inference 且引用支持該事實的證據，屬於分類錯誤或引用不精確。但根據題目要求，unsupported 包括「把推論說成定論」或「證據沒有支持」。這裡 bullet 4 說「效能接近」，證據說「追平」，意思相近。主要問題可能是將事實（追平）標記為 inference。然而，更嚴重的問題可能在表格。；建議：建議將 bullet 4 改為 [fact] 或拆分：訓練時間節省是 fact，效能追平是 fact。若保留 inference，需確保推論邏輯清晰且引用支持推論的前提。"
 },
 {
  "slide": "s08",
  "type": "ai_review_table_mismatch",
  "msg": "table row: π0‑FAST：表格欄位標題為 'Training Cost'，該列填入 '訓練時間最少 5 倍'。證據 [fast#5] 原文是「訓練時間最多少 5 倍」。「最少 5 倍」語意模糊，通常「少 5 倍」在中文裡是錯誤用法（倍數不能少，只能多），應為「節省 5 倍」或「縮短為 1/5」。此外，證據說「最多少 5 倍」，表格寫「最少 5 倍」，漏掉了「少」字或語意不通。若證據原文是「最多少 5 倍」（即至少節省 5 倍），表格寫「最少 5 倍」容易被誤解為「成本是 5 倍」或語法錯誤。；建議：改為「訓練時間縮短至少 5 倍」或「訓練成本降低至少 5 倍」，並修正證據原文可能的語病理解。"
 },
 {
  "slide": "s08",
  "type": "ai_review_disguised_claim",
  "msg": "bullet 4：Bullet 4 標記為 [inference]，但內容「離散 token（FAST）在訓練上更省時，效能接近 diffusion 版 π0」中的兩部分（訓練省時、效能接近）在證據 [fast#5] 中都是明確的事實陳述（「訓練時間最多少 5 倍」、「追平...π0」）。將明確的事實標記為推論，且引用支持該事實的證據，屬於分類錯誤。；建議：將 bullet 4 的標籤改為 [fact]，或重新表述為基於事實的總結，但標籤應反映其性質。"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。