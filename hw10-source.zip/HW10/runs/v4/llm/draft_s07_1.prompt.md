你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s07",
 "kind": "compare",
 "objective": "O5",
 "title": "RT‑1 → RT‑2 → OpenVLA → π0：模型演進比較",
 "claims": [
  "rt2#1",
  "openvla#5",
  "pi0#1"
 ],
 "introduces": [
  "diffusion",
  "flow matching"
 ],
 "purpose": "比較不同世代模型的架構、參數規模與性能差異"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[openvla]] ===
[openvla#5] (fact) 在 29 個任務上比 55B 的 RT-2-X 高 16.5% 絕對成功率，參數少 7 倍

=== [[pi0]] ===
[pi0#1] (fact) 在預訓練 VLM（PaliGemma 3B）上加一個 300M 參數的 action expert，總計 3.3B

=== [[rt2]] ===
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作

這頁必須在 defines 解釋的術語：['diffusion', 'flow matching']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。