你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s08",
 "kind": "compare",
 "objective": "O5",
 "title": "離散 vs 連續 Action Head：Octo、π0、FAST 的對照",
 "claims": [
  "continuous-action-heads#1",
  "continuous-action-heads#2",
  "fast#5"
 ],
 "introduces": [
  "diffusion",
  "flow matching"
 ],
 "purpose": "比較 diffusion、flow matching 與離散 token（FAST）三種 action head 的優缺點與實驗結果"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[continuous-action-heads]] ===
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作

=== [[fast]] ===
[fast#5] (fact) π0-FAST（自回歸、離散 token）在摺衣服等任務上追平用 diffusion 的 π0，訓練時間最多少 5 倍

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'diffusion', 'embodiment', 'flow matching', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s08",
 "kind": "compare",
 "objective": "O5",
 "title": "離散 vs 連續 Action Head：Octo、π0、FAST 的對照",
 "table": {
  "columns": [
   "Method",
   "Action Head Type",
   "Generation Process",
   "Training Cost"
  ],
  "rows": [
   [
    "Octo",
    "continuous (diffusion)",
    "Transformer readout token → diffusion head, 20 denoising steps",
    ""
   ],
   [
    "π0",
    "continuous (flow matching)",
    "PaliGemma + 300M action expert, conditional flow matching",
    ""
   ],
   [
    "π0‑FAST",
    "discrete (token)",
    "自回歸離散 token 生成",
    "訓練時間縮短至少 5 倍"
   ]
  ],
  "cite": [
   "continuous-action-heads#1",
   "continuous-action-heads#2",
   "fast#5"
  ]
 },
 "bullets": [
  {
   "text": "Octo 透過 diffusion head 以 20 步去噪產生連續動作 chunk",
   "cite": [
    "continuous-action-heads#1"
   ],
   "type": "fact"
  },
  {
   "text": "π0 使用 300M action expert 搭配 conditional flow matching 產生連續動作",
   "cite": [
    "continuous-action-heads#2"
   ],
   "type": "fact"
  },
  {
   "text": "π0‑FAST 以自回歸離散 token 方式，在摺衣服等任務上追平 diffusion 版的 π0",
   "cite": [
    "fast#5"
   ],
   "type": "fact"
  },
  {
   "text": "π0‑FAST 的訓練時間縮短至少 5 倍，顯著降低計算成本",
   "cite": [
    "fast#5"
   ],
   "type": "fact"
  },
  {
   "text": "選擇連續或離散 head 取決於資源與即時性需求的平衡",
   "type": "analogy"
  }
 ],
 "defines": [],
 "note": "提醒觀眾：雖然生成方式不同，最終都是在同一 action chunk 空間內做預測，根據資源限制選擇合適的 head。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s08",
  "type": "disguised_claim",
  "msg": "bullet 5 標成 analogy 卻不是比喻（沒有「像／好比／想像」等），看起來是事實陳述：請改成 fact/inference 並引用 claim，或刪掉"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。