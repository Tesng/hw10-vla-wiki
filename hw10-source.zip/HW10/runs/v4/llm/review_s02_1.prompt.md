你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：VLA 定義與與 LLM / VLM 的關係
bullet 1 [fact] VLA 是把 vision‑language model（VLM）微調成直接輸出機器人動作的模型  (cite: vla#1)
bullet 2 [fact] 輸入為相機影像加自然語言指令，輸出為機器人下一步或下一段的動作  (cite: vla#2)
bullet 3 [fact] VLA 借用 VLM 從網路圖文學到的知識，讓機器人理解未在機器人資料中見過的物體與指令  (cite: vla#3)

證據（claim id → 原文）：
[vla#1] (fact) VLA 是把 vision-language model（VLM）微調成直接輸出機器人動作的模型
[vla#2] (fact) 輸入：相機影像 + 自然語言指令；輸出：機器人下一步（或下一段）的動作
[vla#3] (fact) 關鍵在「借用」VLM 從網路圖文學到的知識，讓機器人理解沒在機器人資料中看過的物體與指令

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
真正的比喻不用查證。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。