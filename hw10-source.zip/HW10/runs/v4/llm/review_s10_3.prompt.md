你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：小測驗：檢視概念掌握度
quiz：以下哪項敘述正確描述離散/連續 token、action chunk 與 co‑fine‑tuning 的概念？ 選項：['離散 token 最適合接上 VLM，連續輸出適合高頻靈巧動作，如 50\u202fHz 摺衣服。', 'Action chunking 在推論時一次產生多步，以分開思考頻率與控制頻率。', '只使用機器人資料訓練會導致 VLM 遺忘網路常識，需混合訓練以保留。', 'co‑fine‑tuning 在訓練階段混合機器人與網路資料，以保留常識。'] 正解：0 解說：離散 token 容易與視覺語言模型結合，而連續輸出則更適合需要高頻率、靈巧控制的動作，例如以 50 Hz 速度摺衣服。（推論） (cite: action-representation#8, action-chunking#4, co-fine-tuning#4)

證據（claim id → 原文）：
[action-chunking#4] (inference) 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)
[action-representation#8] (fact) 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服
[co-fine-tuning#4] (inference) 直覺：只餵機器人資料，VLM 會忘掉網路上學到的常識；混著訓練能保留下來 (推論)

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
真正的比喻不用查證。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。