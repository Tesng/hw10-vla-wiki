你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：離散 token 的實作細節與挑戰
bullet 1 [fact] 可直接沿用語言模型的 next-token 預測方式訓練 VLM  (cite: action-representation#3)
bullet 2 [fact] OpenVLA 以第 1 到第 99 百分位決定 bin 範圍，避免極端值  (cite: action-representation#5)
bullet 3 [fact] 以往 VLA 每步、每維度切 256 bin；高頻時相鄰 token 幾乎相同，模型只要照抄前一個即可降低 loss  (cite: fast#1)
bullet 4 [analogy] 高頻控制下的「照抄」問題類似於把連續訊號過度取樣，導致資訊冗餘  (cite: )
名詞解釋 控制頻率：在單位時間內對機器人動作指令的發出次數

證據（claim id → 原文）：
[action-representation#3] (fact) 好處是可以直接沿用語言模型的 next-token 預測訓練 VLM
[action-representation#5] (fact) OpenVLA 以第 1 到第 99 百分位決定 bin 範圍，避免極端值
[fast#1] (fact) 問題：以往 VLA 每個時間步、每個維度各切 256 個 bin；控制頻率一高，相鄰 token 幾乎一樣，模型學到「照抄前一個」就能讓 loss 很低

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
真正的比喻不用查證。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。