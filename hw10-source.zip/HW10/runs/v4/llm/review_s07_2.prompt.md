你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：RT‑1 → RT‑2 → OpenVLA → π0：模型演進比較
bullet 1 [fact] RT‑2 提出 VLA 模型架構，微調 VLM 直接輸出機器人動作  (cite: rt2#1)
bullet 2 [fact] OpenVLA 在 29 個任務上比 55B RT‑2‑X 高 16.5% 絕對成功率，且參數少 7 倍  (cite: openvla#5)
bullet 3 [fact] π0 以 3B 預訓練 VLM 為基礎，加上 300M 參數的 action expert，總計 3.3B  (cite: pi0#1)
表格欄位：Model | Params | Task Success (on 29 tasks) | Performance vs RT‑2‑X  (cite: rt2#1, openvla#5, pi0#1)
table row: RT‑1 | - | - | -
table row: RT‑2 | - | - | -
table row: OpenVLA | 7× less than 55B RT‑2‑X | +16.5% absolute success | Higher
table row: π0 | 3.3B (3B VLM + 300M action expert) | - | -
名詞解釋 diffusion：逐步加入噪聲再逆向去噪的生成模型方法
名詞解釋 flow matching：直接學習資料分布的向量場，使生成過程等同於解微分方程

證據（claim id → 原文）：
[openvla#5] (fact) 在 29 個任務上比 55B 的 RT-2-X 高 16.5% 絕對成功率，參數少 7 倍
[pi0#1] (fact) 在預訓練 VLM（PaliGemma 3B）上加一個 300M 參數的 action expert，總計 3.3B
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
真正的比喻不用查證。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。