你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s07",
 "kind": "compare",
 "objective": "O5",
 "title": "RT‑1 → RT‑2 → OpenVLA → π0：模型演進比較",
 "claims": [
  "rt2#1",
  "openvla#5",
  "pi0#1"
 ],
 "introduces": [
  "diffusion",
  "flow matching"
 ],
 "purpose": "比較不同世代模型的架構、參數規模與性能差異"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[openvla]] ===
[openvla#5] (fact) 在 29 個任務上比 55B 的 RT-2-X 高 16.5% 絕對成功率，參數少 7 倍

=== [[pi0]] ===
[pi0#1] (fact) 在預訓練 VLM（PaliGemma 3B）上加一個 300M 參數的 action expert，總計 3.3B

=== [[rt2]] ===
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作

這頁必須在 defines 解釋的術語：['diffusion', 'flow matching']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s07",
 "kind": "compare",
 "objective": "O5",
 "title": "RT‑1 → RT‑2 → OpenVLA → π0：模型演進比較",
 "table": {
  "columns": [
   "Model",
   "Params",
   "Task Success (on 29 tasks)",
   "Performance vs RT‑2‑X"
  ],
  "rows": [
   [
    "RT‑1",
    "-",
    "-",
    "-"
   ],
   [
    "RT‑2",
    "-",
    "-",
    "-"
   ],
   [
    "OpenVLA",
    "Params 7× less than 55B RT‑2‑X",
    "+16.5% absolute success",
    "Higher"
   ],
   [
    "π0",
    "3.3B (3B VLM + 300M action expert)",
    "-",
    "-"
   ]
  ],
  "cite": [
   "rt2#1",
   "openvla#5",
   "pi0#1"
  ]
 },
 "bullets": [
  {
   "text": "RT‑2 首次提出 VLA 概念，微調 VLM 直接輸出機器人動作",
   "cite": [
    "rt2#1"
   ],
   "type": "fact"
  },
  {
   "text": "OpenVLA 在 29 個任務上比 55B RT‑2‑X 高 16.5% 絕對成功率，且參數少 7 倍",
   "cite": [
    "openvla#5"
   ],
   "type": "fact"
  },
  {
   "text": "π0 以 3B 的預訓練 VLM 為基礎，加上 300M 參數的 action expert，總計 3.3B",
   "cite": [
    "pi0#1"
   ],
   "type": "fact"
  },
  {
   "text": "模型規模的縮減讓部署在較小機器人上更實際",
   "type": "inference",
   "cite": [
    "openvla#5"
   ]
  }
 ],
 "defines": [
  {
   "term": "diffusion",
   "def": "一種逐步加入噪聲再逆向去噪的生成模型方法"
  },
  {
   "term": "flow matching",
   "def": "直接學習資料分布的向量場，使生成過程等同於解微分方程"
  }
 ],
 "note": "提醒觀眾注意，表格中的「-」代表目前卡片未提供具體數據"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s07",
  "type": "ai_review_wrong_attribution",
  "msg": "bullet 1：證據 [rt2#1] 指出 RT-2 提出了 VLA 模型（微調 VLM 輸出動作），但投影片稱 RT-2「首次提出 VLA 概念」。證據中並未提及 RT-1 或其他模型是否提出過類似概念，也未明確說明 RT-2 是「首次」提出該概念，這屬於證據未支持的細節（unsupported）或歸因錯誤。通常 VLA 概念在 RT-1 中已有雛形，RT-2 是將其擴展到通用 VLM。；建議：改為「RT-2 提出 VLA 模型架構，微調 VLM 直接輸出機器人動作」，移除「首次提出概念」的斷言，除非證據明確支持。"
 },
 {
  "slide": "s07",
  "type": "ai_review_table_mismatch",
  "msg": "table row: OpenVLA：欄位標題為 'Params'，但儲存格內容為 'Params 7× less than 55B RT-2-X'。雖然意思可懂，但嚴格來說 'Params' 欄位應填入具體參數數量（如 7B）或明確的相對描述。更嚴重的問題是，證據 [openvla#5] 只說「參數少 7 倍」，並未給出 OpenVLA 的具體參數數量（實際為 7B），表格中未提供具體數字，僅提供相對比較，這在 'Params' 欄位中可能不夠精確，但主要問題在於 'Performance vs RT-2-X' 欄位填了 'Higher'，而 'Task Success' 欄位填了 '+16.5% absolute success'。這本身沒有錯，但 'Params' 欄位填相對值而非絕對值，若其他行（如 π0）填了絕對值 3.3B，則格式不一致。不過，最明顯的錯誤是 bullet 2 和表格都引用了 openvla#5，但 openvla#5 的證據原文是「參數少 7 倍」，這通常意味著 OpenVLA 是 7B (55/7=7.8，約 7B)。表格中 OpenVLA 的 Params 欄位寫 'Params 7× less...' 是描述性的，而 π0 寫 '3.3B...' 是數值性的，格式不統一。但更關鍵的是，證據 [openvla#5] 並未提供 OpenVLA 的具體參數數量，只提供了相對關係。如果表格標題是 'Params'，通常期待具體數字。然而，這可能不算嚴重錯誤。讓我們再看其他問題。；建議：建議將 'Params' 欄位統一為具體數值或明確的相對描述。若證據未提供具體數值，可保留相對描述，但需確保一致性。"
 },
 {
  "slide": "s07",
  "type": "ai_review_unsupported",
  "msg": "bullet 4：投影片標記為 [inference]，內容是「模型規模的縮減讓部署在較小機器人上更實際」。證據 [openvla#5] 僅提到參數少 7 倍和成功率高，並未提及「部署在較小機器人上更實際」或任何關於硬體部署、計算資源限制的內容。這是一個基於常識的推論，但證據中完全沒有支持這一具體結論的文本。雖然標記為 inference，但查核標準要求檢查是否「忠於證據」。如果證據沒有支持，即使是推論，也屬於 unsupported，因為它引入了證據中不存在的細節（部署場景）。；建議：移除該 bullet，或修改為「模型規模縮減可能降低計算需求」，並明確標記為推論，且確保不超出證據範圍。但由於證據完全未提及部署，建議刪除或大幅修飾。"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。