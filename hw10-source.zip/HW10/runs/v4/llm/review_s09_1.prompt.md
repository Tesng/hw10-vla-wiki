你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：VLA 研究時間線 2022‑2025
bullet 1 [fact] 2022 年推出 35M 參數的 Transformer，示範 130k 次，將動作離散為 token。  (cite: vla-timeline#1)
bullet 2 [fact] 2023 年彙集 22 種機器人資料，支援 RT‑X 正遷移。  (cite: vla-timeline#3)
bullet 3 [fact] 2024 年模型擴展至 3.3B 參數，採用 flow matching，實現 50 Hz 折衣服。  (cite: vla-timeline#6)
timeline 2022 rt1：35M Transformer，130k 示範，動作離散成 token  (cite: vla-timeline#1)
timeline 2023 oxe：22 種機器人資料大集合，RT‑X 正遷移  (cite: vla-timeline#3)
timeline 2024 pi0：3.3B，flow matching，50 Hz 摺衣服  (cite: vla-timeline#6)

證據（claim id → 原文）：
[vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |
[vla-timeline#3] (fact) 2023 | [[oxe]] | 22 種機器人資料大集合，RT-X 正遷移  |
[vla-timeline#6] (fact) 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服  |

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
真正的比喻不用查證。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。