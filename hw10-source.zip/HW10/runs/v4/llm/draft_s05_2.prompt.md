你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s05",
 "kind": "content",
 "objective": "O3",
 "title": "資料來源：跨機體資料與 co‑fine‑tuning",
 "claims": [
  "cross-embodiment#2",
  "co-fine-tuning#1",
  "co-fine-tuning#3"
 ],
 "introduces": [
  "co-fine-tuning",
  "embodiment",
  "正遷移"
 ],
 "purpose": "解釋 VLA 如何利用 Open X‑Embodiment 等跨機體資料，以及同時混合視覺語言與機器人軌跡的訓練方式"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[co-fine-tuning]] ===
[co-fine-tuning#1] (fact) 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）
[co-fine-tuning#3] (fact) 效果：55B 模型 co-fine-tune 泛化平均 63，只用機器人資料 fine-tune 為 52

=== [[cross-embodiment]] ===
[cross-embodiment#2] (fact) Open X-Embodiment 匯集 22 種機器人、527 種技能的資料

這頁必須在 defines 解釋的術語：['co-fine-tuning', 'embodiment', '正遷移']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'action chunk', 'policy', '控制頻率']

你上一版的這頁：
{
 "id": "s05",
 "kind": "content",
 "objective": "O3",
 "title": "資料來源：跨機體資料與 co‑fine‑tuning",
 "bullets": [
  {
   "text": "Open X‑Embodiment 匯集 22 種機器人、527 種技能的資料，提供多樣化的跨機體樣本",
   "cite": [
    "cross-embodiment#2"
   ],
   "type": "fact"
  },
  {
   "text": "co‑fine‑tuning 於微調 VLM 時，同時加入機器人軌跡與大規模視覺‑語言資料（如 VQA）",
   "cite": [
    "co-fine-tuning#1"
   ],
   "type": "fact"
  },
  {
   "text": "55B 模型在 co‑fine‑tune 後的泛化平均分數提升至 63，僅用機器人資料 fine‑tune 只能達到 52",
   "cite": [
    "co-fine-tuning#3"
   ],
   "type": "fact"
  },
  {
   "text": "混合視覺‑語言與機器人軌跡的訓練，使模型學會在不同機體間正遷移知識，提升跨機體操作的通用性",
   "cite": [
    "cross-embodiment#2",
    "co-fine-tuning#1",
    "co-fine-tuning#3"
   ],
   "type": "inference"
  }
 ],
 "defines": [
  {
   "term": "co-fine-tuning",
   "def": "在微調大型視覺語言模型時，同時使用機器人軌跡資料與一般視覺語言資料的訓練方式"
  },
  {
   "term": "embodiment",
   "def": "機器人的硬體形態與感測/執行能力，決定其能執行的動作與感知範圍"
  },
  {
   "term": "正遷移",
   "def": "將在一個環境或任務上學到的知識，有效應用到不同機體或情境中，提升新任務表現"
  }
 ],
 "note": "強調資料多樣性與同時訓練的好處，讓觀眾感受跨機體學習的威力"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s05",
  "type": "too_long",
  "msg": "bullet 3 有 61 字，上限 60：請至少刪掉 6 個字，或拆成兩個 bullet"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"content","objective","title","bullets":[{"text","cite":["claim id"],"type":"fact|inference|analogy"}],"defines":[{"term","def"}],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。