你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：資料來源：跨機體資料與 co‑fine‑tuning
bullet 1 [fact] Open X‑Embodiment 匯集 22 種機器人、527 種技能的資料，提供多樣化的跨機體樣本  (cite: cross-embodiment#2)
bullet 2 [fact] co‑fine‑tuning 於微調 VLM 時，同時加入機器人軌跡與大規模視覺‑語言資料（如 VQA）  (cite: co-fine-tuning#1)
bullet 3 [fact] 55B 在 co‑fine‑tune 後泛化平均分數提升至 63，僅用機器人資料 fine‑tune 為 52  (cite: co-fine-tuning#3)
bullet 4 [inference] 混合視覺‑語言與機器人軌跡的訓練，使模型在不同機體間正遷移知識，提升跨機體操作的通用性  (cite: cross-embodiment#2, co-fine-tuning#1, co-fine-tuning#3)
名詞解釋 co-fine-tuning：在微調大型視覺語言模型時，同時使用機器人軌跡與一般視覺語言資料的訓練方式
名詞解釋 embodiment：機器人的硬體形態與感測/執行能力，決定其能執行的動作與感知範圍
名詞解釋 正遷移：將在一個環境或任務上學到的知識，有效應用到不同機體或情境中，提升新任務表現

證據（claim id → 原文）：
[co-fine-tuning#1] (fact) 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）
[co-fine-tuning#3] (fact) 效果：55B 模型 co-fine-tune 泛化平均 63，只用機器人資料 fine-tune 為 52
[cross-embodiment#2] (fact) Open X-Embodiment 匯集 22 種機器人、527 種技能的資料

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
真正的比喻不用查證。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。