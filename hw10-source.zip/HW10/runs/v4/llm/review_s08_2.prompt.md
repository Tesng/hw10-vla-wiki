你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：離散 vs 連續 Action Head：Octo、π0、FAST 的對照
bullet 1 [fact] Octo 透過 diffusion head 以 20 步去噪產生連續動作 chunk  (cite: continuous-action-heads#1)
bullet 2 [fact] π0 使用 300M action expert 搭配 conditional flow matching 產生連續動作  (cite: continuous-action-heads#2)
bullet 3 [fact] π0‑FAST 以自回歸離散 token 方式，在摺衣服等任務上追平 diffusion 版的 π0  (cite: fast#5)
bullet 4 [fact] π0‑FAST 的訓練時間縮短至少 5 倍，顯著降低計算成本  (cite: fast#5)
表格欄位：Method | Action Head Type | Generation Process | Training Cost  (cite: continuous-action-heads#1, continuous-action-heads#2, fast#5)
table row: Octo | continuous (diffusion) | Transformer readout token → diffusion head, 20 denoising steps | 
table row: π0 | continuous (flow matching) | PaliGemma + 300M action expert, conditional flow matching | 
table row: π0‑FAST | discrete (token) | 自回歸離散 token 生成 | 訓練時間縮短至少 5 倍

證據（claim id → 原文）：
[continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
[continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作
[fast#5] (fact) π0-FAST（自回歸、離散 token）在摺衣服等任務上追平用 diffusion 的 π0，訓練時間最多少 5 倍

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
真正的比喻不用查證。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。