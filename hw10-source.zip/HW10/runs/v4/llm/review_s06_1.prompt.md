你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：Action Chunking：提升控制頻率的關鍵
bullet 1 [fact] 模型一次輸出未來多步動作（稱為 action chunk）  (cite: action-chunking#1)
bullet 2 [fact] π0 可一次輸出 H=50 步，控制頻率達 50 Hz  (cite: action-chunking#2)
bullet 3 [fact] RT‑2 55B 每步跑一次大模型，僅 1‑3 Hz；OpenVLA 在 RTX 4090 約 6 Hz  (cite: action-chunking#3)
bullet 4 [inference] 一次預測多步可將推論速度提升數倍，從而提升控制頻率  (cite: action-chunking#2, action-chunking#3)

證據（claim id → 原文）：
[action-chunking#1] (fact) 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步
[action-chunking#2] (fact) π0 一次輸出 H=50 步，控制頻率可達 50 Hz
[action-chunking#3] (fact) 對比：RT-2 55B 每步都要跑一次大模型，只有 1-3 Hz ；OpenVLA 在 RTX 4090 約 6 Hz

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
- disguised_claim：標成 analogy 的句子其實是事實陳述（例如「離散化會增加延遲」），沒有出處
- table_mismatch：表格儲存格內容和欄位標題對不上（例如「訓練資料」欄填的是分箱範圍），或把 A 的數字放到 B 那一列
真正的比喻不用查證。措辭不同但意思一樣的，不算錯。也請順便指出錯字。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading|disguised_claim|table_mismatch|typo","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。