"""把 v3（Groq 實跑）每一份逐頁稿，用 v4 修正後的檢查器重新檢查，統計 v3 的錯誤有多少是檢查器誤報。"""
import json, sys, glob
sys.path.insert(0, "pipeline")
from checks import check_slide
R = "runs/v3"
st = json.load(open(f"{R}/state.json"))
plans = {s["id"]: s for s in st["outline"]}
v3_by_call = {(e["slide"], e["call"]): e["errors"] for e in st["events"] if e["node"] == "draft_pages"}
tot3 = {}; tot4 = {}; rows = []
for (sid, n), errs3 in sorted(v3_by_call.items()):
    f = f"{R}/llm/draft_{sid}_{n}.response.json"
    try:
        slide = json.load(open(f))
    except Exception:
        continue
    slide.update(id=sid, kind=plans[sid]["kind"], objective=plans[sid].get("objective"))
    before = set()
    for x in st["outline"]:
        if x["id"] == sid: break
        before |= set(x.get("introduces", []))
    errs4 = [f"{e['type']}: {e['msg']}" for e in check_slide(slide, plans[sid], st["evidence"], before)]
    for e in errs3:
        k = e.split(":")[0]; tot3[k] = tot3.get(k, 0) + 1
    for e in errs4:
        k = e.split(":")[0]; tot4[k] = tot4.get(k, 0) + 1
    rows.append((sid, n, len(errs3), len(errs4), errs4))
print("| 錯誤類型 | v3 檢查器 | v4 檢查器（同一批稿子） |\n|---|---|---|")
for k in sorted(set(tot3) | set(tot4), key=lambda k: -tot3.get(k, 0)):
    print(f"| {k} | {tot3.get(k, 0)} | {tot4.get(k, 0)} |")
print(f"\n逐頁稿 {len(rows)} 份；v3 判定不通過 {sum(r[2] > 0 for r in rows)} 份，v4 判定不通過 {sum(r[3] > 0 for r in rows)} 份\n")
print("v4 仍抓到的問題：")
for sid, n, a, b, e4 in rows:
    if e4:
        print(f"- draft_{sid}_{n}: " + "；".join(x[:110] for x in e4))
