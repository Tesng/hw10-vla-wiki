"""事後審查 v1：把每個 fact bullet 對到被引用頁中最相似的那一行，看它其實是 fact 還是 (推論)。"""
import json, sys
sys.path.insert(0, "pipeline")
from wiki import load_wiki
from checks import grounded_units
pages = load_wiki()
bi = lambda s: {s[i:i+2] for i in range(len(s)-1)}
slides = json.load(open("runs/v1/state.json"))["slides"]
rows = []
for s in slides:
    for text, cites, where in grounded_units(s):
        best = max(((len(bi(text) & bi(l)) / max(1, len(bi(text))), c, l) for c in cites if c in pages
                    for l in pages[c].bullets), default=(0, None, ""))
        tag = "INFERENCE" if "(推論)" in best[2] else ("WEAK" if best[0] < 0.35 else "ok")
        rows.append((tag, s["id"], where, round(best[0], 2), text[:38], best[1], best[2][:60]))
for r in rows:
    if r[0] != "ok":
        print(*r, sep=" | ")
print("total grounded units:", len(rows), " flagged:", sum(r[0] != "ok" for r in rows))
