"""把 v2 的 claim 層級檢查回溯套用在 v1 的 draft_1 上：每個頁面引用換成該頁最相似的 claim，再跑 check_slides。"""
import json, sys
sys.path.insert(0, "pipeline")
from wiki import load_wiki, claims
from checks import check_slides
pages = load_wiki(); ev = claims(pages)
bi = lambda s: {s[i:i+2] for i in range(len(s)-1)}
def best(text, page):
    cands = [(len(bi(text) & bi(c["text"])), cid) for cid, c in ev.items() if c["page"] == page]
    return max(cands)[1] if cands else page
slides = json.load(open("runs/v1/llm/draft_1.response.json"))["slides"]
for s in slides:
    for b in s.get("bullets", []):
        if b.get("cite"): b["cite"] = [best(b["text"], p) for p in b["cite"]]
    for it in s.get("timeline", []):
        it["cite"] = [best(it["text"], p) for p in it["cite"]]
    if s.get("table"):
        rows = " ".join(" ".join(r) for r in s["table"]["rows"])
        s["table"]["cite"] = sorted({cid for p in s["table"]["cite"] for r in s["table"]["rows"] for cid in [best(" ".join(r), p)]})
    if s.get("quiz"):
        s["quiz"]["cite"] = [best(s["quiz"]["explain"], p) for p in s["quiz"]["cite"]]
errs = check_slides(slides, ev)
for e in errs: print(e)
print(len(errs), "errors")
