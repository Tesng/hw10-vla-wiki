# 檢查報告 — run `v3`

- 狀態：**done_with_issues: ['s08', 's09', 's11']**
- LLM：groq；模型：{'writer': 'openai/gpt-oss-120b', 'reviewer': 'openai/gpt-oss-20b'}
- LLM 呼叫 106 次，prompt tokens 95205，completion tokens 34235，429 等待 4 次
- 渲染檢查方式：heuristic（未使用 Playwright：ModuleNotFoundError）

## 節點執行次數（graph 上每個圈轉了幾次）

| 節點 | 次數 |
|---|---|
| load_wiki | 1 |
| lint_wiki | 1 |
| query_wiki | 1 |
| evidence_cards | 1 |
| outline | 1 |
| check_outline | 1 |
| human_gate | 1 |
| draft_pages | 7 |
| ai_review | 5 |
| check_deck | 3 |
| render_html | 3 |
| check_render | 3 |

## 各關卡檢查結果

| 關卡 | 結果 |
|---|---|
| outline | {"n": 0, "by_type": {}} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "heuristic（未使用 Playwright：ModuleNotFoundError）", "overflow": {"s04": 36, "s08": 108, "s09": 146}, "sections": 13, "external": []} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "heuristic（未使用 Playwright：ModuleNotFoundError）", "overflow": {"s08": 108, "s09": 30}, "sections": 13, "external": []} |
| deck | {"n": 0, "raw_unused": []} |
| render | {"method": "heuristic（未使用 Playwright：ModuleNotFoundError）", "overflow": {"s08": 108, "s09": 78}, "sections": 13, "external": []} |

## 人工確認

- 大綱第 1 版：approve

## 逐頁紀錄（小圈）

| 頁 | 逐頁稿呼叫 | AI 審查呼叫 | 審查退回 | 渲染退回 | 整份檢查退回 |
|---|---|---|---|---|---|
| s01 Vision‑Language‑Action (VLA) 模型概覽 | 1 | 0 | 0 | 0 | 0 |
| s02 VLA 的定義與與 LLM / VLM 的關係 | 1 | 1 | 0 | 0 | 0 |
| s03 動作表示：離散 token vs 連續動作 | 4 | 2 | 1 | 0 | 0 |
| s04 離散 vs 連續：效能與頻率比較 | 4 | 3 | 1 | 1 | 0 |
| s05 資料來源：跨機體資料與 co‑fine‑tuning | 2 | 1 | 0 | 0 | 0 |
| s06 Action Chunking：為何需要一次預測多步 | 2 | 1 | 0 | 0 | 0 |
| s07 Chunking 前後的推論速度比較 | 2 | 1 | 0 | 0 | 0 |
| s08 從 RT‑1 到 π0 的演進路線 | 9 | 3 | 0 | 2 | 0 |
| s09 RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異比較 | 15 | 5 | 2 | 2 | 0 |
| s10 FAST：離散路徑的再度崛起 | 6 | 2 | 1 | 0 | 0 |
| s11 小測驗：檢視概念掌握 | 3 | 1 | 0 | 0 | 0 |
| s12 結論與未來展望 | 1 | 1 | 0 | 0 | 0 |

## 錯誤類型統計（哪個節點最常出錯）

| 節點 | 錯誤類型 | 次數 |
|---|---|---|
| draft_pages | ungrounded_number | 71 |
| ai_review | unsupported | 9 |
| draft_pages | too_long | 7 |
| draft_pages | uncited | 5 |
| draft_pages | undefined_term | 3 |
| draft_pages | inference_as_fact | 3 |
| draft_pages | number_in_analogy | 1 |

## 覆蓋率

- 用到的 claim：27
- 用到的論文：['fast', 'octo', 'openvla', 'oxe', 'pi0', 'rt1', 'rt2']
- 沒用到的論文：無

## Wiki 中的矛盾（⚠）

- action-representation: - ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 [[src:pi0]]；FAST 則顯示離散 token 的 π0-FA

## 未解決（已達上限，需人工處理）

- s08: [{'type': 'overflow', 'msg': '108px'}]
- s09: [{'type': 'overflow', 'msg': '78px'}]
- s11: [{'slide': 's11', 'type': 'ungrounded_number', 'msg': "quiz explain 的數字 ['4', '9'] 不在所引 claim ['action-representation#9', 'co-fine-tuning#4'] 中"}, {'slide': 's11', 'type': 'inference_as_fact', 'msg': 'quiz explain 引用 (推論) claim 卻標成 fact'}]

## 事件時間線

- 11:02:06 `draft_pages` s01 第1次 ✔
- 11:02:08 `draft_pages` s02 第1次 ✔
- 11:02:12 `draft_pages` s03 第1次 ✘ uncited: bullet 3 沒有引用 claim；undefined_term: 術語「diffusion」在這頁第一次出現，必須放進 defines
- 11:02:13 `draft_pages` s03 第2次 ✔
- 11:02:15 `draft_pages` s04 第1次 ✘ uncited: bullet 4 沒有引用 claim
- 11:02:16 `draft_pages` s04 第2次 ✔
- 11:07:21 `draft_pages` s05 第2次 ✔
- 11:07:22 `draft_pages` s06 第1次 ✘ number_in_analogy: bullet 3 是比喻卻含數字；uncited: bullet 2 沒有引用 claim
- 11:07:23 `draft_pages` s06 第2次 ✔
- 11:08:23 `draft_pages` s07 第1次 ✘ ungrounded_number: bullet 2 的數字 ['4090'] 不在所引 claim ['action-chunking#3'] 中
- 11:08:24 `draft_pages` s07 第2次 ✔
- 11:08:26 `draft_pages` s08 第1次 ✘ ungrounded_number: bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中；ungrounded_number: bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中；ungrounded_number: timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中；undefined_term: 術語「flow matching」在這頁第一次出現，必須放進 defines
- 11:09:27 `draft_pages` s08 第2次 ✘ ungrounded_number: bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中；ungrounded_number: bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中；ungrounded_number: timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中
- 11:10:30 `draft_pages` s08 第3次 ✘ ungrounded_number: bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中；ungrounded_number: bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中；ungrounded_number: bullet 3 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中；ungrounded_number: timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中
- 11:10:34 `draft_pages` s09 第1次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；uncited: bullet 4 沒有引用 claim；uncited: bullet 5 沒有引用 claim；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3
- 11:11:37 `draft_pages` s09 第2次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:12:40 `draft_pages` s09 第3次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:12:41 `draft_pages` s10 第1次 ✘ too_long: bullet 1 有 68 字，上限 60；too_long: bullet 2 有 67 字，上限 60；too_long: bullet 3 有 61 字，上限 60
- 11:13:42 `draft_pages` s10 第2次 ✘ too_long: bullet 2 有 63 字，上限 60
- 11:13:44 `draft_pages` s10 第3次 ✘ too_long: bullet 2 有 63 字，上限 60
- 11:14:44 `draft_pages` s11 第1次 ✘ ungrounded_number: quiz explain 的數字 ['4', '9'] 不在所引 claim ['action-representation#9', 'co-fine-tuning#4'] 中；inference_as_fact: quiz explain 引用 (推論) claim 卻標成 fact
- 11:14:46 `draft_pages` s11 第2次 ✘ ungrounded_number: quiz explain 的數字 ['4', '9'] 不在所引 claim ['action-representation#9', 'co-fine-tuning#4'] 中；inference_as_fact: quiz explain 引用 (推論) claim 卻標成 fact
- 11:15:46 `draft_pages` s11 第3次 ✘ ungrounded_number: quiz explain 的數字 ['4', '9'] 不在所引 claim ['action-representation#9', 'co-fine-tuning#4'] 中；inference_as_fact: quiz explain 引用 (推論) claim 卻標成 fact
- 11:15:47 `draft_pages` s12 第1次 ✔
- 11:15:47 `ai_review` s02 第1次 ✔
- 11:15:48 `ai_review` s03 第1次 ✘ unsupported: bullet 3 — 該推論未在證據中得到支持，證據僅描述了離散化與連續化的實作方式，未提及其對語言模型預測機制或控制資訊的影響。
- 11:15:49 `ai_review` s04 第1次 ✘ unsupported: bullet 2 — 證據未提及連續輸出在 50 Hz 以上能保持平滑動作，僅說明其更適合高頻、靈巧動作。；unsupported: bullet 4 — 證據未提及高頻控制需要更低延遲與更小資料量，僅說明連續輸出更適合高頻動作。
- 11:15:50 `ai_review` s05 第1次 ✔
- 11:15:50 `ai_review` s06 第1次 ✔
- 11:15:51 `ai_review` s07 第1次 ✔
- 11:16:49 `ai_review` s08 第1次 ✔
- 11:16:51 `ai_review` s09 第1次 ✘ unsupported: table row: RT‑1 — 缺乏證據說明 RT‑1 是否明確說明離散或連續化方式；unsupported: table row: RT‑2 | Training Data — 未提供證據說明 RT‑2 使用擴增視覺‑語言‑動作對作為訓練資料；unsupported: table row: RT‑2 | Inference Mechanism — 未提供證據說明 RT‑2 直接預測動作 token 的推論機制
- 11:16:52 `ai_review` s10 第1次 ✘ unsupported: bullet 4 — 推論說離散 token 若能有效壓縮，仍可保持與連續 diffusion 相同表現，但證據僅指出 π0-FAST 在摺衣服等任務上追平 diffusion 版 π0，並未證明壓縮本身能保證相同表現。
- 11:16:53 `ai_review` s11 第1次 ✔
- 11:16:53 `ai_review` s12 第1次 ✔
- 11:16:54 `draft_pages` s03 第3次 ✘ undefined_term: 術語「diffusion」在這頁第一次出現，必須放進 defines
- 11:16:56 `draft_pages` s03 第4次 ✔
- 11:17:57 `draft_pages` s04 第3次 ✔
- 11:19:00 `draft_pages` s09 第4次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:20:02 `draft_pages` s09 第5次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:21:05 `draft_pages` s09 第6次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:21:07 `draft_pages` s10 第4次 ✘ too_long: bullet 2 有 63 字，上限 60
- 11:22:07 `draft_pages` s10 第5次 ✘ too_long: bullet 2 有 63 字，上限 60
- 11:22:09 `draft_pages` s10 第6次 ✔
- 11:22:10 `ai_review` s03 第2次 ✔
- 11:22:10 `ai_review` s04 第2次 ✔
- 11:22:12 `ai_review` s09 第2次 ✘ unsupported: bullet 4 — 說明 Diffusion 用於 OpenVLA 生成離散動作 token 序列，但證據 openvla#3 並未提及 Diffusion，僅說明 256 個 bin 與範圍設定。；unsupported: table row OpenVLA – Inference Mechanism — 表格中寫「基於 diffusion 生成離散 token 序列」，但證據中並未提及 Diffusion。
- 11:22:13 `ai_review` s10 第2次 ✔
- 11:23:12 `draft_pages` s09 第7次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:24:15 `draft_pages` s09 第8次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:25:17 `draft_pages` s09 第9次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:25:19 `ai_review` s09 第3次 ✔
- 11:25:21 `draft_pages` s04 第4次 ✔
- 11:26:20 `draft_pages` s08 第4次 ✘ ungrounded_number: bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中；ungrounded_number: bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中；ungrounded_number: bullet 3 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中；ungrounded_number: timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中
- 11:27:23 `draft_pages` s08 第5次 ✘ ungrounded_number: bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中；ungrounded_number: bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中；ungrounded_number: bullet 3 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中；ungrounded_number: timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中
- 11:28:25 `draft_pages` s08 第6次 ✘ ungrounded_number: bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中；ungrounded_number: bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中；ungrounded_number: bullet 3 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中；ungrounded_number: timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中
- 11:29:28 `draft_pages` s09 第10次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:30:30 `draft_pages` s09 第11次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:31:32 `draft_pages` s09 第12次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:31:33 `ai_review` s04 第3次 ✔
- 11:31:33 `ai_review` s08 第2次 ✔
- 11:31:34 `ai_review` s09 第4次 ✔
- 11:32:35 `draft_pages` s08 第7次 ✘ ungrounded_number: bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中；ungrounded_number: bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中；ungrounded_number: bullet 3 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中；ungrounded_number: timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中
- 11:33:37 `draft_pages` s08 第8次 ✘ ungrounded_number: bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中；ungrounded_number: bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中；ungrounded_number: bullet 3 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中；ungrounded_number: timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中
- 11:34:40 `draft_pages` s08 第9次 ✘ ungrounded_number: bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中；ungrounded_number: bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中；ungrounded_number: bullet 3 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中；ungrounded_number: timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中
- 11:35:43 `draft_pages` s09 第13次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:36:46 `draft_pages` s09 第14次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:37:49 `draft_pages` s09 第15次 ✘ ungrounded_number: bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中；ungrounded_number: table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中
- 11:37:49 `ai_review` s08 第3次 ✔
- 11:37:50 `ai_review` s09 第5次 ✔
