# 證據卡：Octo: An Open-Source Generalist Robot Policy

- [action-chunking#1] (fact) 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步
- [action-representation#6] (fact) Octo 用 diffusion action head 輸出連續動作
- [continuous-action-heads#1] (fact) Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk
- [cross-embodiment#4] (fact) Octo 從 OXE 挑 800k 條軌跡 ；OpenVLA 挑 970k 條
- [octo#1] (fact) 兩種尺寸：Octo-Small 27M、Octo-Base 93M 參數
- [octo#2] (fact) 不是建在預訓練 VLM 上，因此是「通用機器人 policy」而非 RT-2 定義的 VLA
- [octo#3] (fact) 從 Open X-Embodiment 的 25 個資料集挑出 800k 條軌跡預訓練
- [octo#4] (fact) Transformer + 可學習的 readout token（類似 BERT 的 [CLS]）；分塊遮罩注意力讓 fine-tune 時可增減輸入/輸出
- [octo#5] (fact) 用 diffusion action head 預測一段連續動作（20 個 diffusion 步），見 [[continuous-action-heads]] 與 [[action-chunking]]
- [octo#6] (fact) 任務可用語言（t5-base 編碼）或目標影像指定
- [octo#7] (fact) Zero-shot 比 RT-1-X 高 29% 成功率，與 55B 的 RT-2-X 表現相近
- [octo#8] (fact) 單張 A5000 消費級 GPU、約 100 筆示範、約 5 小時即可 fine-tune；平均比次佳基準高 52%
- [vla#5] (fact) Octo 是通用機器人 policy，但不是建在預訓練 VLM 上
- [vla-timeline#4] (fact) 2024 | [[octo]] | 93M 開源通用 policy，diffusion head  |
