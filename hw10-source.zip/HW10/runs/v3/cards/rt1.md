# 證據卡：RT-1: Robotics Transformer for Real-World Control at Scale

- [action-representation#1] (fact) RT-1 把 11 個動作維度各離散成 256 個 bin
- [cross-embodiment#6] (fact) 呼應 RT-1 的結論：資料多樣性比資料量更重要
- [vla#4] (fact) RT-1 用 Transformer 直接學動作，但沒有用網路規模預訓練的 VLM
- [vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |
