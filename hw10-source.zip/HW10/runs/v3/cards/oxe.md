# 證據卡：Open X-Embodiment: Robotic Learning Datasets and RT-X Models

- [cross-embodiment#2] (fact) Open X-Embodiment 匯集 22 種機器人、527 種技能的資料
- [cross-embodiment#3] (fact) RT-X 證明用別台機器人的資料訓練，能提升各台機器人的能力（positive transfer）
- [oxe#1] (fact) 匯集 22 種機器人的資料，由 21 個機構合作
- [oxe#2] (fact) 涵蓋 527 種技能（160,266 個任務）
- [oxe#3] (fact) 用統一的資料格式釋出
- [oxe#4] (fact) 用這份資料訓練的 RT-X 模型（RT-1-X、RT-2-X）出現正遷移（positive transfer），提升多種機器人的能力
- [vla-timeline#3] (fact) 2023 | [[oxe]] | 22 種機器人資料大集合，RT-X 正遷移  |
