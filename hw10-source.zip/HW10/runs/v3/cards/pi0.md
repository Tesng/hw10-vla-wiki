# 證據卡：π0: A Vision-Language-Action Flow Model for General Robot Control

- [action-chunking#2] (fact) π0 一次輸出 H=50 步，控制頻率可達 50 Hz
- [action-representation#7] (fact) π0 用 flow matching 的 action expert 輸出連續動作，不做離散化
- [action-representation#8] (fact) 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服
- [action-representation#11] (fact) ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 ；FAST 則顯示離散 token 的 π0-FAST 在摺衣服上也能追平 diffusion 版 π0，但推論較慢（約 750 ms 對 100 ms）
- [continuous-action-heads#2] (fact) π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作
- [cross-embodiment#5] (fact) π0 混用 7 種機器人配置，並加入約 9.1% 開源資料
- [pi0#1] (fact) 在預訓練 VLM（PaliGemma 3B）上加一個 300M 參數的 action expert，總計 3.3B
- [pi0#2] (fact) action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 ，見 [[continuous-action-heads]]
- [pi0#3] (fact) 一次輸出 H=50 步的 action chunk，靈巧任務控制頻率最高 50 Hz ，見 [[action-chunking]]
- [pi0#4] (fact) 超過 10,000 小時機器人資料；7 種機器人配置、68 個任務；約 9.1% 是開源資料（OXE、Bridge v2、DROID）
- [pi0#5] (fact) 訓練分兩段：廣泛資料 pre-training 得到通用基底，再用少量高品質資料 post-training 到特定任務（簡單任務約 5 小時資料，最難的 100 小時以上）
- [pi0#6] (fact) 示範任務：摺衣服、收拾餐桌、組紙箱、裝雞蛋、裝購物袋
- [vla#6] (fact) RT-2、OpenVLA、π0 都建在預訓練 VLM 上，屬於 VLA
- [vla-timeline#6] (fact) 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服  |
