# 證據卡：FAST: Efficient Action Tokenization for Vision-Language-Action Models

- [action-representation#9] (fact) 樸素的 256 bin 在高頻時相鄰 token 高度相關，模型容易陷入「照抄」的局部解
- [action-representation#10] (fact) FAST 先做 DCT 再用 BPE 壓縮，50 Hz 的 1 秒動作從 700 個 token 降到 53 個
- [action-representation#11] (fact) ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 ；FAST 則顯示離散 token 的 π0-FAST 在摺衣服上也能追平 diffusion 版 π0，但推論較慢（約 750 ms 對 100 ms）
- [fast#1] (fact) 問題：以往 VLA 每個時間步、每個維度各切 256 個 bin；控制頻率一高，相鄰 token 幾乎一樣，模型學到「照抄前一個」就能讓 loss 很低
- [fast#2] (fact) 做法：每個維度先做離散餘弦轉換（DCT）→ 係數四捨五入（丟掉不重要的）→ 低頻在前攤平 → 用 BPE 壓縮，詞表預設 1024
- [fast#3] (fact) 壓縮效果：50 Hz 摺 T 恤的 1 秒動作，原本 700 個 token，FAST 只要 53 個（13.2 倍）
- [fast#4] (fact) 每段動作約 30 個 token／手臂，幾乎不隨控制頻率增加
- [fast#5] (fact) π0-FAST（自回歸、離散 token）在摺衣服等任務上追平用 diffusion 的 π0，訓練時間最多少 5 倍
- [fast#6] (fact) 代價：在 4090 上每段動作推論約 750 ms，diffusion 版 π0 約 100 ms
- [vla-timeline#7] (fact) 2025 | [[fast]] | DCT + BPE 動作 token 化，離散路線追平 diffusion  |
