# 證據卡：OpenVLA: An Open-Source Vision-Language-Action Model

- [action-chunking#3] (fact) 對比：RT-2 55B 每步都要跑一次大模型，只有 1-3 Hz ；OpenVLA 在 RTX 4090 約 6 Hz
- [action-representation#4] (fact) PaLM-E 和 OpenVLA 都用「覆寫最少用的 256 個 token」來放動作
- [action-representation#5] (fact) OpenVLA 以第 1 到第 99 百分位決定 bin 範圍，避免極端值
- [continuous-action-heads#4] (fact) 對照組：OpenVLA fine-tune 後比 Diffusion Policy 高 20.4%，顯示離散 token 路線在其實驗中仍有競爭力
- [cross-embodiment#4] (fact) Octo 從 OXE 挑 800k 條軌跡 ；OpenVLA 挑 970k 條
- [openvla#1] (fact) 7B 參數開源 VLA：Prismatic-7B = 600M 視覺編碼器（融合 SigLIP 與 DINOv2）+ 2 層 MLP projector + Llama 2 7B
- [openvla#2] (fact) 在 Open X-Embodiment 中挑 970k 條軌跡訓練
- [openvla#3] (fact) 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token ，見 [[action-representation]]
- [openvla#4] (fact) 訓練：64 張 A100 跑 14 天（21,500 A100-hours）
- [openvla#5] (fact) 在 29 個任務上比 55B 的 RT-2-X 高 16.5% 絕對成功率，參數少 7 倍
- [openvla#6] (fact) fine-tune 後比 Diffusion Policy 高 20.4%
- [openvla#7] (fact) LoRA（rank 32，只訓練約 1.4% 參數）成功率 68.2%，全參數 fine-tune 69.7%；單張 A100 約 10-15 小時
- [openvla#8] (fact) 一張 RTX 4090 約 6 Hz、約 15GB 記憶體
- [vla#6] (fact) RT-2、OpenVLA、π0 都建在預訓練 VLM 上，屬於 VLA
- [vla-timeline#5] (fact) 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5%  |
