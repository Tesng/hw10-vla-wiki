# 大綱（第 1 版）

| id | kind | 目標 | 標題 | claims | 介紹術語 |
|---|---|---|---|---|---|
| s01 | title |  | Vision‑Language‑Action (VLA) 模型概覽 | 0 | VLA, VLM, policy |
| s02 | content | O1 | VLA 的定義與與 LLM / VLM 的關係 | 2 |  |
| s03 | flow | O2 | 動作表示：離散 token vs 連續動作 | 2 | DoF, action chunk |
| s04 | compare | O2 | 離散 vs 連續：效能與頻率比較 | 2 | 控制頻率 |
| s05 | content | O3 | 資料來源：跨機體資料與 co‑fine‑tuning | 2 | embodiment, co-fine-tuning, 正遷移 |
| s06 | flow | O4 | Action Chunking：為何需要一次預測多步 | 2 | action chunk |
| s07 | compare | O4 | Chunking 前後的推論速度比較 | 2 |  |
| s08 | timeline | O5 | 從 RT‑1 到 π0 的演進路線 | 4 |  |
| s09 | compare | O5 | RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異比較 | 4 | diffusion, flow matching |
| s10 | content | O5 | FAST：離散路徑的再度崛起 | 3 |  |
| s11 | quiz |  | 小測驗：檢視概念掌握 | 2 |  |
| s12 | summary |  | 結論與未來展望 | 2 |  |
