你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：Chunking 前後的推論速度比較
bullet 1 [fact] RT-2 每步都要跑一次大模型，頻率只有 1‑3 Hz  (cite: action-chunking#3)
bullet 2 [fact] OpenVLA 約 6 Hz，因為一次推論多步  (cite: action-chunking#3)
bullet 3 [inference] 大模型推論慢，透過一次多算幾步可把「思考頻率」與「控制頻率」分離  (cite: action-chunking#4)
表格欄位：Model | Chunking 設計 | 推論頻率 (Hz)  (cite: action-chunking#3)
table row: RT-2 55B | 每步都跑一次大模型 | 1-3
table row: OpenVLA | 一次多算幾步 | ~6

證據（claim id → 原文）：
[action-chunking#3] (fact) 對比：RT-2 55B 每步都要跑一次大模型，只有 1-3 Hz ；OpenVLA 在 RTX 4090 約 6 Hz
[action-chunking#4] (inference) 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
比喻（標 analogy）不用查證。措辭不同但意思一樣的，不算錯。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。