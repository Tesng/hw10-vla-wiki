你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異比較
bullet 1 [fact] RT‑2 首次提出 VLA 架構，讓 VLM 直接產生機器人動作  (cite: rt2#1)
bullet 2 [fact] OpenVLA 以 256 個離散 bin 表示關節角度，避免極端值擴張  (cite: openvla#3)
bullet 3 [inference] π0 的 action expert 透過 flow matching 輸出連續動作  (cite: pi0#2, action-representation#7)
bullet 4 [inference] 離散化需要先生成 token 再映射，推論步驟較多  (cite: openvla#3)
表格欄位：Model | Action Representation | Training Data | Inference Mechanism  (cite: rt2#1, openvla#3, pi0#2, action-representation#7)
table row: RT‑2 | VLM 直接輸出動作 |  | 
table row: OpenVLA | 每維 256 個 bin | 第 1–99 百分位示範資料 | 生成離散 token 序列
table row: π0 | flow matching 連續動作 | 條件 flow matching 資料 | 直接回傳連續向量
名詞解釋 diffusion：逐步加入噪聲再去噪的生成過程
名詞解釋 flow matching：一次性學習從噪聲到目標樣本的向量場映射

證據（claim id → 原文）：
[action-representation#7] (fact) π0 用 flow matching 的 action expert 輸出連續動作，不做離散化
[openvla#3] (fact) 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token ，見 [[action-representation]]
[pi0#2] (fact) action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 ，見 [[continuous-action-heads]]
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
比喻（標 analogy）不用查證。措辭不同但意思一樣的，不算錯。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。