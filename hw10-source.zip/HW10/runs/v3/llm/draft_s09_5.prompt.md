你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s09",
 "kind": "compare",
 "objective": "O5",
 "title": "RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異比較",
 "claims": [
  "rt2#1",
  "openvla#3",
  "pi0#2",
  "action-representation#7"
 ],
 "introduces": [
  "diffusion",
  "flow matching"
 ],
 "purpose": "對照不同模型在動作表示、訓練資料與推論機制上的差異"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#7] (fact) π0 用 flow matching 的 action expert 輸出連續動作，不做離散化

=== [[openvla]] ===
[openvla#3] (fact) 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token ，見 [[action-representation]]

=== [[pi0]] ===
[pi0#2] (fact) action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 ，見 [[continuous-action-heads]]

=== [[rt2]] ===
[rt2#1] (fact) 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作

這頁必須在 defines 解釋的術語：['diffusion', 'flow matching']
之前投影片已解釋過、不必再解釋的術語：['DoF', 'VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s09",
 "kind": "compare",
 "objective": "O5",
 "title": "RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異比較",
 "table": {
  "columns": [
   "Model",
   "Action Representation",
   "Training Data",
   "Inference Mechanism"
  ],
  "rows": [
   [
    "RT‑2",
    "微調 VLM 直接輸出動作 (VLA)",
    "",
    ""
   ],
   [
    "OpenVLA",
    "每維 256 個離散 bin，覆寫 Llama 最少用的 256 token",
    "使用第 1–99 百分位範圍的示範資料",
    "基於 diffusion 生成離散 token 序列"
   ],
   [
    "π0",
    "使用 flow matching 的 action expert 輸出連續動作，不做離散化",
    "條件 flow matching 訓練的機器人狀態‑動作對",
    "直接回傳連續動作向量"
   ]
  ],
  "cite": [
   "rt2#1",
   "openvla#3",
   "pi0#2",
   "action-representation#7"
  ]
 },
 "bullets": [
  {
   "text": "RT‑2 首次提出 VLA 架構，讓 VLM 直接產生機器人動作",
   "cite": [
    "rt2#1"
   ],
   "type": "fact"
  },
  {
   "text": "OpenVLA 以 256 個離散 bin 代表每個關節角度，避免極端值擴張",
   "cite": [
    "openvla#3"
   ],
   "type": "fact"
  },
  {
   "text": "π0 的 action expert 透過 flow matching 直接輸出連續動作，省去離散化步驟",
   "cite": [
    "pi0#2",
    "action-representation#7"
   ],
   "type": "fact"
  },
  {
   "text": "Diffusion 在 OpenVLA 中用於逐步生成離散動作 token 序列",
   "cite": [
    "openvla#3"
   ],
   "type": "inference"
  },
  {
   "text": "Flow matching 讓 π0 以單一步驟產生平滑的連續控制信號",
   "cite": [
    "pi0#2",
    "action-representation#7"
   ],
   "type": "inference"
  }
 ],
 "defines": [
  {
   "term": "diffusion",
   "def": "逐步加入噪聲再去噪的生成過程，用於從隨機噪聲恢復目標資料"
  },
  {
   "term": "flow matching",
   "def": "一次性學習從噪聲到目標樣本的向量場映射"
  }
 ],
 "note": "提醒觀眾：離散化 vs 連續化的選擇會影響模型的推論速度與精度，特別是機器人即時控制的需求。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s09",
  "type": "ungrounded_number",
  "msg": "bullet 1 的數字 ['2'] 不在所引 claim ['rt2#1'] 中"
 },
 {
  "slide": "s09",
  "type": "ungrounded_number",
  "msg": "table row 的數字 ['2'] 不在所引 claim ['rt2#1', 'openvla#3', 'pi0#2', 'action-representation#7'] 中"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。