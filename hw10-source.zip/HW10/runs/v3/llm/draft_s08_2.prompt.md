你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s08",
 "kind": "timeline",
 "objective": "O5",
 "title": "從 RT‑1 到 π0 的演進路線",
 "claims": [
  "vla-timeline#1",
  "vla-timeline#2",
  "vla-timeline#5",
  "vla-timeline#6"
 ],
 "introduces": [],
 "purpose": "讓觀眾了解主要模型的時間線與技術突破"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[vla-timeline]] ===
[vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |
[vla-timeline#2] (fact) 2023 | [[rt2]] | 把 VLM 變成 VLA，動作寫成文字 token，co-fine-tune  |
[vla-timeline#5] (fact) 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5%  |
[vla-timeline#6] (fact) 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服  |

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['DoF', 'VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s08",
 "kind": "timeline",
 "objective": "O5",
 "title": "從 RT‑1 到 π0 的演進路線",
 "timeline": [
  {
   "year": "2022",
   "name": "RT‑1",
   "text": "35M Transformer，使用 130k 示範，將動作離散成 token",
   "cite": [
    "vla-timeline#1"
   ]
  },
  {
   "year": "2023",
   "name": "RT‑2",
   "text": "將 VLM 轉為 VLA，動作以文字 token 表示，進行 co‑fine‑tune",
   "cite": [
    "vla-timeline#2"
   ]
  },
  {
   "year": "2024",
   "name": "OpenVLA",
   "text": "7B 開源 VLA，於基準測試中以 16.5% 勝過 55B RT‑2‑X",
   "cite": [
    "vla-timeline#5"
   ]
  },
  {
   "year": "2024",
   "name": "π0",
   "text": "3.3B 模型，採用 flow matching，實現 50 Hz 折衣服操作",
   "cite": [
    "vla-timeline#6"
   ]
  }
 ],
 "bullets": [
  {
   "text": "RT‑1 用小型 Transformer 直接學習離散動作 token，展示了端到端的可能性",
   "cite": [
    "vla-timeline#1"
   ],
   "type": "fact"
  },
  {
   "text": "RT‑2 透過文字化動作，使 VLM 能同時理解視覺、語言與行動，提升跨模態學習",
   "cite": [
    "vla-timeline#2"
   ],
   "type": "fact"
  },
  {
   "text": "OpenVLA 以 7B 參數開源，證明較大模型不一定需要更高參數才能超越",
   "cite": [
    "vla-timeline#5"
   ],
   "type": "fact"
  },
  {
   "text": "π0 引入 flow matching，提升控制頻率至 50 Hz，實現更流暢的折衣服任務",
   "cite": [
    "vla-timeline#6"
   ],
   "type": "fact"
  },
  {
   "text": "從 2022 到 2024，模型規模與技術迭代快速，展示了 VLA 領域的高速進步",
   "cite": [
    "vla-timeline#1",
    "vla-timeline#2",
    "vla-timeline#5",
    "vla-timeline#6"
   ],
   "type": "inference"
  }
 ],
 "defines": [],
 "note": "提醒觀眾注意：雖然模型大小不同，但關鍵在於 token 表示與訓練策略的創新"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s08",
  "type": "ungrounded_number",
  "msg": "bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中"
 },
 {
  "slide": "s08",
  "type": "ungrounded_number",
  "msg": "bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中"
 },
 {
  "slide": "s08",
  "type": "ungrounded_number",
  "msg": "timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中"
 },
 {
  "slide": "s08",
  "type": "undefined_term",
  "msg": "術語「flow matching」在這頁第一次出現，必須放進 defines"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"timeline","objective","title","timeline":[{"year","name","text","cite":["claim id"]}],"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。