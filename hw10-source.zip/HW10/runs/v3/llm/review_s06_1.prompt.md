你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：Action Chunking：為何需要一次預測多步
bullet 1 [fact] 模型一次輸出未來好幾步的動作（action chunk）  (cite: action-chunking#1)
bullet 2 [fact] 一次輸出 H=50 步的 action chunk，使控制頻率可達 50 Hz  (cite: action-chunking#2)
bullet 3 [inference] 減少每秒需要的推論次數，降低計算負擔  (cite: action-chunking#1)
bullet 4 [analogy] 想像一次下達一段指令，就像一次寫好一段程式碼，而不是逐行輸入  (cite: )
流程：概念 — 模型一次輸出未來多步的動作（稱為 action chunk），而非每次只預測一步

證據（claim id → 原文）：
[action-chunking#1] (fact) 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步
[action-chunking#2] (fact) π0 一次輸出 H=50 步，控制頻率可達 50 Hz

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
比喻（標 analogy）不用查證。措辭不同但意思一樣的，不算錯。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。