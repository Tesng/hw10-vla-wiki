你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：動作表示：離散 token vs 連續動作
bullet 1 [fact] RT-1 把 11 個動作維度各離散成 256 個 bin  (cite: action-representation#1)
bullet 2 [fact] Octo 用 diffusion action head 輸出連續動作  (cite: action-representation#6)
bullet 3 [inference] 離散化讓模型可利用語言模型的 token 預測機制，連續化則保留更細緻的控制資訊  (cite: action-representation#1)
bullet 4 [analogy] 就像把溫度量測成整數度數或保留小數點  (cite: )
流程：離散 token — 將每個 DoF 切成固定數量的 bin，產生離散的 token 序列
流程：連續動作 — 直接預測每個 DoF 的實數向量，形成連續的動作表示
名詞解釋 DoF：自由度，指機器人可獨立控制的方向或關節數量
名詞解釋 action chunk：將一段連續動作切成固定長度的子序列，供模型一次處理
名詞解釋 diffusion：一種生成模型技術，透過逐步去噪產生連續動作向量

證據（claim id → 原文）：
[action-representation#1] (fact) RT-1 把 11 個動作維度各離散成 256 個 bin
[action-representation#6] (fact) Octo 用 diffusion action head 輸出連續動作

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
比喻（標 analogy）不用查證。措辭不同但意思一樣的，不算錯。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。