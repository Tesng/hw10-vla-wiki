你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：從 RT‑1 到 π0 的演進路線
bullet 1 [fact] RT‑1 使用 35M 參數的 Transformer，透過 130k 示範將動作離散為 token  (cite: vla-timeline#1)
bullet 2 [fact] RT‑2 把 VLM 轉為 VLA，將動作寫成文字 token，並進行 co‑fine‑tune  (cite: vla-timeline#2)
bullet 3 [fact] OpenVLA 為 7B 開源 VLA，在基準測試中以 16.5% 勝過 55B RT‑2‑X  (cite: vla-timeline#5)
bullet 4 [fact] π0 採用 flow matching，使控制頻率提升至 50 Hz，成功執行折衣服任務  (cite: vla-timeline#6)
bullet 5 [inference] 從 2022 到 2024，模型規模與技術快速迭代，展現 VLA 領域的高速進步  (cite: vla-timeline#1, vla-timeline#2, vla-timeline#5, vla-timeline#6)
timeline 2022 RT‑1：35M Transformer，使用 130k 示範，將動作離散成 token  (cite: vla-timeline#1)
timeline 2023 RT‑2：把 VLM 變成 VLA，動作寫成文字 token，co‑fine‑tune  (cite: vla-timeline#2)
timeline 2024 OpenVLA：7B 開源 VLA，於基準測試中以 16.5% 勝過 55B RT‑2‑X  (cite: vla-timeline#5)
timeline 2024 π0：3.3B 模型，採用 flow matching，實現 50 Hz 折衣服操作  (cite: vla-timeline#6)
名詞解釋 flow matching：對齊預測與目標動作分布的技術，可提升控制頻率與平滑度

證據（claim id → 原文）：
[vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |
[vla-timeline#2] (fact) 2023 | [[rt2]] | 把 VLM 變成 VLA，動作寫成文字 token，co-fine-tune  |
[vla-timeline#5] (fact) 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5%  |
[vla-timeline#6] (fact) 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服  |

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
比喻（標 analogy）不用查證。措辭不同但意思一樣的，不算錯。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。