你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：FAST：離散路徑的再度崛起
bullet 1 [fact] 以往 VLA 每步每維切 256 個 bin，控制頻率高時相鄰 token 幾乎相同。  (cite: fast#1)
bullet 2 [fact] FAST 用 DCT+ BPE 把 1 秒 50 Hz 動作的 700 個 token 壓縮至 53 個，提升 13.2 倍。  (cite: fast#3)
bullet 3 [fact] π0‑FAST（自回歸、離散 token）在摺衣服等任務上追平 diffusion 版 π0，訓練時間最多減少 5 倍。  (cite: fast#5)
bullet 4 [inference] 離散 token 若能有效壓縮，仍可保持與連續 diffusion 相同表現。  (cite: fast#5)
bullet 5 [analogy] 就像把長篇文字壓縮成短句，保留關鍵資訊卻大幅減少字數。  (cite: )

證據（claim id → 原文）：
[fast#1] (fact) 問題：以往 VLA 每個時間步、每個維度各切 256 個 bin；控制頻率一高，相鄰 token 幾乎一樣，模型學到「照抄前一個」就能讓 loss 很低
[fast#3] (fact) 壓縮效果：50 Hz 摺 T 恤的 1 秒動作，原本 700 個 token，FAST 只要 53 個（13.2 倍）
[fast#5] (fact) π0-FAST（自回歸、離散 token）在摺衣服等任務上追平用 diffusion 的 π0，訓練時間最多少 5 倍

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
比喻（標 analogy）不用查證。措辭不同但意思一樣的，不算錯。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。