你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s06",
 "kind": "flow",
 "objective": "O4",
 "title": "Action Chunking：為何需要一次預測多步",
 "claims": [
  "action-chunking#1",
  "action-chunking#2"
 ],
 "introduces": [
  "action chunk"
 ],
 "purpose": "解釋一次輸出多步動作的概念與對控制頻率的影響"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-chunking]] ===
[action-chunking#1] (fact) 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步
[action-chunking#2] (fact) π0 一次輸出 H=50 步，控制頻率可達 50 Hz

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['DoF', 'VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

輸出這一頁的 JSON，欄位：{"id","kind":"flow","objective","title","flow":[{"label","text"}],"bullets":[...同 content],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。