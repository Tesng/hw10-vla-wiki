你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s10",
 "kind": "content",
 "objective": "O5",
 "title": "FAST：離散路徑的再度崛起",
 "claims": [
  "fast#1",
  "fast#3",
  "fast#5"
 ],
 "introduces": [],
 "purpose": "說明 FAST 如何透過 DCT + BPE 壓縮提升離散 token 的效能，並解釋與 π0 的衝突"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[fast]] ===
[fast#1] (fact) 問題：以往 VLA 每個時間步、每個維度各切 256 個 bin；控制頻率一高，相鄰 token 幾乎一樣，模型學到「照抄前一個」就能讓 loss 很低
[fast#3] (fact) 壓縮效果：50 Hz 摺 T 恤的 1 秒動作，原本 700 個 token，FAST 只要 53 個（13.2 倍）
[fast#5] (fact) π0-FAST（自回歸、離散 token）在摺衣服等任務上追平用 diffusion 的 π0，訓練時間最多少 5 倍

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['DoF', 'VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'diffusion', 'embodiment', 'flow matching', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s10",
 "kind": "content",
 "objective": "O5",
 "title": "FAST：離散路徑的再度崛起",
 "bullets": [
  {
   "text": "以往 VLA 每步每維切 256 個 bin，控制頻率高時相鄰 token 幾乎相同。",
   "cite": [
    "fast#1"
   ],
   "type": "fact"
  },
  {
   "text": "FAST 用 DCT+ BPE 把 1 秒 50 Hz 動作的 700 個 token 壓縮至 53 個，提升 13.2 倍。",
   "cite": [
    "fast#3"
   ],
   "type": "fact"
  },
  {
   "text": "π0‑FAST（自回歸、離散 token）在摺衣服等任務上追平 diffusion 版 π0，訓練時間最多減少 5 倍。",
   "cite": [
    "fast#5"
   ],
   "type": "fact"
  },
  {
   "text": "此結果顯示離散 token 在高頻控制下仍能保持與 diffusion 相近表現。",
   "cite": [
    "fast#5"
   ],
   "type": "inference"
  },
  {
   "text": "就像把長篇文字壓縮成短句，保留關鍵資訊卻大幅減少字數。",
   "type": "analogy"
  }
 ],
 "defines": [],
 "note": "提醒觀眾 FAST 壓縮提升效能與訓練成本下降，並說明與 π0 的衝突。"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s10",
  "type": "too_long",
  "msg": "bullet 2 有 63 字，上限 60"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"content","objective","title","bullets":[{"text","cite":["claim id"],"type":"fact|inference|analogy"}],"defines":[{"term","def"}],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。