你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s08",
 "kind": "timeline",
 "objective": "O5",
 "title": "從 RT‑1 到 π0 的演進路線",
 "claims": [
  "vla-timeline#1",
  "vla-timeline#2",
  "vla-timeline#5",
  "vla-timeline#6"
 ],
 "introduces": [],
 "purpose": "讓觀眾了解主要模型的時間線與技術突破"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[vla-timeline]] ===
[vla-timeline#1] (fact) 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token  |
[vla-timeline#2] (fact) 2023 | [[rt2]] | 把 VLM 變成 VLA，動作寫成文字 token，co-fine-tune  |
[vla-timeline#5] (fact) 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5%  |
[vla-timeline#6] (fact) 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服  |

這頁必須在 defines 解釋的術語：無
之前投影片已解釋過、不必再解釋的術語：['DoF', 'VLA', 'VLM', 'action chunk', 'co-fine-tuning', 'embodiment', 'policy', '控制頻率', '正遷移']

你上一版的這頁：
{
 "id": "s08",
 "kind": "timeline",
 "objective": "O5",
 "title": "從 RT‑1 到 π0 的演進路線",
 "timeline": [
  {
   "year": "2022",
   "name": "RT‑1",
   "text": "35M Transformer，130k 示範，動作離散為 token",
   "cite": [
    "vla-timeline#1"
   ]
  },
  {
   "year": "2023",
   "name": "RT‑2",
   "text": "把 VLM 變成 VLA，動作寫成文字 token，co‑fine‑tune",
   "cite": [
    "vla-timeline#2"
   ]
  },
  {
   "year": "2024",
   "name": "OpenVLA",
   "text": "7B 開源 VLA，贏 55B RT‑2‑X 16.5%",
   "cite": [
    "vla-timeline#5"
   ]
  },
  {
   "year": "2024",
   "name": "π0",
   "text": "3.3B，採用 flow matching，控制頻率 50 Hz 折衣服",
   "cite": [
    "vla-timeline#6"
   ]
  }
 ],
 "bullets": [
  {
   "text": "RT‑1：35M Transformer，130k 示範，動作離散為 token",
   "cite": [
    "vla-timeline#1"
   ],
   "type": "fact"
  },
  {
   "text": "RT‑2：將 VLM 轉為 VLA，動作文字 token，co‑fine‑tune",
   "cite": [
    "vla-timeline#2"
   ],
   "type": "fact"
  },
  {
   "text": "OpenVLA：7B 開源 VLA，基準測試勝 55B RT‑2‑X 16.5%",
   "cite": [
    "vla-timeline#5"
   ],
   "type": "fact"
  },
  {
   "text": "π0：3.3B，使用 flow matching，控制頻率 50 Hz 折衣服",
   "cite": [
    "vla-timeline#6"
   ],
   "type": "fact"
  },
  {
   "text": "2022‑2024 模型規模與技術快速迭代，展示 VLA 高速進步",
   "cite": [
    "vla-timeline#1",
    "vla-timeline#2",
    "vla-timeline#5",
    "vla-timeline#6"
   ],
   "type": "inference"
  }
 ],
 "defines": [
  {
   "term": "flow matching",
   "def": "對齊預測與目標動作分布的技術，提升控制頻率與平滑度"
  }
 ],
 "note": "提醒觀眾注意模型大小差異與 token 表示的創新"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s08",
  "type": "ungrounded_number",
  "msg": "bullet 1 的數字 ['1'] 不在所引 claim ['vla-timeline#1'] 中"
 },
 {
  "slide": "s08",
  "type": "ungrounded_number",
  "msg": "bullet 2 的數字 ['2'] 不在所引 claim ['vla-timeline#2'] 中"
 },
 {
  "slide": "s08",
  "type": "ungrounded_number",
  "msg": "bullet 3 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中"
 },
 {
  "slide": "s08",
  "type": "ungrounded_number",
  "msg": "timeline OpenVLA 的數字 ['2'] 不在所引 claim ['vla-timeline#5'] 中"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"timeline","objective","title","timeline":[{"year","name","text","cite":["claim id"]}],"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。