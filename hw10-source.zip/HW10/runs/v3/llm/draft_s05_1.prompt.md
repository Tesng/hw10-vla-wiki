你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s05",
 "kind": "content",
 "objective": "O3",
 "title": "資料來源：跨機體資料與 co‑fine‑tuning",
 "claims": [
  "cross-embodiment#2",
  "co-fine-tuning#1"
 ],
 "introduces": [
  "embodiment",
  "co-fine-tuning",
  "正遷移"
 ],
 "purpose": "說明 VLA 訓練資料的多樣性與同時使用機器人軌跡與網路圖文的做法"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[co-fine-tuning]] ===
[co-fine-tuning#1] (fact) 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）

=== [[cross-embodiment]] ===
[cross-embodiment#2] (fact) Open X-Embodiment 匯集 22 種機器人、527 種技能的資料

這頁必須在 defines 解釋的術語：['co-fine-tuning', 'embodiment', '正遷移']
之前投影片已解釋過、不必再解釋的術語：['DoF', 'VLA', 'VLM', 'action chunk', 'policy', '控制頻率']

輸出這一頁的 JSON，欄位：{"id","kind":"content","objective","title","bullets":[{"text","cite":["claim id"],"type":"fact|inference|analogy"}],"defines":[{"term","def"}],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。