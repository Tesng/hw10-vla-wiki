你是獨立的事實查核員。下面是一頁教學投影片，以及它引用的證據原文。
請逐句檢查投影片內容是否「忠於證據」。

投影片：
標題：資料來源：跨機體資料與 co‑fine‑tuning
bullet 1 [fact] Open X-Embodiment 收錄 22 種機器人、527 種技能的軌跡資料  (cite: cross-embodiment#2)
bullet 2 [fact] co‑fine‑tuning 同時使用機器人軌跡與大規模視覺‑語言資料（如 VQA）微調 VLM  (cite: co-fine-tuning#1)
bullet 3 [inference] 結合跨機體軌跡與網路圖文，使模型學到跨機體的正遷移能力  (cite: cross-embodiment#2, co-fine-tuning#1)
bullet 4 [analogy] 就像在烹飪時加入不同產地的食材，能讓菜餚味道更豐富  (cite: )
名詞解釋 co-fine-tuning：在微調視覺語言模型時，同時加入機器人軌跡資料與大規模視覺語言資料的訓練方式
名詞解釋 embodiment：機器人的具體形態與硬體配置，決定其可執行的動作與感測能力
名詞解釋 正遷移：模型在新環境或新機體上仍能保持或提升效能的正向遷移現象

證據（claim id → 原文）：
[co-fine-tuning#1] (fact) 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）
[cross-embodiment#2] (fact) Open X-Embodiment 匯集 22 種機器人、527 種技能的資料

找出這些問題：
- reversed：說法和證據相反
- unsupported：證據沒有支持（包括多加了證據沒有的細節、誇大、把推論說成定論）
- wrong_attribution：把 A 模型/論文的事實套到 B
- misleading：雖然有出處，但會讓初學者誤解
比喻（標 analogy）不用查證。措辭不同但意思一樣的，不算錯。

輸出 JSON：{"verdict":"pass|fail","issues":[{"where":"bullet 2 / table row / quiz ...","type":"reversed|unsupported|wrong_attribution|misleading","problem":"哪裡錯","fix":"建議怎麼改"}]}
沒有問題就輸出 {"verdict":"pass","issues":[]}。