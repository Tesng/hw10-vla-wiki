你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s03",
 "kind": "flow",
 "objective": "O2",
 "title": "動作表示：離散 token vs 連續動作",
 "claims": [
  "action-representation#1",
  "action-representation#6"
 ],
 "introduces": [
  "DoF",
  "action chunk"
 ],
 "purpose": "說明動作如何被編碼為離散 token 或連續向量，並引出後續的 chunk 概念"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#1] (fact) RT-1 把 11 個動作維度各離散成 256 個 bin
[action-representation#6] (fact) Octo 用 diffusion action head 輸出連續動作

這頁必須在 defines 解釋的術語：['DoF', 'action chunk']
之前投影片已解釋過、不必再解釋的術語：['VLA', 'VLM', 'policy']

你上一版的這頁：
{
 "id": "s03",
 "kind": "flow",
 "objective": "O2",
 "title": "動作表示：離散 token vs 連續動作",
 "flow": [
  {
   "label": "離散 token",
   "text": "將每個 DoF 切成固定數量的 bin，產生離散的 token 序列"
  },
  {
   "label": "連續動作",
   "text": "直接預測每個 DoF 的實數向量，形成連續的動作表示"
  }
 ],
 "bullets": [
  {
   "text": "RT-1 把 11 個動作維度各離散成 256 個 bin",
   "cite": [
    "action-representation#1"
   ],
   "type": "fact"
  },
  {
   "text": "Octo 用 diffusion action head 輸出連續動作",
   "cite": [
    "action-representation#6"
   ],
   "type": "fact"
  },
  {
   "text": "離散化讓模型可利用語言模型的 token 預測機制，連續化則保留更細緻的控制資訊",
   "type": "inference"
  },
  {
   "text": "就像把溫度量測成整數度數或保留小數點",
   "type": "analogy"
  }
 ],
 "defines": [
  {
   "term": "DoF",
   "def": "自由度，指機器人可獨立控制的方向或關節數量"
  },
  {
   "term": "action chunk",
   "def": "將一段連續動作切成固定長度的子序列，供模型一次處理"
  }
 ],
 "note": "先問觀眾：文字是 token，動作也能被 token 化嗎？再引出後續的 chunk 概念"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s03",
  "type": "uncited",
  "msg": "bullet 3 沒有引用 claim"
 },
 {
  "slide": "s03",
  "type": "undefined_term",
  "msg": "術語「diffusion」在這頁第一次出現，必須放進 defines"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"flow","objective","title","flow":[{"label","text"}],"bullets":[...同 content],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。