你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "claims": [
  "action-representation#8",
  "action-representation#10"
 ],
 "introduces": [
  "控制頻率"
 ],
 "purpose": "比較離散 token 與連續輸出在高頻控制下的優缺點"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：

=== [[action-representation]] ===
[action-representation#8] (fact) 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服
[action-representation#10] (fact) FAST 先做 DCT 再用 BPE 壓縮，50 Hz 的 1 秒動作從 700 個 token 降到 53 個

這頁必須在 defines 解釋的術語：['控制頻率']
之前投影片已解釋過、不必再解釋的術語：['DoF', 'VLA', 'VLM', 'action chunk', 'policy']

你上一版的這頁：
{
 "id": "s04",
 "kind": "compare",
 "objective": "O2",
 "title": "離散 vs 連續：效能與頻率比較",
 "table": {
  "columns": [
   "方式",
   "易接VLM",
   "高頻適合度",
   "token 數"
  ],
  "rows": [
   [
    "離散 token",
    "最容易接上 VLM",
    "較不適合高頻控制",
    "700 (1 秒,50 Hz)"
   ],
   [
    "連續輸出",
    "較難直接接 VLM",
    "適合高頻、靈巧動作",
    "53 (1 秒,50 Hz)"
   ]
  ],
  "cite": [
   "action-representation#8",
   "action-representation#10"
  ]
 },
 "bullets": [
  {
   "text": "離散 token 直接映射到文字模型，整合簡單",
   "cite": [
    "action-representation#8"
   ],
   "type": "fact"
  },
  {
   "text": "連續輸出在 50 Hz 以上能保持平滑動作",
   "cite": [
    "action-representation#8"
   ],
   "type": "fact"
  },
  {
   "text": "FAST 先做 DCT 再 BPE，將 700 token 壓到 53，顯著減少帶寬",
   "cite": [
    "action-representation#10"
   ],
   "type": "fact"
  },
  {
   "text": "高頻控制需要更低的延遲與更小的資料量",
   "cite": [
    "action-representation#8"
   ],
   "type": "inference"
  },
  {
   "text": "就像音訊壓縮，保留關鍵頻率成分",
   "type": "analogy"
  }
 ],
 "defines": [
  {
   "term": "控制頻率",
   "def": "機器人每秒執行指令的次數，頻率越高回應越即時"
  }
 ],
 "note": "比較時提醒觀眾：離散易於語言結合，連續在實際控制上更有效"
}

這頁沒有通過檢查，只修正以下問題：
[
 {
  "slide": "s04",
  "type": "ai_review_unsupported",
  "msg": "bullet 2：證據未提及連續輸出在 50 Hz 以上能保持平滑動作，僅說明其更適合高頻、靈巧動作。；建議：改為『連續輸出更適合高頻、靈巧動作，例如 50 Hz 摺衣服』或引用相關證據。"
 },
 {
  "slide": "s04",
  "type": "ai_review_unsupported",
  "msg": "bullet 4：證據未提及高頻控制需要更低延遲與更小資料量，僅說明連續輸出更適合高頻動作。；建議：改為『高頻控制更適合連續輸出，因其能以 50 Hz 進行靈巧動作』或加入支持延遲與資料量的證據。"
 }
]

輸出這一頁的 JSON，欄位：{"id","kind":"compare","objective","title","table":{"columns":[...],"rows":[[...]],"cite":["claim id"]},"bullets":[...],"defines":[...],"note"}
格式範例（content 頁；注意 bullets 和 defines 的每一項都是「物件」，claim id 只放在 cite 陣列裡，text 裡不要寫引用）：
{"id": "s05", "kind": "content", "objective": "O2", "title": "動作怎麼變成 token？", "bullets": [{"text": "每個動作維度切成 256 個 bin，變成整數 token", "cite": ["rt2#3"], "type": "fact"}, {"text": "高頻時相鄰 token 幾乎一樣，模型容易照抄", "cite": ["fast#1"], "type": "fact"}, {"text": "差別可能在 token 化方式，而非離散或連續本身", "cite": ["action-representation#12"], "type": "inference"}, {"text": "就像把連續的溫度四捨五入成刻度", "type": "analogy"}], "defines": [{"term": "DoF", "def": "自由度：可以獨立控制的方向數"}], "note": "先問觀眾：文字是 token，那動作呢？"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。