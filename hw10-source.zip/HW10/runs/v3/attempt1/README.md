# v3 第 1 次執行（attempt1）：在 draft_pages 當掉

- 時間：2026-11-15；writer = openai/gpt-oss-120b，reviewer = openai/gpt-oss-20b（Groq）
- 大綱一次通過程式檢查，人工確認通過（約 15 分鐘）
- 寫到 s04 時，模型把 bullets 和 defines 輸出成「字串」而不是物件；當時的 check_slide 假設格式正確，直接 `b.get()` → **AttributeError，整個 graph 當掉**
- 當時 draft_pages 沒有逐頁 checkpoint，s01–s03 的事件紀錄只在記憶體裡，沒有存下來；下表是事後用修正後的檢查器重跑每一份回覆得到的結果

| 呼叫 | 檢查結果（用修正後的 check_slide 重跑） |
|---|---|
| draft_s01_1 | ✔ 通過 |
| draft_s02_1 | ✔ 通過 |
| draft_s03_1 | schema：bullets 第 1 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]<br>schema：bullets 第 2 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]<br>schema：bullets 第 3 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]<br>schema：bullets 第 5 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id] |
| draft_s03_2 | schema：bullets 第 1 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]<br>schema：bullets 第 2 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]<br>schema：bullets 第 3 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]<br>schema：bullets 第 5 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id] |
| draft_s03_3 | schema：bullets 第 1 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]<br>schema：bullets 第 2 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]<br>schema：bullets 第 3 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id]<br>schema：bullets 第 5 項把引用寫在 text 裡；claim id 只能放在 cite 陣列，text 不要出現 cite 或 [id] |
| draft_s04_1 | schema：bullets 第 1 項必須是物件 {"text": "...", "cite": ["claim id"], "type": "fact|inference|analogy"}，不能是字串<br>schema：bullets 第 2 項必須是物件 {"text": "...", "cite": ["claim id"], "type": "fact|inference|analogy"}，不能是字串<br>schema：bullets 第 3 項必須是物件 {"text": "...", "cite": ["claim id"], "type": "fact|inference|analogy"}，不能是字串<br>schema：bullets 第 4 項必須是物件 {"text": "...", "cite": ["claim id"], "type": "fact|inference|analogy"}，不能是字串<br>schema：bullets 第 5 項必須是物件 {"text": "...", "cite": ["claim id"], "type": "fact|inference|analogy"}，不能是字串<br>schema：defines 第 1 項必須是物件 {"term": "術語", "def": "白話解釋"} |

LLM 呼叫紀錄（calls.jsonl）：

- `{"key": "outline_1", "role": "writer", "model": "openai/gpt-oss-120b", "attempt": 1, "prompt_tokens": 4847, "completion_tokens": 1351, "sec": 3.5}`
- `{"key": "draft_s01_1", "role": "writer", "model": "openai/gpt-oss-120b", "attempt": 1, "prompt_tokens": 529, "completion_tokens": 344, "sec": 1.2}`
- `{"key": "draft_s02_1", "role": "writer", "model": "openai/gpt-oss-120b", "attempt": 1, "prompt_tokens": 660, "completion_tokens": 214, "sec": 1.0}`
- `{"key": "draft_s03_1", "event": "json_mode_unsupported_retry"}`
- `{"key": "draft_s03_1", "role": "writer", "model": "openai/gpt-oss-120b", "attempt": 2, "prompt_tokens": 611, "completion_tokens": 667, "sec": 1.9}`
- `{"key": "draft_s03_2", "role": "writer", "model": "openai/gpt-oss-120b", "attempt": 1, "prompt_tokens": 1464, "completion_tokens": 722, "sec": 2.0}`
- `{"key": "draft_s03_3", "role": "writer", "model": "openai/gpt-oss-120b", "attempt": 1, "prompt_tokens": 1480, "completion_tokens": 682, "sec": 2.0}`
- `{"key": "draft_s04_1", "event": "rate_limited", "wait": 3.0}`
- `{"key": "draft_s04_1", "role": "writer", "model": "openai/gpt-oss-120b", "attempt": 2, "prompt_tokens": 678, "completion_tokens": 527, "sec": 1.5}`
