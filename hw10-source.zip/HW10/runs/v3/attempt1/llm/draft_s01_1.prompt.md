你在寫教學簡報「VLA（Vision-Language-Action）模型是什麼？」中的其中一頁。觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
這頁的大綱：
{
 "id": "s01",
 "kind": "title",
 "objective": null,
 "title": "Vision‑Language‑Action (VLA) 模型概覽",
 "claims": [],
 "introduces": [
  "VLA",
  "VLM",
  "policy"
 ],
 "purpose": "說明本次簡報主題與大綱"
}

這頁可以用的證據卡（只能用這些，不可加入卡片以外的知識）：


這頁必須在 defines 解釋的術語：['VLA', 'VLM', 'policy']
之前投影片已解釋過、不必再解釋的術語：無

輸出這一頁的 JSON，格式：{"id","kind":"title","title","subtitle","defines":[{"term","def"}],"note"}
規則：
1. 每個 fact/inference bullet、表格、時間線項目、quiz 解說都要在 cite 放 claim id（完全照抄）。
2. 數字只能使用所引 claim 裡出現過的數字，不要換算或改寫（例如不要把「少 7 倍」寫成「1/7」）。
3. 引用 (inference) claim 的句子 type 必須是 inference；自己的比喻 type=analogy，不需 cite、不可含數字。
4. 最多 5 個 bullet，每個 ≤60 字；defines 的 def 用一句白話。
5. note 是講者備註，可寫教學提示。id、kind、objective 照大綱。繁體中文，術語保留英文。