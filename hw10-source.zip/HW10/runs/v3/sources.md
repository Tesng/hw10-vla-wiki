# 檢索結果

- **O1** 說出 VLA 的定義，以及它和 LLM / VLM 的關係：[[vla]], [[rt2]], [[vla-timeline]], [[action-representation]]
- **O2** 理解動作怎麼變成模型輸出：離散 token vs 連續動作：[[action-representation]], [[fast]], [[vla-timeline]], [[continuous-action-heads]]
- **O3** 知道 VLA 的資料從哪來：跨機體資料與 co-fine-tuning：[[cross-embodiment]], [[co-fine-tuning]], [[oxe]], [[rt2]]
- **O4** 理解為什麼需要 action chunking 才能高頻控制：[[action-chunking]], [[pi0]], [[action-representation]], [[fast]]
- **O5** 能比較 RT-1 → π0 的演進與代表模型：[[action-representation]], [[octo]], [[vla-timeline]], [[openvla]]

共 13 頁、90 條 claim（推論 9 條）
