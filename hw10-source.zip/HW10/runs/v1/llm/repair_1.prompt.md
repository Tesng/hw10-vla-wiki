下列投影片沒有通過自動檢查。請只修正有問題的地方，其餘保持不變，輸出完整的 {"slides":[...]}。
檢查錯誤：
[
 {
  "slide": "s01",
  "type": "undefined_term",
  "msg": "術語「VLA」第一次出現但沒有在 defines 解釋"
 }
]

目前投影片：
[
 {
  "id": "s01",
  "kind": "title",
  "objective": null,
  "title": "VLA 是什麼？讓大模型學會動手",
  "subtitle": "Vision-Language-Action 模型入門 · 從 RT-2 到 π0",
  "note": "今天的目標：懂 VLA 的定義、動作怎麼輸出、資料從哪來、為什麼要 action chunking。"
 },
 {
  "id": "s02",
  "kind": "flow",
  "objective": "O1",
  "title": "從 LLM → VLM → VLA",
  "flow": [
   {
    "label": "LLM",
    "text": "文字進、文字出"
   },
   {
    "label": "VLM",
    "text": "影像 + 文字進、文字出"
   },
   {
    "label": "VLA",
    "text": "影像 + 指令進、機器人動作出"
   }
  ],
  "bullets": [
   {
    "text": "VLA 是把 VLM 微調成直接輸出機器人動作的模型",
    "cite": [
     "vla"
    ],
    "type": "fact"
   },
   {
    "text": "輸入相機影像與自然語言指令，輸出下一步動作",
    "cite": [
     "vla"
    ],
    "type": "fact"
   },
   {
    "text": "就像讓一個很會看圖說話的人，改成看圖動手",
    "type": "analogy"
   }
  ],
  "defines": [
   {
    "term": "VLM",
    "def": "Vision-Language Model，看圖也讀文字的大模型，例如 PaLI-X、PaliGemma"
   },
   {
    "term": "VLA",
    "def": "Vision-Language-Action，在 VLM 上多學一種輸出：機器人動作"
   }
  ],
  "note": "先用 LLM 當錨點，觀眾都熟。"
 },
 {
  "id": "s03",
  "kind": "content",
  "objective": "O1",
  "title": "為什麼要借用 VLM？",
  "bullets": [
   {
    "text": "VLM 從網路圖文學到常識，可以轉移給機器人",
    "cite": [
     "vla"
    ],
    "type": "fact"
   },
   {
    "text": "RT-2 能聽懂機器人資料裡沒有的指令，例如把東西放到某個數字上",
    "cite": [
     "rt2"
    ],
    "type": "fact"
   },
   {
    "text": "還會簡單推理：挑最小的物體、拿石頭當鐵鎚",
    "cite": [
     "rt2"
    ],
    "type": "fact"
   },
   {
    "text": "未見情境成功率 62，舊 policy RT-1 只有 32，約 2 倍",
    "cite": [
     "rt2"
    ],
    "type": "fact"
   },
   {
    "text": "但限制是：網路資料不會教機器人新動作",
    "cite": [
     "rt2"
    ],
    "type": "fact"
   }
  ],
  "defines": [
   {
    "term": "policy",
    "def": "機器人的「決策函式」：看到當下狀態，決定要做什麼動作"
   }
  ],
  "note": "強調：知識會轉移，但動作技能還是要靠機器人資料。"
 },
 {
  "id": "s04",
  "kind": "content",
  "objective": "O2",
  "title": "動作怎麼變成 token？",
  "bullets": [
   {
    "text": "RT-2 的動作：6-DoF 末端位移/旋轉 + 夾爪 + 終止",
    "cite": [
     "rt2"
    ],
    "type": "fact"
   },
   {
    "text": "每個連續維度切成 256 個 bin，一個動作變 8 個整數",
    "cite": [
     "rt2",
     "action-representation"
    ],
    "type": "fact"
   },
   {
    "text": "把整數寫成 token，就能用語言模型的 next-token 預測來訓練",
    "cite": [
     "action-representation"
    ],
    "type": "fact"
   },
   {
    "text": "OpenVLA 覆寫 Llama tokenizer 最少用的 256 個 token 放動作",
    "cite": [
     "openvla"
    ],
    "type": "fact"
   },
   {
    "text": "bin 範圍取第 1 到第 99 百分位，避免極端值",
    "cite": [
     "openvla"
    ],
    "type": "fact"
   }
  ],
  "defines": [
   {
    "term": "DoF",
    "def": "Degree of Freedom 自由度；6-DoF = 3 個位移 + 3 個旋轉"
   }
  ],
  "note": "類比：把連續溫度四捨五入成整數刻度，再當成單字來預測。"
 },
 {
  "id": "s05",
  "kind": "content",
  "objective": "O2",
  "title": "另一條路：直接輸出連續動作",
  "bullets": [
   {
    "text": "Octo 用 diffusion action head，經 20 步去噪產生連續動作",
    "cite": [
     "continuous-action-heads"
    ],
    "type": "fact"
   },
   {
    "text": "π0 在 PaliGemma 旁掛 300M 的 action expert，用 flow matching",
    "cite": [
     "continuous-action-heads",
     "pi0"
    ],
    "type": "fact"
   },
   {
    "text": "從雜訊出發一步步修正成動作，能表示「多種合理做法」",
    "cite": [
     "continuous-action-heads"
    ],
    "type": "fact"
   },
   {
    "text": "像雕刻：從一塊亂石慢慢修成想要的形狀",
    "type": "analogy"
   }
  ],
  "defines": [
   {
    "term": "diffusion",
    "def": "從隨機雜訊開始、反覆去噪生成資料的方法（影像生成常用）"
   },
   {
    "term": "flow matching",
    "def": "學一個把雜訊「流」到資料的速度場，概念類似 diffusion 但更直接"
   }
  ],
  "note": "不需講數學，只講直覺。"
 },
 {
  "id": "s06",
  "kind": "quiz",
  "objective": "O2",
  "title": "小測驗：動作表示",
  "quiz": {
   "q": "下列哪個模型「不」把動作離散成 token？",
   "options": [
    "RT-2",
    "OpenVLA",
    "π0",
    "RT-1"
   ],
   "answer": 2,
   "explain": "π0 用 flow matching 的 action expert 直接輸出連續動作，不做離散化",
   "cite": [
    "action-representation",
    "pi0"
   ]
  }
 },
 {
  "id": "s07",
  "kind": "content",
  "objective": "O3",
  "title": "資料從哪來？跨機體學習",
  "bullets": [
   {
    "text": "Open X-Embodiment：21 個機構、22 種機器人、527 種技能",
    "cite": [
     "oxe"
    ],
    "type": "fact"
   },
   {
    "text": "RT-X 用多種機器人資料訓練，各台機器人都變強",
    "cite": [
     "oxe",
     "cross-embodiment"
    ],
    "type": "fact"
   },
   {
    "text": "Octo 挑 800k、OpenVLA 挑 970k 條軌跡來預訓練",
    "cite": [
     "cross-embodiment"
    ],
    "type": "fact"
   },
   {
    "text": "RT-1 的結論：資料多樣性比資料量更重要",
    "cite": [
     "cross-embodiment"
    ],
    "type": "fact"
   }
  ],
  "defines": [
   {
    "term": "embodiment",
    "def": "機器人的「身體」：手臂型號、感測器、動作空間"
   },
   {
    "term": "正遷移",
    "def": "positive transfer，學 A 的資料反而讓 B 變好"
   }
  ],
  "note": "類比：學過很多種樂器的人，學新樂器更快。"
 },
 {
  "id": "s08",
  "kind": "content",
  "objective": "O3",
  "title": "Co-fine-tuning：別讓 VLM 失憶",
  "bullets": [
   {
    "text": "微調時同時放機器人資料和網路圖文資料（如 VQA）",
    "cite": [
     "co-fine-tuning"
    ],
    "type": "fact"
   },
   {
    "text": "RT-2 中機器人資料約佔 50%（PaLI-X）到 66%（PaLM-E）",
    "cite": [
     "co-fine-tuning"
    ],
    "type": "fact"
   },
   {
    "text": "55B 模型泛化分數：co-fine-tune 63，只用機器人資料 52",
    "cite": [
     "co-fine-tuning"
    ],
    "type": "fact"
   },
   {
    "text": "只餵機器人資料，模型可能忘掉網路常識",
    "cite": [
     "co-fine-tuning"
    ],
    "type": "fact"
   }
  ],
  "defines": [
   {
    "term": "co-fine-tuning",
    "def": "微調時混合新任務資料與原本的預訓練型資料一起訓練"
   }
  ]
 },
 {
  "id": "s09",
  "kind": "content",
  "objective": "O4",
  "title": "大模型太慢？Action chunking",
  "bullets": [
   {
    "text": "RT-2 55B 每步都要跑一次大模型，只有 1-3 Hz",
    "cite": [
     "action-chunking",
     "rt2"
    ],
    "type": "fact"
   },
   {
    "text": "OpenVLA 在一張 RTX 4090 約 6 Hz",
    "cite": [
     "openvla"
    ],
    "type": "fact"
   },
   {
    "text": "π0 一次輸出 50 步動作，控制頻率可達 50 Hz",
    "cite": [
     "action-chunking",
     "pi0"
    ],
    "type": "fact"
   },
   {
    "text": "把「想一次」和「動很多下」分開",
    "cite": [
     "action-chunking"
    ],
    "type": "fact"
   }
  ],
  "defines": [
   {
    "term": "控制頻率",
    "def": "每秒送給馬達幾次指令（Hz）；越高動作越順"
   },
   {
    "term": "action chunk",
    "def": "一次預測的一整段未來動作"
   }
  ]
 },
 {
  "id": "s10",
  "kind": "timeline",
  "objective": "O5",
  "title": "VLA 演進：2022 → 2024",
  "timeline": [
   {
    "year": "2022",
    "name": "RT-1",
    "text": "35M Transformer，130k 示範，動作當 token",
    "cite": [
     "vla-timeline"
    ]
   },
   {
    "year": "2023",
    "name": "RT-2",
    "text": "VLM 變 VLA，co-fine-tune",
    "cite": [
     "vla-timeline"
    ]
   },
   {
    "year": "2023",
    "name": "Open X-Embodiment",
    "text": "22 種機器人資料大集合",
    "cite": [
     "vla-timeline"
    ]
   },
   {
    "year": "2024",
    "name": "Octo",
    "text": "93M 開源通用 policy，diffusion head",
    "cite": [
     "vla-timeline"
    ]
   },
   {
    "year": "2024",
    "name": "OpenVLA",
    "text": "7B 開源，贏 55B RT-2-X 16.5%",
    "cite": [
     "vla-timeline"
    ]
   },
   {
    "year": "2024",
    "name": "π0",
    "text": "3.3B，flow matching，50 Hz 摺衣服",
    "cite": [
     "vla-timeline"
    ]
   }
  ],
  "bullets": [
   {
    "text": "趨勢：封閉大模型 → 開源可微調；離散 token → 連續 chunk",
    "cite": [
     "vla-timeline"
    ],
    "type": "fact"
   }
  ]
 },
 {
  "id": "s11",
  "kind": "compare",
  "objective": "O5",
  "title": "代表模型比一比",
  "table": {
   "columns": [
    "模型",
    "參數",
    "預訓練資料",
    "動作表示",
    "速度"
   ],
   "rows": [
    [
     "RT-2",
     "5B / 55B",
     "機器人 + 網路圖文",
     "離散 token（256 bin）",
     "1-3 Hz（55B）"
    ],
    [
     "Octo",
     "27M / 93M",
     "OXE 800k 軌跡",
     "diffusion 連續 chunk",
     "—"
    ],
    [
     "OpenVLA",
     "7B",
     "OXE 970k 軌跡",
     "離散 token（256 bin）",
     "約 6 Hz"
    ],
    [
     "π0",
     "3.3B",
     "10,000+ 小時",
     "flow matching 連續 chunk",
     "最高 50 Hz"
    ]
   ],
   "cite": [
    "rt2",
    "octo",
    "openvla",
    "pi0"
   ]
  },
  "bullets": [
   {
    "text": "OpenVLA 用 1/7 參數，在 29 個任務贏 RT-2-X 16.5%",
    "cite": [
     "openvla"
    ],
    "type": "fact"
   }
  ]
 },
 {
  "id": "s12",
  "kind": "quiz",
  "objective": "O4",
  "title": "小測驗：為什麼 π0 能做到 50 Hz？",
  "quiz": {
   "q": "π0 能以高頻控制摺衣服，最主要是因為？",
   "options": [
    "模型比 RT-2 大",
    "一次輸出一整段 action chunk",
    "用了更多 GPU",
    "動作離散成 256 bin"
   ],
   "answer": 1,
   "explain": "π0 一次輸出 H=50 步的 action chunk，大模型不用每一步都重新推論",
   "cite": [
    "action-chunking",
    "pi0"
   ]
  }
 },
 {
  "id": "s13",
  "kind": "summary",
  "objective": null,
  "title": "重點回顧",
  "bullets": [
   {
    "text": "VLA = VLM + 動作輸出，借用網路常識",
    "cite": [
     "vla"
    ],
    "type": "fact"
   },
   {
    "text": "動作表示：離散 token（RT-2、OpenVLA）vs 連續（Octo、π0）",
    "cite": [
     "action-representation"
    ],
    "type": "fact"
   },
   {
    "text": "資料：跨機體資料集 + co-fine-tuning",
    "cite": [
     "cross-embodiment",
     "co-fine-tuning"
    ],
    "type": "fact"
   },
   {
    "text": "速度：action chunking 讓大模型也能高頻控制",
    "cite": [
     "action-chunking"
    ],
    "type": "fact"
   },
   {
    "text": "下一步：讀 OpenVLA 程式碼，試著在自己的機器人上 LoRA 微調",
    "type": "analogy"
   }
  ]
 }
]

Wiki context：
=== [[action-chunking]] ===

# Action chunking

- 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步 [[src:octo]]
- π0 一次輸出 H=50 步，控制頻率可達 50 Hz [[src:pi0]]
- 對比：RT-2 55B 每步都要跑一次大模型，只有 1-3 Hz [[src:rt2]]；OpenVLA 在 RTX 4090 約 6 Hz [[src:openvla]]
- 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)
- 相關：[[continuous-action-heads]]


=== [[action-representation]] ===

# 動作表示（Action Representation）

## 路線一：離散 token（把動作當文字）
- RT-1 把 11 個動作維度各離散成 256 個 bin [[src:rt1]]
- RT-2 把每維離散成 256 個 bin，一個動作變成 8 個整數，再寫成文字 token [[src:rt2]]
- 好處是可以直接沿用語言模型的 next-token 預測訓練 VLM [[src:rt2]]
- PaLM-E 和 OpenVLA 都用「覆寫最少用的 256 個 token」來放動作 [[src:rt2]] [[src:openvla]]
- OpenVLA 以第 1 到第 99 百分位決定 bin 範圍，避免極端值 [[src:openvla]]

## 路線二：連續輸出
- Octo 用 diffusion action head 輸出連續動作 [[src:octo]]
- π0 用 flow matching 的 action expert 輸出連續動作，不做離散化 [[src:pi0]]
- 細節見 [[continuous-action-heads]]

## 小結
- 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服 [[src:pi0]]


=== [[co-fine-tuning]] ===

# Co-fine-tuning

- 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）[[src:rt2]]
- RT-2 中機器人資料約佔 PaLI-X 混合資料 50%、PaLM-E 66% [[src:rt2]]
- 效果：55B 模型 co-fine-tune 泛化平均 63，只用機器人資料 fine-tune 為 52 [[src:rt2]]
- 直覺：只餵機器人資料，VLM 會忘掉網路上學到的常識；混著訓練能保留下來 (推論)
- 相關：[[vla]]、[[rt2]]


=== [[continuous-action-heads]] ===

# 連續動作頭：Diffusion 與 Flow Matching

- Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk [[src:octo]]
- π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作 [[src:pi0]]
- 共同直覺：從雜訊出發，一步步「修正」成合理的動作軌跡，能表示多峰（同一情境有多種合理做法）的動作分佈 (推論)
- 對照組：OpenVLA fine-tune 後比 Diffusion Policy 高 20.4%，顯示離散 token 路線在其實驗中仍有競爭力 [[src:openvla]]
- 相關：[[action-representation]]、[[action-chunking]]


=== [[cross-embodiment]] ===

# Cross-embodiment（跨機體）學習

- embodiment 指機器人的「身體」：手臂型號、感測器、動作空間 (推論)
- Open X-Embodiment 匯集 22 種機器人、527 種技能的資料 [[src:oxe]]
- RT-X 證明用別台機器人的資料訓練，能提升各台機器人的能力（positive transfer）[[src:oxe]]
- Octo 從 OXE 挑 800k 條軌跡 [[src:octo]]；OpenVLA 挑 970k 條 [[src:openvla]]
- π0 混用 7 種機器人配置，並加入約 9.1% 開源資料 [[src:pi0]]
- 呼應 RT-1 的結論：資料多樣性比資料量更重要 [[src:rt1]]
- 見 [[oxe]]


=== [[octo]] ===

# Octo（2024）

- 兩種尺寸：Octo-Small 27M、Octo-Base 93M 參數 [[src:octo]]
- 不是建在預訓練 VLM 上，因此是「通用機器人 policy」而非 RT-2 定義的 VLA [[src:octo]]
- 從 Open X-Embodiment 的 25 個資料集挑出 800k 條軌跡預訓練 [[src:octo]]
- Transformer + 可學習的 readout token（類似 BERT 的 [CLS]）；分塊遮罩注意力讓 fine-tune 時可增減輸入/輸出 [[src:octo]]
- 用 diffusion action head 預測一段連續動作（20 個 diffusion 步）[[src:octo]]，見 [[continuous-action-heads]] 與 [[action-chunking]]
- 任務可用語言（t5-base 編碼）或目標影像指定 [[src:octo]]
- Zero-shot 比 RT-1-X 高 29% 成功率，與 55B 的 RT-2-X 表現相近 [[src:octo]]
- 單張 A5000 消費級 GPU、約 100 筆示範、約 5 小時即可 fine-tune；平均比次佳基準高 52% [[src:octo]]


=== [[openvla]] ===

# OpenVLA（2024）

- 7B 參數開源 VLA：Prismatic-7B = 600M 視覺編碼器（融合 SigLIP 與 DINOv2）+ 2 層 MLP projector + Llama 2 7B [[src:openvla]]
- 在 Open X-Embodiment 中挑 970k 條軌跡訓練 [[src:openvla]]
- 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token [[src:openvla]]，見 [[action-representation]]
- 訓練：64 張 A100 跑 14 天（21,500 A100-hours）[[src:openvla]]
- 在 29 個任務上比 55B 的 RT-2-X 高 16.5% 絕對成功率，參數少 7 倍 [[src:openvla]]
- fine-tune 後比 Diffusion Policy 高 20.4% [[src:openvla]]
- LoRA（rank 32，只訓練約 1.4% 參數）成功率 68.2%，全參數 fine-tune 69.7%；單張 A100 約 10-15 小時 [[src:openvla]]
- 一張 RTX 4090 約 6 Hz、約 15GB 記憶體 [[src:openvla]]


=== [[oxe]] ===

# Open X-Embodiment 與 RT-X（2023）

- 匯集 22 種機器人的資料，由 21 個機構合作 [[src:oxe]]
- 涵蓋 527 種技能（160,266 個任務）[[src:oxe]]
- 用統一的資料格式釋出 [[src:oxe]]
- 用這份資料訓練的 RT-X 模型（RT-1-X、RT-2-X）出現正遷移（positive transfer），提升多種機器人的能力 [[src:oxe]]
- 這是 [[cross-embodiment]] 的代表性資料集，後來 [[octo]]、[[openvla]] 都從中挑資料預訓練 (推論)


=== [[pi0]] ===

# π0（Physical Intelligence, 2024）

- 在預訓練 VLM（PaliGemma 3B）上加一個 300M 參數的 action expert，總計 3.3B [[src:pi0]]
- action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 [[src:pi0]]，見 [[continuous-action-heads]]
- 一次輸出 H=50 步的 action chunk，靈巧任務控制頻率最高 50 Hz [[src:pi0]]，見 [[action-chunking]]
- 超過 10,000 小時機器人資料；7 種機器人配置、68 個任務；約 9.1% 是開源資料（OXE、Bridge v2、DROID）[[src:pi0]]
- 訓練分兩段：廣泛資料 pre-training 得到通用基底，再用少量高品質資料 post-training 到特定任務（簡單任務約 5 小時資料，最難的 100 小時以上）[[src:pi0]]
- 示範任務：摺衣服、收拾餐桌、組紙箱、裝雞蛋、裝購物袋 [[src:pi0]]


=== [[rt2]] ===

# RT-2: Vision-Language-Action Models（2023）

- 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作 [[src:rt2]]
- 核心做法：把動作表示成文字 token，直接放進 VLM 的訓練資料 [[src:rt2]]
- 動作 = 6-DoF 末端位移與旋轉 + 夾爪開合 + 終止指令；連續維度離散成 256 個 bin，每個動作 = 8 個整數 [[src:rt2]]
- PaLI-X 本來就有 1000 以內每個整數的 token，可直接對應；PaLM-E 沒有，因此覆寫 256 個最少用到的 token 當動作 token [[src:rt2]]
- 模型：RT-2-PaLI-X（5B、55B）、RT-2-PaLM-E（12B）[[src:rt2]]
- 見 [[co-fine-tuning]]：機器人資料約佔 PaLI-X 混合資料 50%、PaLM-E 66%；55B 模型 co-fine-tune 泛化平均 63，只 fine-tune 為 52 [[src:rt2]]
- 未見情境平均：RT-2 兩個版本都是 62，RT-1 為 32，約 2 倍提升 [[src:rt2]]
- 約 6,000 次評估 [[src:rt2]]
- 湧現能力：認得新物體、理解機器人資料沒有的指令（把東西放到某個數字上）、簡單推理（選最小的物體）、chain-of-thought（拿石頭當鐵鎚）[[src:rt2]]
- 55B 只能跑 1-3 Hz，5B 約 5 Hz，放在雲端 TPU 上由機器人透過網路呼叫 [[src:rt2]]
- 限制：網路資料不會教機器人新動作，技能仍受限於機器人資料中出現過的動作 [[src:rt2]]


=== [[vla]] ===

# Vision-Language-Action（VLA）模型

## 定義
- VLA 是把 vision-language model（VLM）微調成直接輸出機器人動作的模型 [[src:rt2]]
- 輸入：相機影像 + 自然語言指令；輸出：機器人下一步（或下一段）的動作 [[src:rt2]]
- 關鍵在「借用」VLM 從網路圖文學到的知識，讓機器人理解沒在機器人資料中看過的物體與指令 [[src:rt2]]

## 和相近名詞的差別
- RT-1 用 Transformer 直接學動作，但沒有用網路規模預訓練的 VLM [[src:rt1]]
- Octo 是通用機器人 policy，但不是建在預訓練 VLM 上 [[src:octo]]
- RT-2、OpenVLA、π0 都建在預訓練 VLM 上，屬於 VLA [[src:rt2]] [[src:openvla]] [[src:pi0]]

## VLA 的三個設計問題
1. 動作怎麼表示？→ [[action-representation]]
2. 資料從哪來、能不能跨機器人？→ [[cross-embodiment]]、[[co-fine-tuning]]
3. 怎麼輸出夠快、夠順的動作？→ [[action-chunking]]、[[continuous-action-heads]]

演進見 [[vla-timeline]]。


=== [[vla-timeline]] ===

# VLA 演進時間線

| 年 | 工作 | 一句話 |
|---|---|---|
| 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token [[src:rt1]] |
| 2023 | [[rt2]] | 把 VLM 變成 VLA，動作寫成文字 token，co-fine-tune [[src:rt2]] |
| 2023 | [[oxe]] | 22 種機器人資料大集合，RT-X 正遷移 [[src:oxe]] |
| 2024 | [[octo]] | 93M 開源通用 policy，diffusion head [[src:octo]] |
| 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5% [[src:openvla]] |
| 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服 [[src:pi0]] |

- 趨勢一：從封閉大模型走向開源可微調 (推論)
- 趨勢二：動作從離散 token 走向連續 chunk (推論)


每張投影片 JSON：
{"id":"s01","kind":"title|content|flow|compare|timeline|quiz|summary","objective":"O1..O5 或 null",
 "title":"...","subtitle":"(可選)",
 "bullets":[{"text":"≤60字","cite":["wiki頁名"],"type":"fact|analogy"}],
 "defines":[{"term":"術語(須與術語表同名)","def":"一句白話解釋"}],
 "flow":[{"label":"...","text":"..."}],                      (kind=flow)
 "table":{"columns":[...],"rows":[[...]],"cite":[...]},       (kind=compare)
 "timeline":[{"year":"2023","name":"RT-2","text":"...","cite":[...]}], (kind=timeline)
 "quiz":{"q":"...","options":["..."],"answer":0,"explain":"...","cite":[...]}, (kind=quiz)
 "note":"講者備註"}
規則：
1. 只能使用下方 Wiki context 的內容；每個 fact bullet / 表格 / 時間線 / quiz 解說都要 cite 對應 wiki 頁名（不是論文名）。
2. 所有數字必須出現在被 cite 的 wiki 頁中。比喻請標 type=analogy（不需 cite，但不可含數字）。
3. 觀眾：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學。下列術語第一次出現的那張投影片必須放進 defines：['VLA', 'VLM', 'policy', 'embodiment', 'DoF', 'co-fine-tuning', 'action chunk', 'diffusion', 'flow matching', '控制頻率', '正遷移']。
4. 每張最多 5 個 bullet，每個 ≤60 字；總張數 10–16。
5. 第一張 kind=title，至少 1 張 quiz、1 張 summary；每個學習目標至少 1 張。
6. 繁體中文，術語保留英文。只輸出 JSON。