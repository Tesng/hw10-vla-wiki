---
id: oxe
title: "Open X-Embodiment: Robotic Learning Datasets and RT-X Models"
url: https://arxiv.org/abs/2310.08864
year: 2023
fetched: 2026-11-15
---
# Open X-Embodiment (OXE, 2023) — source extract

- A pooled dataset from 22 different robots, assembled through a collaboration of 21 institutions.
- Demonstrates 527 skills (160,266 tasks).
- Datasets released in a standardized data format, together with models.
- RT-X: high-capacity models (RT-1-X, RT-2-X) trained on this mixture "exhibit positive transfer and improve the capabilities of multiple robots" — i.e. training on other robots' data helps each robot.
- Cross-embodiment learning: one policy trained across many robot bodies.
