---
id: openvla
title: "OpenVLA: An Open-Source Vision-Language-Action Model"
url: https://arxiv.org/abs/2406.09246
year: 2024
fetched: 2026-11-15
---
# OpenVLA (Kim et al., 2024) — source extract

- 7B-parameter open-source VLA. Backbone: Prismatic-7B = 600M-parameter visual encoder fusing SigLIP + DINOv2 features, 2-layer MLP projector, Llama 2 7B language model.
- Training data: 970k robot manipulation trajectories from Open X-Embodiment (curated subset of >2M).
- Action tokenization: each action dimension discretized separately into 256 bins; bin widths uniformly divide the interval between the 1st and 99th quantile of training actions (robust to outliers). Bins are mapped onto the 256 least-used tokens of the Llama tokenizer (overwritten).
- Compute: 64 A100 GPUs for 14 days (21,500 A100-hours), batch size 2048.
- Results: outperforms RT-2-X (55B) by 16.5% absolute task success with 7x fewer parameters, across 29 tasks and multiple embodiments. Fine-tuned OpenVLA beats Diffusion Policy by 20.4%.
- Fine-tuning: LoRA on all linear layers, rank 32, ~1.4% of params (97.6M); 68.2% vs 69.7% full fine-tuning; 10-15 hours on a single A100 (8x less compute).
- Inference: ~6 Hz on one RTX 4090 in bfloat16, ~15GB GPU memory; quantization keeps success rate.
