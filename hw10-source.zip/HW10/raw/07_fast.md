---
id: fast
title: "FAST: Efficient Action Tokenization for Vision-Language-Action Models"
url: https://arxiv.org/abs/2501.09747
year: 2025
fetched: 2026-11-15
---
# FAST (Pertsch et al., Physical Intelligence, 2025) — source extract

- Problem: prior VLAs discretize each action dimension at each timestep into one of 256 bins. At high control frequency, consecutive action tokens are highly correlated, so models reach low token prediction loss with trivial mappings and get stuck in poor local optima; marginal information per token approaches zero as frequency increases.
- FAST = Frequency-space Action Sequence Tokenization: normalize each dimension (1st/99th quantile to [-1, 1]) → discrete cosine transform (DCT) per dimension → scale and round coefficients (default scale 10) → flatten low frequencies first → byte-pair encoding (BPE, default vocabulary 1024).
- Compression for 1-second chunks (naive vs FAST tokens): BridgeV2 5 Hz 35 vs 20; DROID 15 Hz 105 vs 29; Table Bussing 20 Hz 140 vs 28; T-Shirt Folding 50 Hz 700 vs 53 (13.2x). Roughly 30 tokens per chunk per arm, largely independent of control frequency.
- FAST+ universal tokenizer trained on about 1M one-second action chunks from diverse robots.
- π0-FAST (autoregressive, discrete tokens) matches diffusion π0 on evaluated tasks including laundry folding; reaches high Table Bussing performance with 3x fewer training steps; up to 5x less training time (GPU hours).
- Trade-off: inference about 750 ms per chunk vs about 100 ms for diffusion π0 on an NVIDIA 4090.
- Scales to 10k hours of robot data; first zero-shot DROID evaluation in unseen environments (16 tasks, 44 trials).
