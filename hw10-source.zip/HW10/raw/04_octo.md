---
id: octo
title: "Octo: An Open-Source Generalist Robot Policy"
url: https://arxiv.org/abs/2405.12213
year: 2024
fetched: 2026-11-15
---
# Octo (Octo Model Team, 2024) — source extract

- Sizes: Octo-Small 27M, Octo-Base 93M parameters. Not built on a pre-trained VLM (a generalist policy, not a VLA in the RT-2 sense).
- Pretraining: 800k trajectories curated from 25 datasets of Open X-Embodiment.
- Architecture: transformer backbone with learned readout tokens (like BERT's [CLS]); block-wise masked attention so inputs/outputs can be added or removed at fine-tuning time (flexible observation and action spaces).
- Action output: diffusion action head predicting a chunk of consecutive actions (20 diffusion steps) — continuous actions, not discrete tokens.
- Task conditioning: language instruction (t5-base encoder) or goal image.
- Zero-shot: 29% higher success than RT-1-X (35M); performed similarly to RT-2-X (55B) on WidowX and RT-1 robot tasks.
- Fine-tuning: ~5 hours on a single NVIDIA A5000 consumer GPU with ~100 demonstrations; outperforms next best baseline by 52% on average across six setups.
- Pretraining compute: 300k steps, batch 2048, TPU v4-128 pod, 14 hours. Evaluated on 9 robot platforms across 4 institutions.
