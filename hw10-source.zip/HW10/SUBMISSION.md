# 繳交內容（可直接複製貼上）

**標題：** 清大 115061602 電機碩一 曾柏凱 VLA 模型入門

> 以下連結假設 GitHub repo 名稱為 `hw10-vla-wiki`；如果取了別的名字，請把網址最後一段改掉。

**1. LLM Wiki 主題與簡短介紹**
主題是 VLA（Vision-Language-Action）模型：讓大型模型看影像、讀指令，直接輸出機器人動作。讀者設定為修過 ML、但沒碰過機器人的同學。依 Karpathy 的 LLM Wiki 模式，先和 AI 討論 8 個問題（讀者、頁面類型、語言、出處粒度、論文矛盾怎麼處理、逐篇或整批 ingest、要產出什麼、lint 要檢查什麼）再建檔。共 ingest 7 篇論文（RT-1、RT-2、Open X-Embodiment、Octo、OpenVLA、π0、FAST），整理成 7 個概念頁、7 個論文頁；每一句都有出處，推論另外標示，論文之間的矛盾並列呈現。

**2. LLM Wiki 連結或成果**
https://tesng.github.io/hw10-vla-wiki/wiki/index.html

**3. 教學 HTML 簡報連結**
https://tesng.github.io/hw10-vla-wiki/slides.html

**4. loop / graph 的流程圖或文字說明**
https://tesng.github.io/hw10-vla-wiki/#sec4
（首頁第 4 節有流程圖。簡述：取得資料 → Wiki lint → 檢索＋覆蓋率關卡 → 證據卡 → AI 大綱 → 程式檢查 → 人工確認 → 逐頁稿（頁內：寫→檢查→修）→ AI 審查（另一個模型、新對話）→ 整份檢查 → 渲染 → 溢出檢查 → 人工驗收 → 交件；錯在哪一關就退回哪一關，每個自動迴圈都有上限）

**5. 一次實際執行的結果或檢查紀錄**
https://tesng.github.io/hw10-vla-wiki/runs.html
（共執行 v1–v5；最終版 v5 用 Groq gpt-oss-120b 寫稿、qwen3.8-27b 審查：152 次 LLM 呼叫，AI 審查退回 10 次，人工驗收抓到 6 個程式與 AI 都漏掉的錯）

**6. 反思：哪個節點最常出錯？如何調整檢查流程？**
最常出錯的是「逐頁稿」節點（LLM 寫內容）：把推論寫成事實、表格欄位放錯、用比喻標籤繞過出處檢查。但錯誤次數最多的其實是檢查器自己：v3 有 71 次數字誤報，原因是特殊連字號「RT‑1」。調整方式是把檢查往前移：出處拆成 claim 移到「查詢 Wiki」階段、術語順序與小測驗證據移到「大綱檢查」、Wiki 導覽句被當成證據的問題移到「lint」；並加上剎車、錯誤訊息改成可以照著做、換更強的審查模型，最後保留人工驗收。完整反思：https://tesng.github.io/hw10-vla-wiki/#sec6

原始碼與所有執行紀錄：https://tesng.github.io/hw10-vla-wiki/hw10-source.zip
