# HW10 — LLM Wiki → 教學 HTML 簡報（VLA 入門）

- 繳交說明（含 loop/graph 設計、執行紀錄、反思）：`REPORT.md`；可直接貼上的繳交內容：`SUBMISSION.md`
- 簡報：`output/slides.html`（最終版 = runs/v5 的成品）
- Wiki：`wiki/`（schema 見 `AGENTS.md`、需求摘要見 `docs/requirements.md`）；檢查：`python3 pipeline/lint.py`
- 產生簡報：`python3 pipeline/graph.py --run <id> --llm groq`（需要 `.env` 裡的 `GROQ_API_KEY`；中斷後加 `--resume`；跑完後回到人工驗收加 `--reopen`）
- 查看可用模型與額度：`python3 pipeline/llm.py --models`
- 產生 GitHub Pages 網站：`python3 pipeline/build_site.py` → 上傳 `site/` 裡的檔案
- 只需要 Python 3.9+ 標準函式庫；渲染檢查可以選用 Playwright
