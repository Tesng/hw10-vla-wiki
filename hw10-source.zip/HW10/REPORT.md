# VLA 是什麼？— 用 LLM Wiki 做教學 HTML 簡報

> HW10｜曾柏凱（清大 電機所）｜主題：Vision-Language-Action（VLA）模型入門

<!-- CARDS -->

## 1. LLM Wiki 主題與簡短介紹

**主題：VLA（Vision-Language-Action）模型**，也就是讓大型模型看影像、讀指令，直接輸出機器人動作。這是我的研究方向（VLA / VLM），所以這個 Wiki 之後也會繼續用。

- **讀者**：修過 ML、懂 Transformer / LLM，但沒碰過機器人的同學
- **收錄 7 篇論文**：RT-1 → RT-2 → Open X-Embodiment → Octo → OpenVLA → π0 → FAST（2022–2025）
- **建法**：照 Karpathy 的 LLM Wiki 模式分三層：`raw/`（原始資料，只讀）→ `wiki/`（LLM 維護）→ `AGENTS.md`（schema）
- **先討論、後生成**：我先和 AI 討論 8 個問題（讀者、頁面類型、語言、出處粒度、矛盾處理、ingest 方式、要產出什麼、lint 檢查什麼），確認後才建檔。每個決定都寫在 [需求摘要](wiki/schema.html)，也一條條對應到 AGENTS.md。

## 2. LLM Wiki 連結與成果

🔗 **Wiki 瀏覽頁：[wiki/index.html](wiki/index.html)**（GitHub repo 裡是原始 markdown，用 git 管理）

| 類型 | 頁面 |
|---|---|
| 導覽 | [[index]]（目錄）、[[log]]（append-only 變更紀錄） |
| 概念頁 ×7 | [[vla]]、[[action-representation]]、[[co-fine-tuning]]、[[cross-embodiment]]、[[action-chunking]]、[[continuous-action-heads]]、[[vla-timeline]] |
| 論文頁 ×7 | [[rt1]]、[[rt2]]、[[oxe]]、[[octo]]、[[openvla]]、[[pi0]]、[[fast]] |

**建 Wiki 時特別考量的幾件事**

1. **出處要細到「每一句」**：每條 bullet 都標 `[[src:論文]]`；沒有論文支持的句子要標「推論」，而且推論句裡不能有數字。這樣後面做簡報時，才能分辨哪些是事實、哪些是推論。
2. **數字一定要在原文找得到**：lint 會把每個數字拿去 raw/ 原文比對。
3. **矛盾不刪掉，兩邊都留**：例如 π0 用連續 flow matching 做 50 Hz 靈巧任務，FAST 卻顯示離散 token 也能追平，Wiki 會寫成「⚠ 矛盾」把兩邊並列，再另外寫一行推論說明可能的原因（見 [[action-representation]]）。
4. **一次 ingest 一篇，每篇一個 git commit**：前 6 篇是在建 git 之前整批 ingest 的；討論後改成逐篇，第 7 篇 FAST 就是照這個流程進來的（`git log` 可以看到 `ingest: fast`）。
5. **lint 是一支可以執行的腳本**：`python3 pipeline/lint.py` 會檢查斷鏈、孤兒頁、index 缺頁、句子沒有出處、數字在出處找不到、推論句含數字、frontmatter 少列來源、矛盾句來源少於 2 個。第一次 lint 抓到 9 個問題，其中 8 個其實是 lint 規則自己的誤判，所以我也修了 lint（見[執行紀錄](runs.html)）。

## 3. 教學 HTML 簡報

🔗 **簡報：[slides.html](slides.html)**（← → 換頁、N 顯示講者備註、小測驗可以點選作答）。這份是 graph 最後一次執行（run v5）的成品：寫稿 Groq `openai/gpt-oss-120b`，審查 Groq `qwen/qwen3.8-27b`，經過 2 道人工關卡。

教學設計：

- **5 個學習目標**（每頁左上角都標出這頁對應哪個目標）：O1 VLA 的定義、O2 動作怎麼變成輸出、O3 資料從哪來、O4 為什麼需要 action chunking、O5 代表模型的演進與比較
- **從觀眾熟悉的東西開始**：LLM → VLM → VLA，再進到「動作怎麼表示」「資料」「速度」三個設計問題，最後用時間線和比較表收尾
- **名詞小卡**：policy、embodiment、DoF、flow matching 等 11 個術語，第一次出現的那頁一定有白話解釋（程式檢查）
- **小測驗 ×1、總結 ×1、未來挑戰 ×1**
- **每句都有出處標籤**：滑鼠移上去可以看 Wiki 原句；實心點是論文事實、空心橘點是推論、橘字是比喻；最後一頁列出論文連結

**Wiki 與簡報的對應**（每頁引用的 Wiki 頁；點進去可以看到原句）：

| 頁 | 類型 | 目標 | 標題 | 引用的 Wiki claim |
|---|---|---|---|---|
| s01 | title | — | VLA（Vision‑Language‑Action）模型概覽 | — |
| s02 | content | O1 | VLA 定義與 LLM / VLM 的關係 | [[vla]] |
| s03 | content | O2 | 離散 token 與連續動作的表徵方式 | [[action-representation]] |
| s04 | compare | O2 | 離散 vs 連續：效能與頻率比較 | [[action-representation]] |
| s05 | content | O3 | 資料來源：跨機體資料與 co‑fine‑tuning | [[co-fine-tuning]]、[[cross-embodiment]] |
| s06 | content | O4 | Action Chunking：提升控制頻率的關鍵 | [[action-chunking]] |
| s07 | compare | O4 | Octo Diffusion vs π0 Flow Matching | [[action-representation]]、[[continuous-action-heads]] |
| s08 | timeline | O5 | 從 RT‑1 到 π0 的演進路線 | [[vla-timeline]] |
| s09 | compare | O5 | RT‑1 → RT‑2 → OpenVLA → π0：關鍵差異 | [[openvla]]、[[pi0]]、[[rt2]]、[[vla-timeline]] |
| s10 | quiz | — | 小測驗：檢測概念掌握 | [[action-chunking]]、[[co-fine-tuning]]、[[vla]] |
| s11 | summary | — | 總結與未來展望 | [[openvla]]、[[vla-timeline]] |
| s12 | flow | — | 未來挑戰與研究方向 | [[fast]] |
| — | 資料來源 | — | 自動產生：每篇論文 → 用到的 Wiki 頁 | — |

## 4. loop / graph 設計

<!-- GRAPH_SVG -->

流程是**事先畫好的 graph**（`pipeline/graph.py`，最終版）：誰在什麼時候做什麼，由程式決定，不是由 AI 決定。每個節點只做一件事，而且有明確的輸入與輸出檔案（`runs/<id>/sources.md → cards/ → outline.md → drafts/ → deck.html → report.md`）。AI 節點用 Groq：寫稿 `openai/gpt-oss-120b`，審查 `qwen/qwen3.8-27b`（不同模型家族，各自一份每分鐘額度）。
對應作業的流程：**取得資料**（load_wiki、lint_wiki）→ **查詢 Wiki**（query_wiki、evidence_cards）→ **整理重點**（outline、人工確認）→ **檢查內容**（程式檢查、AI 審查）→ **產生簡報**（render_html、check_render）→ **人工驗收**（human_final）→ finalize。

**每一關只能看什麼、不能做什麼**

| 節點 | 只能看 | 不能做（由程式擋下） |
|---|---|---|
| evidence_cards | Wiki 的 claim，依論文分卡 | 混入其他來源 |
| outline（AI） | index + 證據卡 | 引用卡片裡沒有的 claim（`bad_cite`） |
| draft_pages（AI） | 大綱中的這一頁 + 這一頁的證據卡 | 引用卡片以外的內容（`cite_outside_cards`）、改寫數字、把推論寫成事實 |
| ai_review（另一個模型） | 該頁成品 + 它引用的原句 | 自己改稿（只能回報問題） |
| render_html | 已通過的逐頁稿 | 改任何一個字（固定模板） |
| human_final（人） | 渲染後的成品 + 檢查報告 | ——（人決定退回哪幾頁，或退回大綱） |

**哪些步驟會重複執行？（都有硬上限）**

| 迴圈 | 什麼時候轉 | 上限 |
|---|---|---|
| query_wiki ⟲ | 某個學習目標的事實少於 2 條 → 擴大檢索 | 2 次，仍不足就停（不用自己的知識硬湊） |
| outline ⇄ check_outline | 大綱的程式檢查沒過（張數、目標覆蓋、claim 不存在、術語先用後教） | 2 次 |
| human_gate → outline | 我看了大綱，寫下修改意見 | 5 次 |
| human_final → draft_pages／outline | 我看了成品：「s07: 意見」只退回那幾頁；「outline: 意見」退回大綱 | 不設上限（人的決定） |
| 逐頁稿頁內小圈 | 寫一頁 → 程式檢查 → 修 | 每頁 2 次 |
| ai_review → draft_pages | 審查發現說法講反、沒有證據支持、張冠李戴 → **只退回那一頁** | 每頁 2 次 |
| check_render → draft_pages | 渲染後溢出畫面 → 只退回那一頁、要求縮短 | 每頁 2 次 |
| check_deck → outline（大圈） | 有論文完全沒被用到 → 退回大綱補進去 | 1 次 |

**哪些地方需要檢查或重新生成？** 會重新生成的只有 AI 節點（大綱、逐頁稿）。檢查分兩種：**程式檢查**負責出處、數字、字數、術語、溢出這類「可以用腳本判斷」的事；**AI 審查**負責「說法有沒有講反、有沒有忠於來源」這種程式判斷不了的事，而且審查用另一個模型、開新的對話，只給它成品和來源，**不讓它審自己的作品**。

**為什麼這樣設計？**

- **錯誤要在離源頭最近的地方被抓到**：出處在 query 階段就拆成帶 id 的證據卡，術語順序在大綱階段就檢查，所以小圈轉得快、大圈很少轉。
- **錯在哪一頁就退回哪一頁**：v1 修一個錯要把 13 頁整份重送；v3 只重寫有問題的那一頁，其他頁不動。
- **「做完了」由腳本說了算**：完成標準是程式檢查全過、AI 審查 pass、渲染沒有溢出，而不是 AI 說「檢查過了」。
- **每一關的產出都是檔案**：可以打開來看、放進 git、單獨重跑；每次 LLM 呼叫的 prompt 和 response 都留著。

**把這個 loop 的規格寫清楚（講義：一個 loop 要寫清楚五件事）**

- 🎯 **目標**：只用 Wiki 的內容，產出能讓初學者理解 VLA 的 HTML 簡報（O1–O5）
- 🧱 **限制**：raw/ 不可改；只能引用證據卡；數字不可換算；推論要標出來
- ✅ **完成標準**：程式檢查全過 + AI 審查 pass + 渲染不溢出 + 10–14 頁內容頁
- 🛑 **停止條件**：見上表每個迴圈的上限；相關頁面少於 3 頁就一開始停下
- ⏰ **觸發**：每次 ingest 新論文後，手動執行 `python3 pipeline/graph.py --run <id> --llm groq`

## 5. 實際執行結果與檢查紀錄

完整紀錄：🔗 [runs.html](runs.html)（每次執行的 trace、檢查報告、逐句比對）

我總共實際跑了 5 個版本，每次都留下完整紀錄（`runs/v1` … `runs/v5`）。

| 版本 | 寫稿的 LLM | 結果 | 關鍵數字 |
|---|---|---|---|
| v1 | Claude（agent 模式） | 檢查全過，但**人工逐句比對**發現 4 句推論被寫成事實 | `check_slides` 擋下 1 個錯（術語先用後教），修 1 次通過 |
| v2 | Claude（agent 模式） | 大綱檢查與內容檢查都一次通過 | 檢查改到 claim 層級；回放到 v1 草稿，抓到那 4 句 + 1 個數字改寫 |
| v3 第 1 次 | Groq gpt-oss-120b | **在 draft_pages 當掉** | 模型把 bullets 輸出成字串，檢查器沒先驗格式 → `AttributeError` |
| v3 | Groq gpt-oss-120b／審查 gpt-oss-20b | 完成，但 3 頁未解決 | 106 次呼叫、約 13 萬 tokens、約 36 分鐘；draft_pages 出錯 93 次，其中 71 次是檢查器誤報 |
| v4 | Groq gpt-oss-120b／審查 qwen3.8-27b | 完成，1 頁未解決 | **68 次呼叫**、約 7.5 萬 tokens、約 10 分鐘；0 次數字誤報 |
| v5（最終） | 同 v4 ＋ 人工驗收關卡 | **完成**，12 頁全部通過；人工驗收實際退回 3 次（退回大綱 1 次、退回指定頁共 10 頁次） | 152 次呼叫、約 20 萬 tokens；撞到 Groq 每日上限 1 次（隔天 --resume 接續）；graph 自身 bug 4 個 |

v3 → v4 的錯誤類型（同一批 49 份逐頁稿，分別用兩版檢查器檢查，`runs/v3_review/`）：

| 錯誤類型 | v3 檢查器 | v4 檢查器 |
|---|---|---|
| ungrounded_number（數字找不到出處） | 71 | **0**（全是誤報） |
| too_long | 7 | 7 |
| uncited | 5 | 5 |
| undefined_term | 3 | 3 |
| inference_as_fact | 3 | 0（誤報） |
| schema（格式錯誤） | 0 | 3（v3 沒檢查） |
| disguised_claim（假比喻） | 0 | 2（v3 沒檢查） |

判定不通過的稿子：v3 是 37/49 份，v4 是 16/49 份。

**v5（最終版）的檢查紀錄**（`runs/v5/report.md`）：

| 節點 | 錯誤類型 | 次數 |
|---|---|---|
| draft_pages | inference_as_fact（推論寫成事實／表格引用推論） | 19 |
| ai_review | unsupported（證據不支持） | 13 |
| ai_review | table_mismatch（表格欄位錯置） | 11 |
| draft_pages | too_long | 9 |
| draft_pages | ungrounded_number／uncited／disguised_claim | 5／5／4 |
| draft_pages | repeated_error（剎車） | 4 |
| ai_review | misleading／wrong_attribution／reversed | 2／2／1 |

- 逐頁稿 66 次、AI 審查 38 次（退回 10 次），Playwright 實測 0 頁溢出。
- **人工驗收第 6 輪抓到 6 個程式和 AI 審查都沒抓到的錯**：s03 把 action chunk 說成「把動作切成 token」、s07「flow matching 只需一次前向傳播」、s11 把 OpenVLA 的成績說成所有 VLA 的、s12「訓練時間最少 5 倍」（原文是最多少 5 倍）、s04／s09 表格空格。退回後只重寫那幾頁，再審查、再驗收才通過。

## 6. 反思

### 哪一個節點最常出錯？

**`draft_pages`（逐頁稿，LLM 寫內容的節點）。** 每一版都是它出錯最多，常見的錯法如下：

| 錯法 | 例子 | 由誰抓到 |
|---|---|---|
| 把推論寫成事實 | v1：4 句 | 人工逐句比對 → 之後由程式檢查 |
| 輸出格式不對 | v3：bullets 變成字串、引用寫進句子 | 程式（v3 之後先驗格式） |
| 用「比喻」標籤包裝事實，繞過出處檢查 | v3 s09：「離散化會增加延遲」標成 analogy | 程式（v4 新增 disguised_claim） |
| 數字或主詞套錯 | v3 s04：把 FAST 的 53 個 token 寫在「連續輸出」那一列 | v3 審查沒抓到 → v4 換更強的審查模型、加 table_mismatch |
| 字數超過、算不準中文字數 | v3 s10：63 字改了 5 次 | 程式；錯誤訊息改成寫出「要刪幾個字」 |

v5 裡被程式擋下最多的是「推論寫成事實」（19 次），被 AI 審查退回最多的是「證據不支持」與「表格欄位錯置」（24 次）；而**意思錯了、但數字和出處都對**的錯誤（例如把 action chunk 解釋成 token 化），程式和 AI 審查都漏掉，最後是人工驗收抓到的。

但是**錯誤次數最多的其實是檢查器自己**：v3 的 93 次錯誤裡，有 71 次是數字檢查器誤報。原因是 Groq 寫「RT‑1」用了不換行連字號（U+2011），程式沒認出模型名稱，就把 1、2 當成要查出處的數字。估算型的溢出檢查也誤報 s08、s09（瀏覽器實測 0px）。另外，v4 的 AI 審查把小測驗「故意設計的錯誤選項」當成錯誤要求改正，結果 4 個選項全部變成正確。**檢查器和審查者本身也會錯，也需要被檢查。**

### 發現問題後，把檢查往前移到哪一步？

| 問題 | 原本在哪裡抓 | 往前移到哪裡 |
|---|---|---|
| 推論被寫成事實、數字張冠李戴 | 投影片寫完後，以「頁」為單位檢查 | **query_wiki**：檢索時就拆成帶 id 的 claim，標好 fact／inference 與數字（v2） |
| 術語先用後教 | 整份投影片寫完後 | **check_outline**：大綱階段就檢查（v2） |
| 格式錯誤 | 沒有檢查（直接當掉） | **check_slide 的第一步**：先驗格式、再驗內容（v3 修正） |
| 證據卡本身錯（只有連結的「相關」句被當成證據，v4 s11 因此寫出錯誤結論） | 簡報產出後由人發現 | **lint_wiki**：新增 nav_as_claim 規則，在 Wiki 層就擋下（v4 → v5） |
| 頁面太薄 | 人看成品才發現 | **check_outline**：每頁至少 3 條 claim（v4） |

| 稿子仍是舊版大綱寫的（v5 退回大綱後漏重寫 4 頁） | 人工驗收 | **check_deck**：新增 stale_slide，稿子和現行大綱不一致就退回 |
| 小測驗沒有分配證據、標題錯字 | 寫稿時才失敗、人工驗收 | **check_outline**：quiz 至少 2 條 claim、錯字檢查 |

這就是講義說的「錯誤要在離源頭最近的地方被抓到」：越晚發現，退回的範圍越大、浪費的 LLM 呼叫越多。

### 有沒有因此修改 workflow／graph？為什麼？

有，一共改了 4 次，每次都是被實際執行結果逼出來的：

1. **v1 → v2**：新增 check_outline；引用從「頁」改成「claim」。原因：頁層級的引用看起來有出處，實際上沒辦法驗證。
2. **v2 → v3**（對照講義）：證據卡、人工確認大綱、逐頁稿只看自己的卡片、AI 審查（另一個模型、新對話）、渲染檢查、錯在哪一頁就退回哪一頁。原因：v2 修一個錯要整份重送，而且沒有「說法有沒有講反」這種程式判斷不了的檢查。
3. **v3 → v4**：Unicode 正規化、假比喻檢查、剎車（同樣的錯誤連續兩次就停；v3 的 s09 同一個錯重寫了 12 次）、估算型檢查只警告不退件、換更強的審查模型、依 Groq 回傳的額度 header 精準節流。結果呼叫次數從 106 降到 68，時間從 36 分鐘降到 10 分鐘。
4. **v4 → v5**：審查規則補上小測驗的邏輯、Wiki 修正證據卡、新增**人工驗收**關卡（可以只退回指定頁，或用「outline:」退回大綱）。原因：審查者自己也會把東西改壞，最後仍需要人在指定關卡把關。
5. **v5 執行中修掉的 graph 本身的 bug**（每一個都是實際跑出來的）：網路逾時沒有重試；退回大綱後「哪些頁要重寫」只和上一版比，漏掉 4 頁；人工關卡空白 Enter 被當成通過、長中文意見被終端機截斷（改成支援 `@檔案`）；人工退回次數的上限兩度擋下真正的退回，還把結果誤判成 done（改成人工退回不設上限、超過自動上限時列為未解決）。**剎車和人工關卡本身的邏輯也需要測試。**

### 其他心得

- **人工關卡不是裝飾**：最後一輪人工驗收抓到 6 個「數字和出處都對、意思卻錯」的錯誤，這是程式檢查與 AI 審查的盲區。但人也會漏看（v5 第 3 輪就把舊版的 s07／s10 放行了），所以能用程式檢查的一致性（例如稿子 vs 大綱）都要交給程式。
- **「做完了」不能由 AI 說了算**：v1 的檢查全過，但內容仍然有錯。可以執行的檢查必須夠細，檢查器本身也要用真實資料測過。
- **錯誤訊息要能照著做**：v3 只說「沒有引用」，模型同樣的錯犯了 3 次；改成「claim id 只能放在 cite 陣列，text 裡不要寫引用」之後，一次就修好。
- **loop 一定要有剎車**：沒有上限的 loop 會把額度燒光。這次光是 v3 就用了 13 萬 tokens，還真的撞到 Groq 的每日上限（20 萬 tokens），v5 隔天才用 `--resume` 從 checkpoint 接續。
- **限制**：數字檢查只比對字串，抓不到「數字對但主詞錯」；這類錯要靠 AI 審查，而審查也可能漏掉。檢索用關鍵字打分，Wiki 再大一點就需要 embedding 檢索。
