---
name: log
type: meta
summary: Wiki 變更紀錄（append-only）
sources: []
---
# Log
## [2026-11-15] discuss | 與使用者確認結構：6 source + 7 concept + index/log；觀眾＝修過 ML 但沒碰過機器人
## [2026-11-15] ingest | rt1
## [2026-11-15] ingest | rt2
## [2026-11-15] ingest | oxe
## [2026-11-15] ingest | octo
## [2026-11-15] ingest | openvla
## [2026-11-15] ingest | pi0
## [2026-11-15] build | concepts: vla, action-representation, co-fine-tuning, cross-embodiment, action-chunking, continuous-action-heads, vla-timeline
## [2026-11-15] lint | 初次 lint 9 項：6 項導覽列/表頭誤判、1 項連結名 [[pi0]] 的 0 被當數字、1 項推論句含連結名數字 → 修 lint 規則；1 項真錯誤：vla frontmatter 漏列 rt1 → 已修
## [2026-11-15] lint | 0 issue
## [2026-11-15] query | graph v1 (runs/v1)：context 12 頁；check_slides 1 錯（s01 VLA 未定義）→ repair 1 次通過；人工審查發現 4 句 (推論) 被寫成事實
## [2026-11-15] schema | graph v2：query 改輸出 claim 層級 evidence pack；新增 check_outline；check_slides 改 claim 層級
## [2026-11-15] query | graph v2 (runs/v2)：78 claims（7 inference）；outline/slides 檢查皆一次通過 → output/slides.html
## [2026-11-15] ingest | fast（第一篇照 AGENTS.md 逐篇 ingest + commit）：新增 sources/fast；更新 action-representation（加入路線三與 ⚠ 矛盾）、vla-timeline、index
## [2026-11-15] lint | v4 實跑發現 fast#7（只有連結的「相關」句）被當成推論 claim，s11 引用它寫出錯誤結論 → 改成導覽列；lint 新增 nav_as_claim 規則
