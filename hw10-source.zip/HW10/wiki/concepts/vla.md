---
name: vla
type: concept
summary: VLA 的定義：看影像、讀指令、直接輸出機器人動作的模型；建在預訓練 VLM 上
sources: [rt1, rt2, openvla, pi0, octo]
---
# Vision-Language-Action（VLA）模型

## 定義
- VLA 是把 vision-language model（VLM）微調成直接輸出機器人動作的模型 [[src:rt2]]
- 輸入：相機影像 + 自然語言指令；輸出：機器人下一步（或下一段）的動作 [[src:rt2]]
- 關鍵在「借用」VLM 從網路圖文學到的知識，讓機器人理解沒在機器人資料中看過的物體與指令 [[src:rt2]]

## 和相近名詞的差別
- RT-1 用 Transformer 直接學動作，但沒有用網路規模預訓練的 VLM [[src:rt1]]
- Octo 是通用機器人 policy，但不是建在預訓練 VLM 上 [[src:octo]]
- RT-2、OpenVLA、π0 都建在預訓練 VLM 上，屬於 VLA [[src:rt2]] [[src:openvla]] [[src:pi0]]

## VLA 的三個設計問題
1. 動作怎麼表示？→ [[action-representation]]
2. 資料從哪來、能不能跨機器人？→ [[cross-embodiment]]、[[co-fine-tuning]]
3. 怎麼輸出夠快、夠順的動作？→ [[action-chunking]]、[[continuous-action-heads]]

演進見 [[vla-timeline]]。
