---
name: action-representation
type: concept
summary: 動作表示三條路線：256 bin 離散 token（RT-1/RT-2/OpenVLA）、連續輸出（Octo diffusion、π0 flow matching）、壓縮後的離散 token（FAST）
sources: [rt1, rt2, openvla, octo, pi0, fast]
---
# 動作表示（Action Representation）

## 路線一：離散 token（把動作當文字）
- RT-1 把 11 個動作維度各離散成 256 個 bin [[src:rt1]]
- RT-2 把每維離散成 256 個 bin，一個動作變成 8 個整數，再寫成文字 token [[src:rt2]]
- 好處是可以直接沿用語言模型的 next-token 預測訓練 VLM [[src:rt2]]
- PaLM-E 和 OpenVLA 都用「覆寫最少用的 256 個 token」來放動作 [[src:rt2]] [[src:openvla]]
- OpenVLA 以第 1 到第 99 百分位決定 bin 範圍，避免極端值 [[src:openvla]]

## 路線二：連續輸出
- Octo 用 diffusion action head 輸出連續動作 [[src:octo]]
- π0 用 flow matching 的 action expert 輸出連續動作，不做離散化 [[src:pi0]]
- 細節見 [[continuous-action-heads]]

## 小結
- 離散 token 最容易接上 VLM；連續輸出更適合高頻、靈巧的動作，例如 π0 以 50 Hz 摺衣服 [[src:pi0]]

## 路線三：壓縮後的離散 token（FAST）
- 樸素的 256 bin 在高頻時相鄰 token 高度相關，模型容易陷入「照抄」的局部解 [[src:fast]]
- FAST 先做 DCT 再用 BPE 壓縮，50 Hz 的 1 秒動作從 700 個 token 降到 53 個 [[src:fast]]
- ⚠ 矛盾：π0 論文以連續 flow matching 處理 50 Hz 靈巧任務 [[src:pi0]]；FAST 則顯示離散 token 的 π0-FAST 在摺衣服上也能追平 diffusion 版 π0，但推論較慢（約 750 ms 對 100 ms）[[src:fast]]
- 可能原因：差別不在「離散或連續」本身，而在 token 化方式是否壓掉高頻冗餘；兩者在訓練速度與推論速度上各有取捨 (推論)
