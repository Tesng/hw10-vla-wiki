---
name: cross-embodiment
type: concept
summary: 跨機體學習：一個 policy 用多種機器人的資料訓練；OXE 是主要資料來源
sources: [oxe, octo, openvla, pi0, rt1]
---
# Cross-embodiment（跨機體）學習

- embodiment 指機器人的「身體」：手臂型號、感測器、動作空間 (推論)
- Open X-Embodiment 匯集 22 種機器人、527 種技能的資料 [[src:oxe]]
- RT-X 證明用別台機器人的資料訓練，能提升各台機器人的能力（positive transfer）[[src:oxe]]
- Octo 從 OXE 挑 800k 條軌跡 [[src:octo]]；OpenVLA 挑 970k 條 [[src:openvla]]
- π0 混用 7 種機器人配置，並加入約 9.1% 開源資料 [[src:pi0]]
- 呼應 RT-1 的結論：資料多樣性比資料量更重要 [[src:rt1]]
- 見 [[oxe]]
