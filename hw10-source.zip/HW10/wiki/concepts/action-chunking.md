---
name: action-chunking
type: concept
summary: Action chunking：一次預測一段未來動作而非一步，讓高頻控制變可行
sources: [pi0, octo, rt2, openvla]
---
# Action chunking

- 定義：模型一次輸出未來好幾步的動作（一個 chunk），而不是每次只輸出一步 [[src:octo]]
- π0 一次輸出 H=50 步，控制頻率可達 50 Hz [[src:pi0]]
- 對比：RT-2 55B 每步都要跑一次大模型，只有 1-3 Hz [[src:rt2]]；OpenVLA 在 RTX 4090 約 6 Hz [[src:openvla]]
- 直覺：大模型推論慢，一次多算幾步就能把「思考頻率」和「控制頻率」分開 (推論)
- 相關：[[continuous-action-heads]]
