---
name: vla-timeline
type: concept
summary: 2022–2025 VLA 演進時間線：RT-1 → RT-2 → OXE/RT-X → Octo → OpenVLA → π0 → FAST
sources: [rt1, rt2, oxe, octo, openvla, pi0, fast]
---
# VLA 演進時間線（2022–2025）

| 年 | 工作 | 一句話 |
|---|---|---|
| 2022 | [[rt1]] | 35M Transformer，130k 示範，動作離散成 token [[src:rt1]] |
| 2023 | [[rt2]] | 把 VLM 變成 VLA，動作寫成文字 token，co-fine-tune [[src:rt2]] |
| 2023 | [[oxe]] | 22 種機器人資料大集合，RT-X 正遷移 [[src:oxe]] |
| 2024 | [[octo]] | 93M 開源通用 policy，diffusion head [[src:octo]] |
| 2024 | [[openvla]] | 7B 開源 VLA，贏 55B RT-2-X 16.5% [[src:openvla]] |
| 2024 | [[pi0]] | 3.3B，flow matching，50 Hz 摺衣服 [[src:pi0]] |
| 2025 | [[fast]] | DCT + BPE 動作 token 化，離散路線追平 diffusion [[src:fast]] |

- 趨勢一：從封閉大模型走向開源可微調 (推論)
- 趨勢二：動作從離散 token 走向連續 chunk，但 FAST 讓離散路線重新有競爭力 (推論)
