---
name: continuous-action-heads
type: concept
summary: 連續動作頭：diffusion head（Octo）與 flow matching action expert（π0）
sources: [octo, pi0, openvla]
---
# 連續動作頭：Diffusion 與 Flow Matching

- Octo：Transformer 的 readout token 接上 diffusion action head，經 20 個去噪步產生連續動作 chunk [[src:octo]]
- π0：PaliGemma 旁邊掛一組 300M 的 action expert 權重，用 conditional flow matching 產生連續動作 [[src:pi0]]
- 共同直覺：從雜訊出發，一步步「修正」成合理的動作軌跡，能表示多峰（同一情境有多種合理做法）的動作分佈 (推論)
- 對照組：OpenVLA fine-tune 後比 Diffusion Policy 高 20.4%，顯示離散 token 路線在其實驗中仍有競爭力 [[src:openvla]]
- 相關：[[action-representation]]、[[action-chunking]]
