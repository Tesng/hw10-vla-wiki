---
name: co-fine-tuning
type: concept
summary: Co-fine-tuning：微調時把機器人資料和網路圖文資料混在一起，保住 VLM 的常識
sources: [rt2]
---
# Co-fine-tuning

- 做法：微調 VLM 時，同時放機器人軌跡資料與網路規模的 vision-language 資料（例如 VQA）[[src:rt2]]
- RT-2 中機器人資料約佔 PaLI-X 混合資料 50%、PaLM-E 66% [[src:rt2]]
- 效果：55B 模型 co-fine-tune 泛化平均 63，只用機器人資料 fine-tune 為 52 [[src:rt2]]
- 直覺：只餵機器人資料，VLM 會忘掉網路上學到的常識；混著訓練能保留下來 (推論)
- 相關：[[vla]]、[[rt2]]
