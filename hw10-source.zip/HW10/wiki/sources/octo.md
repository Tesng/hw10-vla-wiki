---
name: octo
type: source
summary: Octo：小型開源通用 policy，用 diffusion head 輸出連續動作 chunk，可彈性換感測器與動作空間
sources: [octo]
---
# Octo（2024）

- 兩種尺寸：Octo-Small 27M、Octo-Base 93M 參數 [[src:octo]]
- 不是建在預訓練 VLM 上，因此是「通用機器人 policy」而非 RT-2 定義的 VLA [[src:octo]]
- 從 Open X-Embodiment 的 25 個資料集挑出 800k 條軌跡預訓練 [[src:octo]]
- Transformer + 可學習的 readout token（類似 BERT 的 [CLS]）；分塊遮罩注意力讓 fine-tune 時可增減輸入/輸出 [[src:octo]]
- 用 diffusion action head 預測一段連續動作（20 個 diffusion 步）[[src:octo]]，見 [[continuous-action-heads]] 與 [[action-chunking]]
- 任務可用語言（t5-base 編碼）或目標影像指定 [[src:octo]]
- Zero-shot 比 RT-1-X 高 29% 成功率，與 55B 的 RT-2-X 表現相近 [[src:octo]]
- 單張 A5000 消費級 GPU、約 100 筆示範、約 5 小時即可 fine-tune；平均比次佳基準高 52% [[src:octo]]
