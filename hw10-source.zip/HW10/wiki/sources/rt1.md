---
name: rt1
type: source
summary: RT-1：用 Transformer 把影像+語言指令直接映射成離散動作 token 的大規模真實機器人 policy
sources: [rt1]
---
# RT-1: Robotics Transformer（2022）

- 在 13 台機器人上花 17 個月收集超過 130k 筆示範、700 多種任務指令 [[src:rt1]]
- 模型約 35M 參數：以語言指令做 FiLM 調變的 EfficientNet-B3 → TokenLearner → decoder-only Transformer [[src:rt1]]
- 每張影像 81 個 visual token，經 TokenLearner 壓成 8 個；輸入 6 張歷史影像共 48 個 token [[src:rt1]]
- 動作有 11 維（7 維手臂、3 維底盤、1 維模式切換），每維離散成 256 個 bin，用分類的方式預測 [[src:rt1]]
- 3 Hz 閉迴路控制，推論需在 100 ms 內 [[src:rt1]]
- 已見指令成功率 97%；未見任務 76%、有干擾物 83%、新背景 59% [[src:rt1]]
- 結論：資料多樣性比資料量更重要 [[src:rt1]]
- 它是之後 [[rt2]] 的比較基準，也是 [[action-representation]] 中「離散 token」路線的起點 (推論)
