---
name: openvla
type: source
summary: OpenVLA：7B 開源 VLA（Llama 2 + SigLIP/DINOv2），以 1/7 參數贏過 RT-2-X，可用 LoRA 在單卡微調
sources: [openvla]
---
# OpenVLA（2024）

- 7B 參數開源 VLA：Prismatic-7B = 600M 視覺編碼器（融合 SigLIP 與 DINOv2）+ 2 層 MLP projector + Llama 2 7B [[src:openvla]]
- 在 Open X-Embodiment 中挑 970k 條軌跡訓練 [[src:openvla]]
- 動作離散化：每維 256 個 bin，範圍取訓練資料第 1 到第 99 百分位（避免極端值把 bin 撐寬）；覆寫 Llama tokenizer 中最少用的 256 個 token [[src:openvla]]，見 [[action-representation]]
- 訓練：64 張 A100 跑 14 天（21,500 A100-hours）[[src:openvla]]
- 在 29 個任務上比 55B 的 RT-2-X 高 16.5% 絕對成功率，參數少 7 倍 [[src:openvla]]
- fine-tune 後比 Diffusion Policy 高 20.4% [[src:openvla]]
- LoRA（rank 32，只訓練約 1.4% 參數）成功率 68.2%，全參數 fine-tune 69.7%；單張 A100 約 10-15 小時 [[src:openvla]]
- 一張 RTX 4090 約 6 Hz、約 15GB 記憶體 [[src:openvla]]
