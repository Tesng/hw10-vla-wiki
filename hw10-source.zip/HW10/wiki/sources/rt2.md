---
name: rt2
type: source
summary: RT-2：把動作寫成文字 token、和網路圖文資料一起 co-fine-tune 大型 VLM，正式提出 VLA 一詞
sources: [rt2]
---
# RT-2: Vision-Language-Action Models（2023）

- 提出 vision-language-action（VLA）模型：微調 VLM 讓它直接輸出機器人動作 [[src:rt2]]
- 核心做法：把動作表示成文字 token，直接放進 VLM 的訓練資料 [[src:rt2]]
- 動作 = 6-DoF 末端位移與旋轉 + 夾爪開合 + 終止指令；連續維度離散成 256 個 bin，每個動作 = 8 個整數 [[src:rt2]]
- PaLI-X 本來就有 1000 以內每個整數的 token，可直接對應；PaLM-E 沒有，因此覆寫 256 個最少用到的 token 當動作 token [[src:rt2]]
- 模型：RT-2-PaLI-X（5B、55B）、RT-2-PaLM-E（12B）[[src:rt2]]
- 見 [[co-fine-tuning]]：機器人資料約佔 PaLI-X 混合資料 50%、PaLM-E 66%；55B 模型 co-fine-tune 泛化平均 63，只 fine-tune 為 52 [[src:rt2]]
- 未見情境平均：RT-2 兩個版本都是 62，RT-1 為 32，約 2 倍提升 [[src:rt2]]
- 約 6,000 次評估 [[src:rt2]]
- 湧現能力：認得新物體、理解機器人資料沒有的指令（把東西放到某個數字上）、簡單推理（選最小的物體）、chain-of-thought（拿石頭當鐵鎚）[[src:rt2]]
- 55B 只能跑 1-3 Hz，5B 約 5 Hz，放在雲端 TPU 上由機器人透過網路呼叫 [[src:rt2]]
- 限制：網路資料不會教機器人新動作，技能仍受限於機器人資料中出現過的動作 [[src:rt2]]
