---
name: fast
type: source
summary: FAST：用 DCT + BPE 壓縮動作序列再 token 化，讓「離散 token」路線也能做高頻靈巧任務
sources: [fast]
---
# FAST: Efficient Action Tokenization（2025）

- 問題：以往 VLA 每個時間步、每個維度各切 256 個 bin；控制頻率一高，相鄰 token 幾乎一樣，模型學到「照抄前一個」就能讓 loss 很低 [[src:fast]]
- 做法：每個維度先做離散餘弦轉換（DCT）→ 係數四捨五入（丟掉不重要的）→ 低頻在前攤平 → 用 BPE 壓縮，詞表預設 1024 [[src:fast]]
- 壓縮效果：50 Hz 摺 T 恤的 1 秒動作，原本 700 個 token，FAST 只要 53 個（13.2 倍）[[src:fast]]
- 每段動作約 30 個 token／手臂，幾乎不隨控制頻率增加 [[src:fast]]
- π0-FAST（自回歸、離散 token）在摺衣服等任務上追平用 diffusion 的 π0，訓練時間最多少 5 倍 [[src:fast]]
- 代價：在 4090 上每段動作推論約 750 ms，diffusion 版 π0 約 100 ms [[src:fast]]
- 相關：[[action-representation]]、[[pi0]]、[[action-chunking]]
