---
name: oxe
type: source
summary: Open X-Embodiment：21 個機構、22 種機器人的資料大集合，RT-X 證明跨機體訓練有正遷移
sources: [oxe]
---
# Open X-Embodiment 與 RT-X（2023）

- 匯集 22 種機器人的資料，由 21 個機構合作 [[src:oxe]]
- 涵蓋 527 種技能（160,266 個任務）[[src:oxe]]
- 用統一的資料格式釋出 [[src:oxe]]
- 用這份資料訓練的 RT-X 模型（RT-1-X、RT-2-X）出現正遷移（positive transfer），提升多種機器人的能力 [[src:oxe]]
- 這是 [[cross-embodiment]] 的代表性資料集，後來 [[octo]]、[[openvla]] 都從中挑資料預訓練 (推論)
