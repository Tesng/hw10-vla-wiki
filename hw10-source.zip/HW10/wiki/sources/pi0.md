---
name: pi0
type: source
summary: π0：PaliGemma 3B + 300M flow-matching action expert，輸出 50 步連續動作 chunk，可做摺衣服等靈巧任務
sources: [pi0]
---
# π0（Physical Intelligence, 2024）

- 在預訓練 VLM（PaliGemma 3B）上加一個 300M 參數的 action expert，總計 3.3B [[src:pi0]]
- action expert 是處理機器人狀態與動作 token 的獨立權重，用 conditional flow matching 訓練，直接輸出連續動作 [[src:pi0]]，見 [[continuous-action-heads]]
- 一次輸出 H=50 步的 action chunk，靈巧任務控制頻率最高 50 Hz [[src:pi0]]，見 [[action-chunking]]
- 超過 10,000 小時機器人資料；7 種機器人配置、68 個任務；約 9.1% 是開源資料（OXE、Bridge v2、DROID）[[src:pi0]]
- 訓練分兩段：廣泛資料 pre-training 得到通用基底，再用少量高品質資料 post-training 到特定任務（簡單任務約 5 小時資料，最難的 100 小時以上）[[src:pi0]]
- 示範任務：摺衣服、收拾餐桌、組紙箱、裝雞蛋、裝購物袋 [[src:pi0]]
