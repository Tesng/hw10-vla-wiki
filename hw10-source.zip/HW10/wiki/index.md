---
name: index
type: meta
summary: Wiki 目錄
sources: []
---
# VLA Wiki — Index

## Concepts
- [[vla]] — VLA 的定義與三個設計問題
- [[action-representation]] — 離散 token vs 連續動作
- [[co-fine-tuning]] — 機器人資料 + 網路資料混訓
- [[cross-embodiment]] — 跨機器人資料與正遷移
- [[action-chunking]] — 一次預測一段動作
- [[continuous-action-heads]] — diffusion / flow matching
- [[vla-timeline]] — 2022–2025 演進

## Sources
- [[rt1]] — RT-1 (2022)
- [[rt2]] — RT-2 (2023)
- [[oxe]] — Open X-Embodiment (2023)
- [[octo]] — Octo (2024)
- [[openvla]] — OpenVLA (2024)
- [[pi0]] — π0 (2024)
- [[fast]] — FAST (2025)
